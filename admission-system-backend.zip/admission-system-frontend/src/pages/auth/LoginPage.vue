<template>
  <section class="auth-page">
    <div class="auth-card auth-card-compact">
      <div class="auth-header">
        <span class="auth-badge">Личный кабинет</span>
        <h1>Вход в систему</h1>
        <p>
          Используйте email и пароль, чтобы продолжить работу с заявлениями,
          документами и рейтингами.
        </p>
      </div>

      <form class="form auth-form" @submit.prevent="login">
        <label>
          Email
          <input v-model="form.email" type="email" placeholder="student@example.com" />
        </label>

        <label>
          Пароль
          <input v-model="form.password" type="password" placeholder="Введите пароль" />
        </label>

        <button type="submit" class="auth-submit">Войти</button>
      </form>

      <p v-if="error" class="error">{{ error }}</p>

      <div class="auth-footer">
        <span>Нет аккаунта?</span>
        <RouterLink to="/register">Зарегистрироваться</RouterLink>
      </div>
    </div>
  </section>
</template>

<script>
import http from '@/shared/api/http'
import { saveAuthSession } from '@/shared/lib/session'

export default {
  name: 'LoginPage',

  data() {
    return {
      form: {
        email: '',
        password: ''
      },
      error: ''
    }
  },

  methods: {
    async login() {
      this.error = ''

      try {
        const response = await http.post('/auth/login', this.form)

        saveAuthSession(response.data)

        this.$router.push('/applicant')
      } catch (error) {
        this.error = error.response?.data?.message || 'Ошибка входа'
      }
    }
  }
}
</script>
