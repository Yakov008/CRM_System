<template>
  <section class="auth-page">
    <div class="auth-card">
      <div class="auth-header">
        <span class="auth-badge">Новый абитуриент</span>
        <h1>Регистрация</h1>
        <p>
          Заполните основные данные. После регистрации вы сразу попадёте в личный кабинет.
        </p>
      </div>

      <form class="form auth-form" @submit.prevent="register">
        <div class="auth-grid">
          <label>
            Email
            <input v-model.trim="form.email" type="email" maxlength="120" placeholder="student@example.com" />
          </label>

          <label>
            Пароль
            <input v-model="form.password" type="password" maxlength="100" placeholder="Минимум 6 символов" />
          </label>

          <label>
            Фамилия
            <input v-model.trim="form.lastName" type="text" maxlength="80" placeholder="Иванов" />
          </label>

          <label>
            Имя
            <input v-model.trim="form.firstName" type="text" maxlength="80" placeholder="Иван" />
          </label>

          <label>
            Отчество
            <input v-model.trim="form.middleName" type="text" maxlength="80" placeholder="Иванович" />
          </label>

          <label>
            Дата рождения
            <input v-model="form.birthDate" type="date" />
          </label>

          <label>
            Телефон
            <input
              v-model="form.phone"
              type="tel"
              maxlength="16"
              placeholder="+7 999 000-00-00"
              @input="formatPhone"
            />
          </label>

          <label>
            Номер паспорта
            <input
              v-model="form.passportNumber"
              type="text"
              inputmode="numeric"
              maxlength="11"
              placeholder="1234 567890"
              @input="formatPassport"
            />
          </label>
        </div>

        <button type="submit" class="auth-submit">Создать аккаунт</button>
      </form>

      <p v-if="message" class="success">{{ message }}</p>
      <p v-if="error" class="error">{{ error }}</p>

      <div class="auth-footer">
        <span>Уже есть аккаунт?</span>
        <RouterLink to="/login">Войти</RouterLink>
      </div>
    </div>
  </section>
</template>

<script>
import http from '@/shared/api/http'
import { saveAuthSession } from '@/shared/lib/session'

export default {
  name: 'RegisterPage',

  data() {
    return {
      form: {
        email: '',
        password: '',
        lastName: '',
        firstName: '',
        middleName: '',
        birthDate: '',
        phone: '+7 ',
        passportNumber: ''
      },
      message: '',
      error: ''
    }
  },

  methods: {
    async register() {
      this.message = ''
      this.error = ''

      try {
        const response = await http.post('/applicants/register', this.form)

        const loginResponse = await http.post('/auth/login', {
          email: this.form.email,
          password: this.form.password
        })

        saveAuthSession({
          ...response.data,
          token: loginResponse.data.token
        })

        this.message = 'Регистрация прошла успешно'
        this.$router.push('/applicant')
      } catch (error) {
        this.error = error.response?.data?.message || 'Ошибка регистрации'
      }
    },

    formatPhone() {
      let digits = this.form.phone.replace(/\D/g, '')

      if (digits.startsWith('8')) {
        digits = `7${digits.slice(1)}`
      }

      if (!digits.startsWith('7')) {
        digits = `7${digits}`
      }

      digits = digits.slice(0, 11)

      const part1 = digits.slice(1, 4)
      const part2 = digits.slice(4, 7)
      const part3 = digits.slice(7, 9)
      const part4 = digits.slice(9, 11)

      let value = '+7'

      if (part1) {
        value += ` ${part1}`
      }

      if (part2) {
        value += ` ${part2}`
      }

      if (part3) {
        value += `-${part3}`
      }

      if (part4) {
        value += `-${part4}`
      }

      this.form.phone = value
    },

    formatPassport() {
      const digits = this.form.passportNumber.replace(/\D/g, '').slice(0, 10)

      this.form.passportNumber = digits.length > 4
        ? `${digits.slice(0, 4)} ${digits.slice(4)}`
        : digits
    }
  }
}
</script>
