<template>
  <section class="auth-page">
    <div class="auth-card">
      <div class="auth-header">
        <span class="auth-badge">Новый абитуриент</span>
        <h1>Регистрация</h1>
        <p>
          Заполните основные данные. После регистрации вы сразу попадете в
          личный кабинет.
        </p>
      </div>

      <form class="form auth-form" @submit.prevent="register">
        <div class="auth-grid">
          <label>
            Email
            <input v-model="form.email" type="email" placeholder="student@example.com" />
          </label>

          <label>
            Пароль
            <input v-model="form.password" type="password" placeholder="Минимум 6 символов" />
          </label>

          <label>
            Фамилия
            <input v-model="form.lastName" type="text" placeholder="Иванов" />
          </label>

          <label>
            Имя
            <input v-model="form.firstName" type="text" placeholder="Иван" />
          </label>

          <label>
            Отчество
            <input v-model="form.middleName" type="text" placeholder="Иванович" />
          </label>

          <label>
            Дата рождения
            <input v-model="form.birthDate" type="date" />
          </label>

          <label>
            Телефон
            <input v-model="form.phone" type="text" placeholder="+7 999 000-00-00" />
          </label>

          <label>
            Номер паспорта
            <input v-model="form.passportNumber" type="text" placeholder="1234 567890" />
          </label>
        </div>

        <button type="submit" class="auth-submit">Создать аккаунт</button>
      </form>

      <p v-if="message" class="success">{{ message }}</p>
      <p v-if="error" class="error">{{ error }}</p>

      <div class="auth-footer">
        <span>Уже есть аккаунт?</span>
        <RouterLink to="/login">Войти</RouterLink>
      </div>
    </div>
  </section>
</template>

<script>
import http from '@/shared/api/http'
import { saveAuthSession } from '@/shared/lib/session'

export default {
  name: 'RegisterPage',

  data() {
    return {
      form: {
        email: '',
        password: '',
        lastName: '',
        firstName: '',
        middleName: '',
        birthDate: '',
        phone: '',
        passportNumber: ''
      },
      message: '',
      error: ''
    }
  },

  methods: {
    async register() {
      this.message = ''
      this.error = ''

      try {
        const response = await http.post('/applicants/register', this.form)

        const loginResponse = await http.post('/auth/login', {
          email: this.form.email,
          password: this.form.password
        })

        saveAuthSession({
          ...response.data,
          token: loginResponse.data.token
        })

        this.message = 'Регистрация прошла успешно'
        this.$router.push('/applicant')
      } catch (error) {
        this.error = error.response?.data?.message || 'Ошибка регистрации'
      }
    }
  }
}
</script>
