<template>
  <section>
    <h1>Документы заявления</h1>

    <div v-if="!applicantId" class="card">
      <p>Вы не вошли как абитуриент.</p>
      <RouterLink to="/login">Перейти ко входу</RouterLink>
    </div>

    <div v-else>
      <div class="card">
        <h2>Выбор заявления</h2>

        <label>
          Заявление
          <select v-model.number="selectedApplicationId" @change="loadDocuments">
            <option value="" disabled>Выберите заявление</option>
            <option
              v-for="application in applications"
              :key="application.id"
              :value="application.id"
            >
              Заявление №{{ application.id }} — {{ application.admissionCampaignName }} — {{ application.status }}
            </option>
          </select>
        </label>

        <p v-if="applications.length === 0 && !loadingApplications">
          У вас пока нет заявлений.
        </p>
      </div>

      <div v-if="selectedApplicationId" class="card">
        <h2>Добавить документ</h2>

        <form class="form" @submit.prevent="addDocument">
          <label>
            Тип документа
            <select v-model="form.documentType">
              <option value="" disabled>Выберите тип документа</option>
              <option value="PASSPORT">Паспорт</option>
              <option value="EDUCATION_CERTIFICATE">Документ об образовании</option>
              <option value="CONSENT">Согласие на зачисление</option>
              <option value="OTHER">Другое</option>
            </select>
          </label>

          <input
            type="file"
            @change="onFileChange"
          />

          <button type="submit" :disabled="saving">
            {{ saving ? 'Сохранение...' : 'Добавить документ' }}
          </button>
        </form>

        <p v-if="message" class="success">{{ message }}</p>
        <p v-if="error" class="error">{{ error }}</p>
      </div>

      <div v-if="replacingDocument" class="card edit-card">
        <h2>Замена документа №{{ replacingDocument.id }}</h2>

        <p class="muted">
          Старый файл будет заменён новым, а статус документа снова станет «Загружен».
        </p>

        <form class="form" @submit.prevent="replaceDocument">
          <label>
            Тип документа
            <select v-model="replaceForm.documentType">
              <option value="" disabled>Выберите тип документа</option>
              <option value="PASSPORT">Паспорт</option>
              <option value="EDUCATION_CERTIFICATE">Документ об образовании</option>
              <option value="CONSENT">Согласие на зачисление</option>
              <option value="OTHER">Другое</option>
            </select>
          </label>

          <input
            type="file"
            @change="onReplaceFileChange"
          />

          <div class="button-row">
            <button type="submit" :disabled="replacing">
              {{ replacing ? 'Замена...' : 'Заменить документ' }}
            </button>

            <button
              type="button"
              class="secondary-button"
              @click="cancelReplace"
            >
              Отмена
            </button>
          </div>
        </form>
      </div>

      <div v-if="selectedApplicationId" class="card">
        <h2>Документы выбранного заявления</h2>

        <p v-if="loadingDocuments">Загрузка документов...</p>

        <div v-if="documents.length > 0" class="documents-table-wrapper">
          <table class="table documents-table"> 
            <thead>
              <tr>
                <th>Тип</th>
                <th>Файл</th>
                <th>Путь</th>
                <th>Статус</th>
                <th>Загружен</th>
                <th>Комментарий</th>
                <th>Действие</th>
              </tr>
            </thead>

            <tbody>
              <tr v-for="document in documents" :key="document.id">
                <td>{{ translateDocumentType(document.documentType) }}</td>
                <td>
                  <div class="file-name-scroll" :title="document.fileName">
                    {{ document.fileName }}
                  </div>
                </td>
                <td>
                  <div class="file-path-wrap" :title="document.filePath">
                    {{ document.filePath }}
                  </div>
                </td>
                <td>
                  <span class="status">{{ translateDocumentStatus(document.status) }}</span>
                </td>
                <td>{{ formatDate(document.uploadedAt) }}</td>
                <td>{{ document.comment || '—' }}</td>
                <td>
                  <div class="button-column">
                    <button
                      type="button"
                      class="secondary-button small-button"
                      @click="downloadDocument(document)"
                    >
                      Скачать
                    </button>

                    <button
                      v-if="document.status !== 'VERIFIED'"
                      type="button"
                      class="secondary-button small-button"
                      @click="startReplace(document)"
                    >
                      Заменить
                    </button>

                    <button
                      v-if="document.status !== 'VERIFIED'"
                      type="button"
                      class="danger-button small-button"
                      :disabled="deletingDocumentId === document.id"
                      @click="deleteDocument(document)"
                    >
                      {{ deletingDocumentId === document.id ? 'Удаление...' : 'Удалить' }}
                    </button>
                  </div>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
        
        <p v-else-if="!loadingDocuments">
          Документы для этого заявления пока не добавлены.
        </p>
      </div>
    </div>
  </section>
</template>

<script>
import http from '@/shared/api/http'
import { getSession } from '@/shared/lib/session'

export default {
  name: 'DocumentsPage',

  data() {
    const session = getSession()

    return {
      applicantId: session.applicantId,
      applications: [],
      documents: [],
      selectedApplicationId: '',
      form: {
        documentType: '',
        file: null
      },
      replacingDocument: null,
      replaceForm: {
        documentType: '',
        file: null
      },
      loadingApplications: false,
      loadingDocuments: false,
      saving: false,
      replacing: false,
      deletingDocumentId: null,
      message: '',
      error: ''
    }
  },

  async mounted() {
    if (!this.applicantId) {
      return
    }

    await this.loadApplications()
  },

  methods: {
    async loadApplications() {
      this.loadingApplications = true
      this.error = ''

      try {
        const response = await http.get(`/applicants/${this.applicantId}/applications`)
        this.applications = response.data

        if (this.applications.length > 0 && !this.selectedApplicationId) {
          this.selectedApplicationId = this.applications[0].id
          await this.loadDocuments()
        }
      } catch (error) {
        this.error = error.response?.data?.message || 'Не удалось загрузить заявления'
      } finally {
        this.loadingApplications = false
      }
    },

    async loadDocuments() {
      if (!this.selectedApplicationId) {
        return
      }

      this.loadingDocuments = true
      this.error = ''

      try {
        const response = await http.get(
          `/applicants/${this.applicantId}/applications/${this.selectedApplicationId}/documents`
        )

        this.documents = response.data
      } catch (error) {
        this.error = error.response?.data?.message || 'Не удалось загрузить документы'
      } finally {
        this.loadingDocuments = false
      }
    },

    async addDocument() {
      this.message = ''
      this.error = ''

      if (!this.selectedApplicationId) {
        this.error = 'Выберите заявление'
        return
      }

      if (!this.form.documentType || !this.form.file) {
        this.error = 'Выберите тип документа и файл'
        return
      }

      const formData = new FormData()
      formData.append('documentType', this.form.documentType)
      formData.append('file', this.form.file)

      this.saving = true

      try {
        await http.post(
          `/applicants/${this.applicantId}/applications/${this.selectedApplicationId}/documents/upload`,
          formData
        )

        this.message = 'Документ загружен'

        this.form = {
          documentType: '',
          file: null
        }

        await this.loadDocuments()
      } catch (error) {
        this.error = error.response?.data?.message || 'Не удалось загрузить документ'
      } finally {
        this.saving = false
      }
    },

    async downloadDocument(doc) {
      this.error = ''

      try {
        const response = await http.get(`/documents/${doc.id}/download`, {
          responseType: 'blob'
        })

        const url = window.URL.createObjectURL(new Blob([response.data]))
        const link = window.document.createElement('a')

        link.href = url
        link.download = doc.fileName || 'document'
        window.document.body.appendChild(link)

        link.click()
        link.remove()

        window.URL.revokeObjectURL(url)
      } catch (error) {
        this.error = error.response?.data?.message || 'Не удалось скачать документ'
      }
    },

    onReplaceFileChange(event) {
      const file = event.target.files[0]

      if (!file) {
        this.replaceForm.file = null
        return
      }

      this.replaceForm.file = file
    },

    startReplace(document) {
      this.message = ''
      this.error = ''

      this.replacingDocument = document
      this.replaceForm = {
        documentType: document.documentType,
        file: null
      }

      window.scrollTo({
        top: 0,
        behavior: 'smooth'
      })
    },

    cancelReplace() {
      this.replacingDocument = null
      this.replaceForm = {
        documentType: '',
        file: null
      }
    },

    async replaceDocument() {
      this.message = ''
      this.error = ''

      if (!this.replacingDocument) {
        this.error = 'Документ для замены не выбран'
        return
      }

      if (!this.replaceForm.documentType || !this.replaceForm.file) {
        this.error = 'Выберите тип документа и новый файл'
        return
      }

      const formData = new FormData()
      formData.append('documentType', this.replaceForm.documentType)
      formData.append('file', this.replaceForm.file)

      this.replacing = true

      try {
        await http.put(
          `/applicants/${this.applicantId}/applications/${this.selectedApplicationId}/documents/${this.replacingDocument.id}/replace`,
          formData
        )

        this.message = 'Документ заменён и снова отправлен на проверку'

        this.cancelReplace()
        await this.loadDocuments()
      } catch (error) {
        this.error = error.response?.data?.message || 'Не удалось заменить документ'
      } finally {
        this.replacing = false
      }
    },

    async deleteDocument(document) {
      const confirmed = window.confirm(
        `Удалить документ "${document.fileName}"?`
      )

      if (!confirmed) {
        return
      }

      this.message = ''
      this.error = ''
      this.deletingDocumentId = document.id

      try {
        await http.delete(
          `/applicants/${this.applicantId}/applications/${this.selectedApplicationId}/documents/${document.id}`
        )

        this.message = 'Документ удалён'

        if (this.replacingDocument?.id === document.id) {
          this.cancelReplace()
        }

        await this.loadDocuments()
      } catch (error) {
        this.error = error.response?.data?.message || 'Не удалось удалить документ'
      } finally {
        this.deletingDocumentId = null
      }
    },

    translateDocumentType(type) {
      const types = {
        PASSPORT: 'Паспорт',
        EDUCATION_CERTIFICATE: 'Документ об образовании',
        CONSENT: 'Согласие',
        OTHER: 'Другое'
      }

      return types[type] || type
    },

    translateDocumentStatus(status) {
      const statuses = {
        UPLOADED: 'Загружен',
        VERIFIED: 'Проверен',
        REJECTED: 'Отклонён'
      }

      return statuses[status] || status
    },
    onFileChange(event) {
      const file = event.target.files[0]

      if (!file) {
        this.form.file = null
        return
      }

      this.form.file = file
    },

    formatDate(value) {
      if (!value) {
        return '—'
      }

      return new Date(value).toLocaleString('ru-RU')
    }
  }
}
</script>
