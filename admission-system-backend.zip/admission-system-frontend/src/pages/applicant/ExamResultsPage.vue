<template>
  <section>
    <h1>Результаты ЕГЭ</h1>

    <div v-if="limitInfo && applicantId" class="card">
      <h2>Лимит добавления результатов</h2>

      <p>
        <b>Добавлено за последний час:</b>
        {{ limitInfo.used }} из {{ limitInfo.limit }}
      </p>

      <p>
        <b>Осталось добавлений:</b>
        {{ limitInfo.remaining }}
      </p>

      <p v-if="limitInfo.resetAt">
        <b>Ближайшее восстановление лимита:</b>
        {{ formatDate(limitInfo.resetAt) }}
      </p>

      <p v-else class="muted">
        За последний час результатов ещё не добавлялось.
      </p>
    </div>

    <div v-if="!applicantId" class="card">
      <p>Вы не вошли как абитуриент.</p>
      <RouterLink to="/login">Перейти ко входу</RouterLink>
    </div>

    <div v-else>
      <div class="card">
        <h2>Добавить результат</h2>

        <form class="form" @submit.prevent="addExamResult">
          <select v-model.number="form.examSubjectId">
            <option value="" disabled>Выберите предмет</option>
            <option
              v-for="subject in subjects"
              :key="subject.id"
              :value="subject.id"
            >
              {{ subject.name }}
            </option>
          </select>

          <input
            v-model.number="form.examYear"
            type="number"
            placeholder="Год экзамена"
          />

          <input
            v-model.number="form.score"
            type="number"
            placeholder="Балл"
            min="0"
            max="100"
          />

          <button type="submit" :disabled="saving">
            {{ saving ? 'Сохранение...' : 'Добавить' }}
          </button>
        </form>

        <p v-if="message" class="success">{{ message }}</p>
        <p v-if="error" class="error">{{ error }}</p>
      </div>

      <div v-if="editingResultId" class="card edit-card">
        <h2>Редактировать результат ЕГЭ</h2>

        <form class="form" @submit.prevent="updateExamResult">
          <select v-model.number="editForm.examSubjectId">
            <option value="" disabled>Выберите предмет</option>
            <option
              v-for="subject in subjects"
              :key="subject.id"
              :value="subject.id"
            >
              {{ subject.name }}
            </option>
          </select>

          <input
            v-model.number="editForm.examYear"
            type="number"
            placeholder="Год экзамена"
          />

          <input
            v-model.number="editForm.score"
            type="number"
            placeholder="Балл"
            min="0"
            max="100"
          />

          <div class="button-row">
            <button type="submit" :disabled="updating">
              {{ updating ? 'Сохранение...' : 'Сохранить изменения' }}
            </button>

            <button
              type="button"
              class="secondary-button"
              @click="cancelEdit"
            >
              Отмена
            </button>
          </div>
        </form>
      </div>

      <div class="card">
        <h2>Мои результаты</h2>

        <p v-if="loading">Загрузка...</p>

        <table v-if="results.length > 0" class="table">
          <thead>
            <tr>
              <th>Предмет</th>
              <th>Год</th>
              <th>Балл</th>
              <th>Добавлено</th>
              <th>Действие</th>
            </tr>
          </thead>

          <tbody>
            <tr v-for="result in results" :key="result.id">
              <td>{{ result.examSubjectName }}</td>
              <td>{{ result.examYear }}</td>
              <td>{{ result.score }}</td>
              <td>{{ formatDate(result.createdAt) }}</td>
              <td>
                <div class="button-row">
                  <button
                    type="button"
                    class="secondary-button small-button"
                    @click="startEdit(result)"
                  >
                    Изменить
                  </button>

                  <button
                    type="button"
                    class="danger-button small-button"
                    :disabled="deletingResultId === result.id"
                    @click="deleteExamResult(result)"
                  >
                    {{ deletingResultId === result.id ? 'Удаление...' : 'Удалить' }}
                  </button>
                </div>
              </td>
            </tr>
          </tbody>
        </table>

        <p v-else-if="!loading">Результаты ЕГЭ пока не добавлены.</p>
      </div>
    </div>
  </section>
</template>

<script>
import http from '@/shared/api/http'
import { getSession } from '@/shared/lib/session'

export default {
  name: 'ExamResultsPage',

  data() {
    const session = getSession()

    return {
      applicantId: session.applicantId,
      subjects: [],
      results: [],
      limitInfo: null,
      form: {
        examSubjectId: '',
        examYear: new Date().getFullYear(),
        score: ''
      },
      editingResultId: null,
      editForm: {
        examSubjectId: '',
        examYear: new Date().getFullYear(),
        score: ''
      },
      loading: false,
      saving: false,
      updating: false,
      deletingResultId: null,
      message: '',
      error: ''
    }
  },

  async mounted() {
    if (!this.applicantId) {
      return
    }

    await this.loadSubjects()
    await this.loadResults()
    await this.loadLimit()
  },

  methods: {
    async loadSubjects() {
      try {
        const response = await http.get('/exam-subjects')
        this.subjects = response.data
      } catch (error) {
        this.error = 'Не удалось загрузить список предметов'
      }
    },

    async loadResults() {
      this.loading = true

      try {
        const response = await http.get(`/applicants/${this.applicantId}/exam-results`)
        this.results = response.data
      } catch (error) {
        this.error = error.response?.data?.message || 'Не удалось загрузить результаты ЕГЭ'
      } finally {
        this.loading = false
      }
    },

    async loadLimit() {
      try {
        const response = await http.get(
          `/applicants/${this.applicantId}/exam-results/limit`
        )

        this.limitInfo = response.data
      } catch (error) {
        this.error = error.response?.data?.message || 'Не удалось загрузить лимит добавления ЕГЭ'
      }
    },

    async addExamResult() {
      this.message = ''
      this.error = ''

      if (!this.form.examSubjectId || !this.form.examYear || this.form.score === '') {
        this.error = 'Заполните все поля'
        return
      }

      this.saving = true

      try {
        await http.post(`/applicants/${this.applicantId}/exam-results`, this.form)

        this.message = 'Результат ЕГЭ добавлен'

        this.form.examSubjectId = ''
        this.form.examYear = new Date().getFullYear()
        this.form.score = ''

        await this.loadResults()
        await this.loadLimit()
      } catch (error) {
        this.error = error.response?.data?.message || 'Не удалось добавить результат ЕГЭ'
      } finally {
        this.saving = false
      }
    },

    startEdit(result) {
      this.message = ''
      this.error = ''

      this.editingResultId = result.id

      this.editForm = {
        examSubjectId: result.examSubjectId,
        examYear: result.examYear,
        score: result.score
      }

      window.scrollTo({
        top: 0,
        behavior: 'smooth'
      })
    },

    cancelEdit() {
      this.editingResultId = null

      this.editForm = {
        examSubjectId: '',
        examYear: new Date().getFullYear(),
        score: ''
      }
    },

    async updateExamResult() {
      this.message = ''
      this.error = ''

      if (!this.editForm.examSubjectId || !this.editForm.examYear || this.editForm.score === '') {
        this.error = 'Заполните все поля'
        return
      }

      if (this.editForm.score < 0 || this.editForm.score > 100) {
        this.error = 'Балл должен быть от 0 до 100'
        return
      }

      this.updating = true

      try {
        await http.put(
          `/applicants/${this.applicantId}/exam-results/${this.editingResultId}`,
          this.editForm
        )

        this.message = 'Результат ЕГЭ изменён'

        this.cancelEdit()
        await this.loadResults()
      } catch (error) {
        this.error = error.response?.data?.message || 'Не удалось изменить результат ЕГЭ'
      } finally {
        this.updating = false
      }
    },

    async deleteExamResult(result) {
      const confirmed = window.confirm(
        `Удалить результат "${result.examSubjectName}" за ${result.examYear} год?`
      )

      if (!confirmed) {
        return
      }

      this.message = ''
      this.error = ''
      this.deletingResultId = result.id

      try {
        await http.delete(
          `/applicants/${this.applicantId}/exam-results/${result.id}`
        )

        this.message = 'Результат ЕГЭ удалён'

        if (this.editingResultId === result.id) {
          this.cancelEdit()
        }

        await this.loadResults()
        await this.loadLimit()
      } catch (error) {
        this.error = error.response?.data?.message || 'Не удалось удалить результат ЕГЭ'
      } finally {
        this.deletingResultId = null
      }
    },

    formatDate(value) {
      if (!value) {
        return '—'
      }

      return new Date(value).toLocaleString('ru-RU')
    }
  }
}
</script>
