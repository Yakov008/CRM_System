<template>
  <section>
    <h1>Мои заявления</h1>

    <div v-if="!applicantId" class="card">
      <p>Вы не вошли как абитуриент.</p>
      <RouterLink to="/login">Перейти ко входу</RouterLink>
    </div>

    <div v-else>
      <div class="card">
        <h2>Подать заявление</h2>

        <form class="form" @submit.prevent="createApplication(true)">
          <label>
            Приёмная кампания
            <select v-model.number="form.admissionCampaignId">
              <option value="" disabled>Выберите кампанию</option>
              <option v-for="campaign in campaigns" :key="campaign.id" :value="campaign.id">
                {{ campaign.name }}
              </option>
            </select>
          </label>

          <div>
            <h3>Направления и приоритеты</h3>

            <div v-for="(priority, index) in form.priorities" :key="index" class="priority-row">
              <span class="priority-number">{{ index + 1 }}</span>

              <select v-model.number="priority.programId">
                <option value="" disabled>Выберите направление</option>
                <option v-for="program in availableCreatePrograms" :key="program.id" :value="program.id">
                  {{ program.code }} {{ program.name }}
                </option>
              </select>

              <button type="button" class="secondary-button" @click="removeCreatePriority(index)"
                :disabled="form.priorities.length === 1">
                Удалить
              </button>
            </div>

            <button type="button" class="secondary-button" @click="addCreatePriority"
              :disabled="form.priorities.length >= 5">
              Добавить направление
            </button>
          </div>

          <textarea v-model="form.comment" placeholder="Комментарий к заявлению" rows="3"></textarea>

          <div class="button-row">
            <button type="button" class="secondary-button" :disabled="saving" @click="createApplication(false)">
              {{ saving ? 'Сохранение...' : 'Сохранить черновик' }}
            </button>

            <button type="submit" :disabled="saving">
              {{ saving ? 'Подача заявления...' : 'Подать заявление' }}
            </button>
          </div>
        </form>

        <p v-if="message" class="success">{{ message }}</p>
        <p v-if="error" class="error">{{ error }}</p>
      </div>

      <div v-if="editingApplicationId" class="card edit-card">
        <h2>Редактирование заявления №{{ editingApplicationId }}</h2>

        <p class="muted">
          Приёмную кампанию изменить нельзя. Можно изменить только направления, приоритеты и комментарий.
        </p>

        <form class="form" @submit.prevent="updateApplication">
          <div>
            <h3>Новые направления и приоритеты</h3>

            <div v-for="(priority, index) in editForm.priorities" :key="index" class="priority-row">
              <span class="priority-number">{{ index + 1 }}</span>

              <select v-model.number="priority.programId">
                <option value="" disabled>Выберите направление</option>
                <option v-for="program in availableEditPrograms" :key="program.id" :value="program.id">
                  {{ program.code }} {{ program.name }}
                </option>
              </select>

              <button type="button" class="secondary-button" @click="removeEditPriority(index)"
                :disabled="editForm.priorities.length === 1">
                Удалить
              </button>
            </div>

            <button type="button" class="secondary-button" @click="addEditPriority"
              :disabled="editForm.priorities.length >= 5">
              Добавить направление
            </button>
          </div>

          <textarea v-model="editForm.comment" placeholder="Комментарий к заявлению" rows="3"></textarea>

          <div class="button-row">
            <button type="submit" :disabled="updating">
              {{ updating ? 'Сохранение...' : 'Сохранить изменения' }}
            </button>

            <button type="button" class="secondary-button" @click="cancelEdit">
              Отмена
            </button>
          </div>
        </form>
      </div>

      <div class="card">
        <h2>Список заявлений</h2>

        <p v-if="loading">Загрузка...</p>

        <div v-if="applications.length > 0" class="application-list">
          <div v-for="(application, index) in applications" :key="application.id" class="application-card">
            <div class="application-header">
              <div>
                <h3>Заявление №{{ index + 1 }}</h3>
                <p class="muted">ID в базе: {{ application.id }}</p>
              </div>

              <div class="application-header-actions">
                <span class="status">{{ translateStatus(application.status) }}</span>

                <button
                  type="button"
                  class="secondary-button small-button"
                  @click="toggleApplication(application.id)"
                >
                  {{ isApplicationExpanded(application.id) ? 'Свернуть' : 'Раскрыть' }}
                </button>
              </div>
            </div>

            <div class="application-summary">
              <span><b>Кампания:</b> {{ application.admissionCampaignName }}</span>
              <span><b>Подано:</b> {{ formatDate(application.submittedAt) }}</span>
              <span><b>Приоритетов:</b> {{ application.priorities.length }}</span>
            </div>

            <div v-if="isApplicationExpanded(application.id)" class="application-details">
              <p><b>Создано:</b> {{ formatDate(application.createdAt) }}</p>
              <p v-if="isApplicationLocked(application)" class="lock-warning">
                <b>Заблокировано до:</b> {{ formatDate(application.lockedUntil) }}
              </p>

              <p v-if="isApplicationLocked(application)" class="error">
                Заявление временно нельзя редактировать.
              </p>

              <p v-if="isFinalStatus(application.status)" class="muted">
                Заявление находится в финальном статусе и не может быть изменено абитуриентом.
              </p>

              <p v-if="application.comment">
                <b>Комментарий:</b> {{ application.comment }}
              </p>

              <h4>Приоритеты</h4>

              <ol>
                <li v-for="priority in application.priorities" :key="priority.id">
                  {{ priority.programCode }} {{ priority.programName }}
                </li>
              </ol>
              <div class="button-row">
                <button type="button" class="secondary-button" @click="startEdit(application)"
                  :disabled="!canEditApplication(application)">
                  Редактировать
                </button>

                <button v-if="application.status === 'DRAFT'" type="button"
                  :disabled="submittingApplicationId === application.id"
                  @click="submitApplication(application)">
                  {{ submittingApplicationId === application.id ? 'Подача...' : 'Подать заявление' }}
                </button>

                <button v-if="canWithdrawApplication(application)" type="button" class="danger-button"
                  :disabled="withdrawingApplicationId === application.id" @click="withdrawApplication(application)">
                  {{
                    withdrawingApplicationId === application.id
                      ? 'Отзыв...'
                      : 'Отозвать заявление'
                  }}
                </button>
              </div>
            </div>
          </div>
        </div>

        <p v-else-if="!loading">Заявления пока не поданы.</p>
      </div>
    </div>
  </section>
</template>

<script>
import http from '@/shared/api/http'
import { getSession } from '@/shared/lib/session'

export default {
  name: 'ApplicationsPage',

  data() {
    const session = getSession()

    return {
      applicantId: session.applicantId,
      campaigns: [],
      programs: [],
      applications: [],
      expandedApplicationIds: [],
      form: {
        admissionCampaignId: '',
        priorities: [
          {
            programId: ''
          }
        ],
        comment: ''
      },
      editingApplicationId: null,
      editForm: {
        admissionCampaignId: '',
        priorities: [
          {
            programId: ''
          }
        ],
        comment: ''
      },
      loading: false,
      saving: false,
      updating: false,
      submittingApplicationId: null,
      withdrawingApplicationId: null,
      message: '',
      error: ''
    }
  },

  computed: {
    availableCreatePrograms() {
      if (!this.form.admissionCampaignId) {
        return this.programs
      }

      return this.programs.filter(
        program => program.admissionCampaignId === this.form.admissionCampaignId
      )
    },

    availableEditPrograms() {
      if (!this.editForm.admissionCampaignId) {
        return this.programs
      }

      return this.programs.filter(
        program => program.admissionCampaignId === this.editForm.admissionCampaignId
      )
    }
  },

  async mounted() {
    if (!this.applicantId) {
      return
    }

    await this.loadInitialData()
  },

  methods: {
    async loadInitialData() {
      this.loading = true
      this.error = ''

      try {
        await Promise.all([
          this.loadCampaigns(),
          this.loadPrograms(),
          this.loadApplications()
        ])
      } finally {
        this.loading = false
      }
    },

    async loadCampaigns() {
      try {
        const response = await http.get('/admission-campaigns/active')
        this.campaigns = response.data

        if (this.campaigns.length > 0 && !this.form.admissionCampaignId) {
          this.form.admissionCampaignId = this.campaigns[0].id
        }
      } catch (error) {
        this.error = error.response?.data?.message || 'Не удалось загрузить приёмные кампании'
      }
    },

    async loadPrograms() {
      try {
        const response = await http.get('/programs')
        this.programs = response.data
      } catch (error) {
        this.error = error.response?.data?.message || 'Не удалось загрузить направления'
      }
    },

    async loadApplications() {
      try {
        const response = await http.get(`/applicants/${this.applicantId}/applications`)
        this.applications = response.data
      } catch (error) {
        this.error = error.response?.data?.message || 'Не удалось загрузить заявления'
      }
    },

    addCreatePriority() {
      if (this.form.priorities.length >= 5) {
        return
      }

      this.form.priorities.push({
        programId: ''
      })
    },

    removeCreatePriority(index) {
      if (this.form.priorities.length === 1) {
        return
      }

      this.form.priorities.splice(index, 1)
    },

    addEditPriority() {
      if (this.editForm.priorities.length >= 5) {
        return
      }

      this.editForm.priorities.push({
        programId: ''
      })
    },

    removeEditPriority(index) {
      if (this.editForm.priorities.length === 1) {
        return
      }

      this.editForm.priorities.splice(index, 1)
    },

    isApplicationExpanded(applicationId) {
      return this.expandedApplicationIds.includes(applicationId)
    },

    toggleApplication(applicationId) {
      if (this.isApplicationExpanded(applicationId)) {
        this.expandedApplicationIds = this.expandedApplicationIds.filter(id => id !== applicationId)
        return
      }

      this.expandedApplicationIds = [...this.expandedApplicationIds, applicationId]
    },

    async createApplication(submit = true) {
      this.message = ''
      this.error = ''

      const validationError = this.validateApplicationForm(
        this.form.admissionCampaignId,
        this.form.priorities
      )

      if (validationError) {
        this.error = validationError
        return
      }

      const request = {
        admissionCampaignId: this.form.admissionCampaignId,
        priorities: this.form.priorities.map((priority, index) => ({
          programId: priority.programId,
          priorityNumber: index + 1
        })),
        comment: this.form.comment,
        submit
      }

      this.saving = true

      try {
        await http.post(`/applicants/${this.applicantId}/applications`, request)

        this.message = submit
          ? 'Заявление успешно подано'
          : 'Черновик заявления сохранён'

        this.form.priorities = [
          {
            programId: ''
          }
        ]
        this.form.comment = ''

        await this.loadApplications()
      } catch (error) {
        this.error = error.response?.data?.message || 'Не удалось подать заявление'
      } finally {
        this.saving = false
      }
    },

    startEdit(application) {
      this.message = ''
      this.error = ''

      if (!this.canEditApplication(application)) {
        this.error = 'Это заявление сейчас нельзя редактировать'
        return
      }

      this.editingApplicationId = application.id

      this.editForm = {
        admissionCampaignId: application.admissionCampaignId,
        priorities: application.priorities.map(priority => ({
          programId: priority.programId
        })),
        comment: application.comment || ''
      }

      window.scrollTo({
        top: 0,
        behavior: 'smooth'
      })
    },

    cancelEdit() {
      this.editingApplicationId = null
      this.editForm = {
        admissionCampaignId: '',
        priorities: [
          {
            programId: ''
          }
        ],
        comment: ''
      }
    },

    async updateApplication() {
      this.message = ''
      this.error = ''

      const validationError = this.validateApplicationForm(
        this.editForm.admissionCampaignId,
        this.editForm.priorities
      )

      if (validationError) {
        this.error = validationError
        return
      }

      const request = {
        priorities: this.editForm.priorities.map((priority, index) => ({
          programId: priority.programId,
          priorityNumber: index + 1
        })),
        comment: this.editForm.comment
      }

      this.updating = true

      try {
        await http.put(
          `/applicants/${this.applicantId}/applications/${this.editingApplicationId}`,
          request
        )

        this.message = 'Заявление успешно изменено'

        this.cancelEdit()
        await this.loadApplications()
      } catch (error) {
        this.error = error.response?.data?.message || 'Не удалось изменить заявление'
      } finally {
        this.updating = false
      }
    },

    validateApplicationForm(admissionCampaignId, priorities) {
      if (!admissionCampaignId) {
        return 'Выберите приёмную кампанию'
      }

      const hasEmptyProgram = priorities.some(priority => !priority.programId)

      if (hasEmptyProgram) {
        return 'Выберите направления для всех приоритетов'
      }

      const programIds = priorities.map(priority => priority.programId)
      const uniqueProgramIds = new Set(programIds)

      if (programIds.length !== uniqueProgramIds.size) {
        return 'Одно направление нельзя выбрать несколько раз'
      }

      return ''
    },

    isApplicationLocked(application) {
      if (!application.lockedUntil) {
        return false
      }

      return new Date() < new Date(application.lockedUntil)
    },

    isFinalStatus(status) {
      return ['APPROVED', 'REJECTED', 'WITHDRAWN'].includes(status)
    },

    translateStatus(status) {
      const statuses = {
        DRAFT: 'Черновик',
        SUBMITTED: 'Подано',
        UNDER_REVIEW: 'На проверке',
        APPROVED: 'Принято',
        REJECTED: 'Отклонено',
        WITHDRAWN: 'Отозвано'
      }

      return statuses[status] || status
    },

    canEditApplication(application) {
      return !this.isApplicationLocked(application)
        && !this.isFinalStatus(application.status)
    },

    canWithdrawApplication(application) {
      return ['SUBMITTED', 'UNDER_REVIEW'].includes(application.status)
        && !this.isApplicationLocked(application)
    },

    async submitApplication(application) {
      this.message = ''
      this.error = ''
      this.submittingApplicationId = application.id

      try {
        await http.patch(
          `/applicants/${this.applicantId}/applications/${application.id}/submit`
        )

        this.message = `Заявление №${application.id} подано`
        await this.loadApplications()
      } catch (error) {
        this.error = error.response?.data?.message || 'Не удалось подать заявление'
      } finally {
        this.submittingApplicationId = null
      }
    },

    async withdrawApplication(application) {
      const confirmed = window.confirm(
        `Отозвать заявление №${application.id}? После отзыва оно исчезнет из рейтинга.`
      )

      if (!confirmed) {
        return
      }

      this.message = ''
      this.error = ''
      this.withdrawingApplicationId = application.id

      try {
        await http.patch(
          `/applicants/${this.applicantId}/applications/${application.id}/withdraw`
        )

        this.message = `Заявление №${application.id} отозвано`

        if (this.editingApplicationId === application.id) {
          this.cancelEdit()
        }

        await this.loadApplications()
      } catch (error) {
        this.error = error.response?.data?.message || 'Не удалось отозвать заявление'
      } finally {
        this.withdrawingApplicationId = null
      }
    },
    formatDate(value) {
      if (!value) {
        return '—'
      }

      return new Date(value).toLocaleString('ru-RU')
    }
  }
}
</script>
