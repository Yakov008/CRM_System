<template>
  <section>
    <h1>Личный кабинет</h1>

    <div v-if="loading" class="card">
      <p>Загрузка данных...</p>
    </div>

    <div v-else-if="!isLoggedIn" class="card">
      <p>Вы не вошли в систему.</p>
      <RouterLink to="/login">Перейти ко входу</RouterLink>
    </div>

    <div v-else>
      <div class="card">
        <div class="profile-header">
          <div>
            <h2>{{ pageTitle }}</h2>
            <p class="muted">{{ email }}</p>
          </div>

          <span class="status">{{ translateRole(role) }}</span>
        </div>
      </div>

      <div v-if="isApplicant" class="cards cabinet-grid">
        <div class="card">
          <h2>Профиль абитуриента</h2>

          <p><b>ID абитуриента:</b> {{ applicantId }}</p>
          <p><b>ФИО:</b> {{ fullName }}</p>
          <p><b>Дата рождения:</b> {{ formatDate(applicant.birthDate) }}</p>
          <p><b>Телефон:</b> {{ applicant.phone || '—' }}</p>
          <p><b>Паспорт:</b> {{ applicant.passportNumber || '—' }}</p>
          <p><b>Баллы за достижения:</b> {{ applicant.achievementsScore ?? 0 }}</p>
        </div>

        <div class="card">
          <h2>Сводка</h2>

          <div class="stats-grid">
            <div class="stat-card">
              <div class="stat-value">{{ examResults.length }}</div>
              <div class="stat-label">результатов ЕГЭ</div>
            </div>

            <div class="stat-card">
              <div class="stat-value">{{ applications.length }}</div>
              <div class="stat-label">заявлений</div>
            </div>

            <div class="stat-card">
              <div class="stat-value">{{ submittedApplicationsCount }}</div>
              <div class="stat-label">поданных</div>
            </div>

            <div class="stat-card">
              <div class="stat-value">{{ approvedApplicationsCount }}</div>
              <div class="stat-label">принятых</div>
            </div>
          </div>
        </div>
      </div>

      <div v-if="isApplicant" class="card">
        <h2>Быстрые действия</h2>

        <div class="quick-actions">
          <RouterLink class="action-link" to="/exam-results">
            Добавить результаты ЕГЭ
          </RouterLink>

          <RouterLink class="action-link" to="/applications">
            Подать или изменить заявление
          </RouterLink>

          <RouterLink class="action-link" to="/documents">
            Загрузить документы
          </RouterLink>

          <RouterLink class="action-link" to="/rankings">
            Посмотреть рейтинг
          </RouterLink>
        </div>
      </div>

      <div v-if="isApplicant" class="card">
        <h2>Последние заявления</h2>

        <table v-if="applications.length > 0" class="table">
          <thead>
            <tr>
              <th>ID</th>
              <th>Кампания</th>
              <th>Статус</th>
              <th>Подано</th>
              <th>Блокировка</th>
            </tr>
          </thead>

          <tbody>
            <tr v-for="application in latestApplications" :key="application.id">
              <td>{{ application.id }}</td>
              <td>{{ application.admissionCampaignName }}</td>
              <td>
                <span class="status">
                  {{ translateApplicationStatus(application.status) }}
                </span>
              </td>
              <td>{{ formatDateTime(application.submittedAt) }}</td>
              <td>{{ formatDateTime(application.lockedUntil) }}</td>
            </tr>
          </tbody>
        </table>

        <p v-else>Заявления пока не поданы.</p>
      </div>

      <div v-if="isOfficerOrAdmin" class="card">
        <h2>Служебные разделы</h2>

        <div class="quick-actions">
          <RouterLink
            v-if="isOfficerOrAdmin"
            class="action-link"
            to="/officer/applications"
          >
            Проверка заявлений
          </RouterLink>

          <RouterLink
            v-if="isOfficerOrAdmin"
            class="action-link"
            to="/officer/documents"
          >
            Проверка документов
          </RouterLink>

          <RouterLink
            v-if="isAdmin"
            class="action-link"
            to="/admin/campaigns"
          >
            Управление кампаниями
          </RouterLink>

          <RouterLink
            v-if="isAdmin"
            class="action-link"
            to="/admin/programs"
          >
            Управление направлениями
          </RouterLink>

          <RouterLink
            v-if="isAdmin"
            class="action-link"
            to="/admin/program-requirements"
          >
            Требования ЕГЭ
          </RouterLink>
        </div>
      </div>

      <p v-if="error" class="error">{{ error }}</p>
    </div>
  </section>
</template>

<script>
import http from '@/shared/api/http'
import { USER_ROLES } from '@/shared/constants/roles'
import { getSession, saveAuthSession } from '@/shared/lib/session'

export default {
  name: 'ApplicantHomePage',

  data() {
    const session = getSession()

    return {
      userId: session.userId,
      applicantId: session.applicantId,
      email: session.email,
      role: session.role,
      applicant: {},
      examResults: [],
      applications: [],
      loading: false,
      error: ''
    }
  },

  computed: {
    isLoggedIn() {
      return Boolean(this.role)
    },

    isApplicant() {
      return this.role === USER_ROLES.APPLICANT
    },

    isOfficerOrAdmin() {
      return this.role === USER_ROLES.OFFICER || this.role === USER_ROLES.ADMIN
    },

    isAdmin() {
      return this.role === USER_ROLES.ADMIN
    },

    pageTitle() {
      if (this.isApplicant) {
        return 'Кабинет абитуриента'
      }

      if (this.role === USER_ROLES.OFFICER) {
        return 'Кабинет сотрудника приёмной комиссии'
      }

      if (this.role === USER_ROLES.ADMIN) {
        return 'Кабинет администратора'
      }

      return 'Личный кабинет'
    },

    fullName() {
      const lastName = this.applicant.lastName || ''
      const firstName = this.applicant.firstName || ''
      const middleName = this.applicant.middleName || ''

      const result = `${lastName} ${firstName} ${middleName}`.trim()

      return result || '—'
    },

    submittedApplicationsCount() {
      return this.applications.filter(application =>
        ['SUBMITTED', 'UNDER_REVIEW', 'APPROVED'].includes(application.status)
      ).length
    },

    approvedApplicationsCount() {
      return this.applications.filter(application =>
        application.status === 'APPROVED'
      ).length
    },

    latestApplications() {
      return [...this.applications]
        .sort((first, second) => second.id - first.id)
        .slice(0, 5)
    }
  },

  async mounted() {
    await this.loadCabinet()
  },

  methods: {
    async loadCabinet() {
      this.loading = true
      this.error = ''

      try {
        await this.loadCurrentUser()

        if (this.isApplicant && this.applicantId) {
          await Promise.all([
            this.loadApplicant(),
            this.loadExamResults(),
            this.loadApplications()
          ])
        }
      } catch (error) {
        this.error = error.response?.data?.message || 'Не удалось загрузить кабинет'
      } finally {
        this.loading = false
      }
    },

    async loadCurrentUser() {
      const response = await http.get('/auth/me')

      this.userId = response.data.userId
      this.applicantId = response.data.applicantId
      this.email = response.data.email
      this.role = response.data.role

      saveAuthSession(response.data)
    },

    async loadApplicant() {
      const response = await http.get(`/applicants/${this.applicantId}`)
      this.applicant = response.data
    },

    async loadExamResults() {
      const response = await http.get(`/applicants/${this.applicantId}/exam-results`)
      this.examResults = response.data
    },

    async loadApplications() {
      const response = await http.get(`/applicants/${this.applicantId}/applications`)
      this.applications = response.data
    },

    translateRole(role) {
      const roles = {
        APPLICANT: 'Абитуриент',
        OFFICER: 'Сотрудник',
        ADMIN: 'Администратор'
      }

      return roles[role] || role
    },

    translateApplicationStatus(status) {
      const statuses = {
        DRAFT: 'Черновик',
        SUBMITTED: 'Подано',
        UNDER_REVIEW: 'На проверке',
        APPROVED: 'Принято',
        REJECTED: 'Отклонено',
        WITHDRAWN: 'Отозвано'
      }

      return statuses[status] || status
    },

    formatDate(value) {
      if (!value) {
        return '—'
      }

      return new Date(value).toLocaleDateString('ru-RU')
    },

    formatDateTime(value) {
      if (!value) {
        return '—'
      }

      return new Date(value).toLocaleString('ru-RU')
    }
  }
}
</script>
