<template>
  <section>
    <h1>Проверка заявлений</h1>

    <div class="card">
      <h2>Фильтр</h2>

      <div class="filter-row">
        <select v-model="selectedStatus">
          <option value="">Все заявления</option>
          <option value="DRAFT">Черновики</option>
          <option value="SUBMITTED">Поданные</option>
          <option value="UNDER_REVIEW">На проверке</option>
          <option value="APPROVED">Принятые</option>
          <option value="REJECTED">Отклонённые</option>
          <option value="WITHDRAWN">Отозванные</option>
        </select>

        <button type="button" @click="loadApplications">
          Применить
        </button>
      </div>

      <p v-if="error" class="error">{{ error }}</p>
      <p v-if="message" class="success">{{ message }}</p>
    </div>

    <div v-if="selectedDetails" class="card edit-card">
      <div class="application-header">
        <h2>Подробная проверка заявления №{{ selectedDetails.application.id }}</h2>

        <button type="button" class="secondary-button small-button" @click="selectedDetails = null">
          Закрыть
        </button>
      </div>

      <h3>Абитуриент</h3>

      <p><b>ФИО:</b> {{ buildFullName(selectedDetails.applicant) }}</p>
      <p><b>Email:</b> {{ selectedDetails.applicant.email }}</p>
      <p><b>Дата рождения:</b> {{ formatDate(selectedDetails.applicant.birthDate) }}</p>
      <p><b>Телефон:</b> {{ selectedDetails.applicant.phone || '—' }}</p>
      <p><b>Паспорт:</b> {{ selectedDetails.applicant.passportNumber || '—' }}</p>
      <p><b>Баллы достижений:</b> {{ selectedDetails.applicant.achievementsScore ?? 0 }}</p>

      <h3>Приоритеты заявления</h3>

      <ol>
        <li v-for="priority in selectedDetails.application.priorities" :key="priority.id">
          {{ priority.programCode }} {{ priority.programName }}
        </li>
      </ol>

      <h3>Результаты ЕГЭ</h3>

      <table v-if="selectedDetails.examResults.length > 0" class="table">
        <thead>
          <tr>
            <th>Предмет</th>
            <th>Год</th>
            <th>Балл</th>
          </tr>
        </thead>

        <tbody>
          <tr v-for="result in selectedDetails.examResults" :key="result.id">
            <td>{{ result.examSubjectName }}</td>
            <td>{{ result.examYear }}</td>
            <td>{{ result.score }}</td>
          </tr>
        </tbody>
      </table>

      <p v-else>Результаты ЕГЭ не добавлены.</p>

      <h3>Документы</h3>

      <div v-if="selectedDetails.documents.length > 0" class="officer-documents-table-wrapper">
        <table class="table officer-documents-table">
          <thead>
            <tr>
              <th>Тип</th>
              <th>Файл</th>
              <th>Статус</th>
              <th>Комментарий</th>
              <th>Действие</th>
            </tr>
          </thead>

          <tbody>
            <tr v-for="document in selectedDetails.documents" :key="document.id">
              <td>{{ translateDocumentType(document.documentType) }}</td>
              <td>
                <div class="file-name-scroll" :title="document.fileName">
                  {{ document.fileName }}
                </div>
              </td>
              <td>
                <span class="status">
                  {{ translateDocumentStatus(document.status) }}
                </span>
              </td>
              <td>{{ document.comment || '—' }}</td>
              <td>
                <button type="button" class="secondary-button small-button" @click="downloadDocument(document)">
                  Скачать
                </button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>

      <p v-else>Документы не загружены.</p>
    </div>

    <div class="card">
      <h2>Список заявлений</h2>

      <p v-if="loading">Загрузка...</p>

      <div v-if="applications.length > 0" class="application-list">
        <div v-for="application in applications" :key="application.id" class="application-card">
          <div class="application-header">
            <h3>Заявление №{{ application.id }}</h3>
            <span class="status">{{ translateStatus(application.status) }}</span>
          </div>

          <p><b>ID абитуриента:</b> {{ application.applicantId }}</p>
          <p><b>Абитуриент:</b> {{ application.applicantFullName || '—' }}</p>
          <p><b>Баллы за достижения:</b> {{ application.achievementsScore }}</p>
          <p><b>Кампания:</b> {{ application.admissionCampaignName }}</p>
          <p><b>Создано:</b> {{ formatDate(application.createdAt) }}</p>
          <p><b>Подано:</b> {{ formatDate(application.submittedAt) }}</p>
          <p><b>Заблокировано до:</b> {{ formatDate(application.lockedUntil) }}</p>

          <p v-if="application.comment">
            <b>Комментарий:</b> {{ application.comment }}
          </p>

          <h4>Приоритеты</h4>

          <ol>
            <li v-for="priority in application.priorities" :key="priority.id">
              {{ priority.programCode }} {{ priority.programName }}
            </li>
          </ol>

          <div class="status-edit">
            <h4>Индивидуальные достижения</h4>

            <input v-model.number="achievementsForms[application.applicantId].achievementsScore" type="number" min="0"
              max="10" placeholder="Баллы от 0 до 10" />

            <button type="button" :disabled="updatingAchievementsApplicantId === application.applicantId"
              @click="updateAchievements(application.applicantId)">
              {{
                updatingAchievementsApplicantId === application.applicantId
                  ? 'Сохранение...'
                  : 'Сохранить баллы'
              }}
            </button>
          </div>

          <div class="status-edit">
            <h4>Изменить статус</h4>

            <select v-model="statusForms[application.id].status">
              <option value="SUBMITTED">Подано</option>
              <option value="UNDER_REVIEW">На проверке</option>
              <option value="APPROVED">Принято</option>
              <option value="REJECTED">Отклонено</option>
              <option value="WITHDRAWN">Отозвано</option>
            </select>

            <textarea v-model="statusForms[application.id].comment" rows="3"
              placeholder="Комментарий сотрудника"></textarea>

            <button type="button" :disabled="updatingApplicationId === application.id"
              @click="updateStatus(application.id)">
              {{
                updatingApplicationId === application.id
                  ? 'Сохранение...'
                  : 'Сохранить статус'
              }}
            </button>

            <button type="button" class="secondary-button" :disabled="loadingDetailsApplicationId === application.id"
              @click="loadApplicationDetails(application.id)">
              {{
                loadingDetailsApplicationId === application.id
                  ? 'Загрузка...'
                  : 'Подробнее'
              }}
            </button>

          </div>
        </div>
      </div>

      <p v-else-if="!loading">Заявления не найдены.</p>
    </div>
  </section>
</template>

<script>
import http from '@/shared/api/http'

export default {
  name: 'OfficerApplicationsPage',

  data() {
    return {
      selectedStatus: '',
      applications: [],
      statusForms: {},
      achievementsForms: {},
      selectedDetails: null,
      loading: false,
      loadingDetailsApplicationId: null,
      updatingApplicationId: null,
      updatingAchievementsApplicantId: null,
      message: '',
      error: ''
    }
  },

  async mounted() {
    await this.loadApplications()
  },

  methods: {
    async loadApplicationDetails(applicationId) {
      this.error = ''
      this.loadingDetailsApplicationId = applicationId

      try {
        const response = await http.get(`/applications/${applicationId}/details`)
        this.selectedDetails = response.data

        window.scrollTo({
          top: 0,
          behavior: 'smooth'
        })
      } catch (error) {
        this.error = error.response?.data?.message || 'Не удалось загрузить подробности заявления'
      } finally {
        this.loadingDetailsApplicationId = null
      }
    },

    buildFullName(applicant) {
      const lastName = applicant.lastName || ''
      const firstName = applicant.firstName || ''
      const middleName = applicant.middleName || ''

      return `${lastName} ${firstName} ${middleName}`.trim() || '—'
    },

    translateDocumentType(type) {
      const types = {
        PASSPORT: 'Паспорт',
        EDUCATION_CERTIFICATE: 'Документ об образовании',
        CONSENT: 'Согласие на зачисление',
        OTHER: 'Другое'
      }

      return types[type] || type
    },

    translateDocumentStatus(status) {
      const statuses = {
        UPLOADED: 'Загружен',
        VERIFIED: 'Проверен',
        REJECTED: 'Отклонён'
      }

      return statuses[status] || status
    },

    async downloadDocument(doc) {
      this.error = ''

      try {
        const response = await http.get(`/documents/${doc.id}/download`, {
          responseType: 'blob'
        })

        const url = window.URL.createObjectURL(new Blob([response.data]))
        const link = window.document.createElement('a')

        link.href = url
        link.download = doc.fileName || 'document'
        window.document.body.appendChild(link)

        link.click()
        link.remove()

        window.URL.revokeObjectURL(url)
      } catch (error) {
        this.error = error.response?.data?.message || 'Не удалось скачать документ'
      }
    },
    async loadApplications() {
      this.loading = true
      this.message = ''
      this.error = ''

      try {
        const url = this.selectedStatus
          ? `/applications?status=${this.selectedStatus}`
          : '/applications'

        const response = await http.get(url)

        this.applications = response.data
        this.prepareStatusForms()
        this.prepareAchievementsForms()
      } catch (error) {
        this.error = error.response?.data?.message || 'Не удалось загрузить заявления'
      } finally {
        this.loading = false
      }
    },

    prepareStatusForms() {
      const forms = {}

      this.applications.forEach(application => {
        forms[application.id] = {
          status: application.status,
          comment: application.comment || ''
        }
      })

      this.statusForms = forms
    },

    prepareAchievementsForms() {
      const forms = {}

      this.applications.forEach(application => {
        forms[application.applicantId] = {
          achievementsScore: application.achievementsScore ?? 0
        }
      })

      this.achievementsForms = forms
    },

    async updateStatus(applicationId) {
      this.message = ''
      this.error = ''
      this.updatingApplicationId = applicationId

      const form = this.statusForms[applicationId]

      try {
        await http.patch(`/applications/${applicationId}/status`, {
          status: form.status,
          comment: form.comment
        })

        this.message = `Статус заявления №${applicationId} обновлён`

        await this.loadApplications()
      } catch (error) {
        this.error = error.response?.data?.message || 'Не удалось изменить статус заявления'
      } finally {
        this.updatingApplicationId = null
      }
    },

    translateStatus(status) {
      const statuses = {
        DRAFT: 'Черновик',
        SUBMITTED: 'Подано',
        UNDER_REVIEW: 'На проверке',
        APPROVED: 'Принято',
        REJECTED: 'Отклонено',
        WITHDRAWN: 'Отозвано'
      }

      return statuses[status] || status
    },

    async updateAchievements(applicantId) {
      this.message = ''
      this.error = ''
      this.updatingAchievementsApplicantId = applicantId

      const form = this.achievementsForms[applicantId]

      if (form.achievementsScore < 0 || form.achievementsScore > 10) {
        this.error = 'Баллы за достижения должны быть от 0 до 10'
        this.updatingAchievementsApplicantId = null
        return
      }

      try {
        await http.patch(`/officer/applicants/${applicantId}/achievements`, {
          achievementsScore: form.achievementsScore
        })

        this.message = `Баллы за достижения абитуриента №${applicantId} обновлены`

        await this.loadApplications()
      } catch (error) {
        this.error = error.response?.data?.message || 'Не удалось обновить баллы за достижения'
      } finally {
        this.updatingAchievementsApplicantId = null
      }
    },

    formatDate(value) {
      if (!value) {
        return '—'
      }

      return new Date(value).toLocaleString('ru-RU')
    }
  }
}
</script>