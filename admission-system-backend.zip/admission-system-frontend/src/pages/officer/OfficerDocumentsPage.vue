<template>
  <section>
    <h1>Проверка документов</h1>

    <div class="content-with-sidebar">
      <aside class="filter-sidebar card">
        <h2>Фильтр</h2>

        <label>
          Статус документа
          <select v-model="selectedStatus">
            <option value="UPLOADED">Загруженные</option>
            <option value="VERIFIED">Проверенные</option>
            <option value="REJECTED">Отклонённые</option>
          </select>
        </label>

        <button type="button" class="full-width-button" @click="loadDocuments">
          Применить
        </button>

        <p v-if="message" class="success">{{ message }}</p>
        <p v-if="error" class="error">{{ error }}</p>
      </aside>

      <div class="content-main">
        <div class="card">
          <h2>Список документов</h2>

          <p v-if="loading">Загрузка...</p>

          <div v-if="documents.length > 0" class="officer-documents-table-wrapper">
            <table class="table officer-review-documents-table">
              <thead>
                <tr>
                  <th>
                    <button type="button" class="sort-button" @click="setSort('id')">
                      ID {{ sortIndicator('id') }}
                    </button>
                  </th>
                  <th>
                    <button type="button" class="sort-button" @click="setSort('applicationId')">
                      Заявление {{ sortIndicator('applicationId') }}
                    </button>
                  </th>
                  <th>
                    <button type="button" class="sort-button" @click="setSort('documentType')">
                      Тип {{ sortIndicator('documentType') }}
                    </button>
                  </th>
                  <th>
                    <button type="button" class="sort-button" @click="setSort('fileName')">
                      Файл {{ sortIndicator('fileName') }}
                    </button>
                  </th>
                  <th>
                    <button type="button" class="sort-button" @click="setSort('uploadedAt')">
                      Загружен {{ sortIndicator('uploadedAt') }}
                    </button>
                  </th>
                  <th>
                    <button type="button" class="sort-button" @click="setSort('status')">
                      Статус {{ sortIndicator('status') }}
                    </button>
                  </th>
                  <th>
                    <button type="button" class="sort-button" @click="setSort('comment')">
                      Комментарий {{ sortIndicator('comment') }}
                    </button>
                  </th>
                  <th>Действия</th>
                </tr>
              </thead>

              <tbody>
                <tr v-for="document in sortedDocuments" :key="document.id">
                  <td>{{ document.id }}</td>
                  <td>№{{ document.applicationId }}</td>
                  <td>{{ translateDocumentType(document.documentType) }}</td>
                  <td>
                    <div class="file-name-scroll compact-file-name" :title="document.fileName">
                      {{ document.fileName }}
                    </div>
                  </td>
                  <td>{{ formatDate(document.uploadedAt) }}</td>
                  <td>
                    <select
                      v-model="documentForms[document.id].status"
                      class="compact-control"
                    >
                      <option value="UPLOADED">Загружен</option>
                      <option value="VERIFIED">Проверен</option>
                      <option value="REJECTED">Отклонён</option>
                    </select>
                  </td>
                  <td>
                    <textarea
                      v-model="documentForms[document.id].comment"
                      class="compact-control"
                      rows="2"
                      placeholder="Комментарий"
                    ></textarea>
                  </td>
                  <td>
                    <div class="document-actions">
                      <button
                        type="button"
                        class="small-button"
                        :disabled="updatingDocumentId === document.id"
                        @click="updateDocumentStatus(document.id)"
                      >
                        {{
                          updatingDocumentId === document.id
                            ? '...'
                            : 'Сохранить'
                        }}
                      </button>

                      <button
                        type="button"
                        class="secondary-button small-button"
                        @click="downloadDocument(document)"
                      >
                        Скачать
                      </button>
                    </div>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>

          <p v-else-if="!loading">Документы не найдены.</p>
        </div>
      </div>
    </div>
  </section>
</template>

<script>
import http from '@/shared/api/http'
import { sortByColumn } from '@/shared/lib/sort'

export default {
  name: 'OfficerDocumentsPage',

  data() {
    return {
      selectedStatus: 'UPLOADED',
      documents: [],
      documentForms: {},
      sortKey: 'id',
      sortDirection: 'asc',
      loading: false,
      updatingDocumentId: null,
      message: '',
      error: ''
    }
  },

  async mounted() {
    await this.loadDocuments()
  },

  computed: {
    sortedDocuments() {
      return sortByColumn(this.documents, this.sortKey, this.sortDirection)
    }
  },

  methods: {
    async loadDocuments() {
      this.loading = true
      this.message = ''
      this.error = ''

      try {
        const response = await http.get(`/documents?status=${this.selectedStatus}`)

        this.documents = response.data
        this.prepareDocumentForms()
      } catch (error) {
        this.error = error.response?.data?.message || 'Не удалось загрузить документы'
      } finally {
        this.loading = false
      }
    },

    prepareDocumentForms() {
      const forms = {}

      this.documents.forEach(document => {
        forms[document.id] = {
          status: document.status,
          comment: document.comment || ''
        }
      })

      this.documentForms = forms
    },

    async updateDocumentStatus(documentId) {
      this.message = ''
      this.error = ''
      this.updatingDocumentId = documentId

      const form = this.documentForms[documentId]

      try {
        await http.patch(`/documents/${documentId}/status`, {
          status: form.status,
          comment: form.comment
        })

        this.message = `Статус документа №${documentId} обновлён`

        await this.loadDocuments()
      } catch (error) {
        this.error = error.response?.data?.message || 'Не удалось изменить статус документа'
      } finally {
        this.updatingDocumentId = null
      }
    },

    async downloadDocument(doc) {
      this.error = ''

      try {
        const response = await http.get(`/documents/${doc.id}/download`, {
          responseType: 'blob'
        })

        const url = window.URL.createObjectURL(new Blob([response.data]))
        const link = window.document.createElement('a')

        link.href = url
        link.download = doc.fileName || 'document'
        window.document.body.appendChild(link)

        link.click()
        link.remove()

        window.URL.revokeObjectURL(url)
      } catch (error) {
        this.error = error.response?.data?.message || 'Не удалось скачать документ'
      }
    },

    translateDocumentType(type) {
      const types = {
        PASSPORT: 'Паспорт',
        EDUCATION_CERTIFICATE: 'Документ об образовании',
        CONSENT: 'Согласие на зачисление',
        OTHER: 'Другое'
      }

      return types[type] || type
    },

    formatDate(value) {
      if (!value) {
        return '—'
      }

      return new Date(value).toLocaleString('ru-RU')
    },

    setSort(key) {
      if (this.sortKey === key) {
        this.sortDirection = this.sortDirection === 'asc' ? 'desc' : 'asc'
        return
      }

      this.sortKey = key
      this.sortDirection = 'asc'
    },

    sortIndicator(key) {
      if (this.sortKey !== key) {
        return ''
      }

      return this.sortDirection === 'asc' ? '↑' : '↓'
    }
  }
}
</script>
