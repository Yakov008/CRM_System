<template>
  <section>
    <h1>Проверка документов</h1>

    <div class="card">
      <h2>Фильтр документов</h2>

      <div class="filter-row">
        <select v-model="selectedStatus">
          <option value="UPLOADED">Загруженные</option>
          <option value="VERIFIED">Проверенные</option>
          <option value="REJECTED">Отклонённые</option>
        </select>

        <button type="button" @click="loadDocuments">
          Применить
        </button>
      </div>

      <p v-if="message" class="success">{{ message }}</p>
      <p v-if="error" class="error">{{ error }}</p>
    </div>

    <div class="card">
      <h2>Список документов</h2>

      <p v-if="loading">Загрузка...</p>

      <div v-if="documents.length > 0" class="application-list">
        <div
          v-for="document in documents"
          :key="document.id"
          class="application-card"
        >
          <div class="application-header">
            <h3>Документ №{{ document.id }}</h3>
            <span class="status">{{ translateDocumentStatus(document.status) }}</span>
          </div>

          <p><b>ID заявления:</b> {{ document.applicationId }}</p>
          <p><b>Тип:</b> {{ translateDocumentType(document.documentType) }}</p>
          <p><b>Имя файла:</b> {{ document.fileName }}</p>
          <p><b>Путь к файлу:</b> {{ document.filePath }}</p>
          <p><b>Загружен:</b> {{ formatDate(document.uploadedAt) }}</p>

          <p v-if="document.comment">
            <b>Комментарий:</b> {{ document.comment }}
          </p>

          <div class="status-edit">
            <h4>Результат проверки</h4>

            <select v-model="documentForms[document.id].status">
              <option value="UPLOADED">Загружен</option>
              <option value="VERIFIED">Проверен</option>
              <option value="REJECTED">Отклонён</option>
            </select>

            <textarea
              v-model="documentForms[document.id].comment"
              rows="3"
              placeholder="Комментарий сотрудника"
            ></textarea>

            <button
              type="button"
              :disabled="updatingDocumentId === document.id"
              @click="updateDocumentStatus(document.id)"
            >
              {{
                updatingDocumentId === document.id
                  ? 'Сохранение...'
                  : 'Сохранить статус'
              }}
            </button>
            <button
              type="button"
              class="secondary-button small-button"
              @click="downloadDocument(document)"
            >
              Скачать файл
            </button>
          </div>
        </div>
      </div>

      <p v-else-if="!loading">Документы не найдены.</p>
    </div>
  </section>
</template>

<script>
import http from '@/shared/api/http'

export default {
  name: 'OfficerDocumentsPage',

  data() {
    return {
      selectedStatus: 'UPLOADED',
      documents: [],
      documentForms: {},
      loading: false,
      updatingDocumentId: null,
      message: '',
      error: ''
    }
  },

  async mounted() {
    await this.loadDocuments()
  },

  methods: {
    async loadDocuments() {
      this.loading = true
      this.message = ''
      this.error = ''

      try {
        const response = await http.get(`/documents?status=${this.selectedStatus}`)

        this.documents = response.data
        this.prepareDocumentForms()
      } catch (error) {
        this.error = error.response?.data?.message || 'Не удалось загрузить документы'
      } finally {
        this.loading = false
      }
    },

    prepareDocumentForms() {
      const forms = {}

      this.documents.forEach(document => {
        forms[document.id] = {
          status: document.status,
          comment: document.comment || ''
        }
      })

      this.documentForms = forms
    },

    async updateDocumentStatus(documentId) {
      this.message = ''
      this.error = ''
      this.updatingDocumentId = documentId

      const form = this.documentForms[documentId]

      try {
        await http.patch(`/documents/${documentId}/status`, {
          status: form.status,
          comment: form.comment
        })

        this.message = `Статус документа №${documentId} обновлён`

        await this.loadDocuments()
      } catch (error) {
        this.error = error.response?.data?.message || 'Не удалось изменить статус документа'
      } finally {
        this.updatingDocumentId = null
      }
    },

    async downloadDocument(doc) {
      this.error = ''

      try {
        const response = await http.get(`/documents/${doc.id}/download`, {
          responseType: 'blob'
        })

        const url = window.URL.createObjectURL(new Blob([response.data]))
        const link = window.document.createElement('a')

        link.href = url
        link.download = doc.fileName || 'document'
        window.document.body.appendChild(link)

        link.click()
        link.remove()

        window.URL.revokeObjectURL(url)
      } catch (error) {
        this.error = error.response?.data?.message || 'Не удалось скачать документ'
      }
    },

    translateDocumentType(type) {
      const types = {
        PASSPORT: 'Паспорт',
        EDUCATION_CERTIFICATE: 'Документ об образовании',
        CONSENT: 'Согласие на зачисление',
        OTHER: 'Другое'
      }

      return types[type] || type
    },

    translateDocumentStatus(status) {
      const statuses = {
        UPLOADED: 'Загружен',
        VERIFIED: 'Проверен',
        REJECTED: 'Отклонён'
      }

      return statuses[status] || status
    },

    formatDate(value) {
      if (!value) {
        return '—'
      }

      return new Date(value).toLocaleString('ru-RU')
    }
  }
}
</script>