<template>
  <section>
    <h1>Управление приёмными кампаниями</h1>

    <div class="card">
      <h2>{{ editingCampaignId ? 'Редактировать кампанию' : 'Создать кампанию' }}</h2>

      <form class="form" @submit.prevent="saveCampaign">
        <input
          v-model="form.name"
          type="text"
          placeholder="Название кампании"
        />

        <input
          v-model.number="form.year"
          type="number"
          placeholder="Год"
        />

        <label>
          Дата начала
          <input v-model="form.startDate" type="date" />
        </label>

        <label>
          Дата окончания
          <input v-model="form.endDate" type="date" />
        </label>

        <label class="checkbox-row">
          <input v-model="form.active" type="checkbox" />
          Активная кампания
        </label>

        <div class="button-row">
          <button type="submit" :disabled="saving">
            {{ saving ? 'Сохранение...' : 'Сохранить' }}
          </button>

          <button
            v-if="editingCampaignId"
            type="button"
            class="secondary-button"
            @click="cancelEdit"
          >
            Отмена
          </button>
        </div>
      </form>

      <p v-if="message" class="success">{{ message }}</p>
      <p v-if="error" class="error">{{ error }}</p>
    </div>

    <div class="card">
      <h2>Список кампаний</h2>

      <p v-if="loading">Загрузка...</p>

      <table v-if="campaigns.length > 0" class="table">
        <thead>
          <tr>
            <th>ID</th>
            <th>Название</th>
            <th>Год</th>
            <th>Начало</th>
            <th>Окончание</th>
            <th>Активна</th>
            <th>Действие</th>
          </tr>
        </thead>

        <tbody>
          <tr v-for="campaign in campaigns" :key="campaign.id">
            <td>{{ campaign.id }}</td>
            <td>{{ campaign.name }}</td>
            <td>{{ campaign.year }}</td>
            <td>{{ formatDate(campaign.startDate) }}</td>
            <td>{{ formatDate(campaign.endDate) }}</td>
            <td>
              <span class="status">
                {{ campaign.active ? 'Да' : 'Нет' }}
              </span>
            </td>
            <td>
              <button
                type="button"
                class="secondary-button small-button"
                @click="startEdit(campaign)"
              >
                Изменить
              </button>
            </td>
          </tr>
        </tbody>
      </table>

      <p v-else-if="!loading">Приёмные кампании пока не созданы.</p>
    </div>
  </section>
</template>

<script>
import http from '@/shared/api/http'

export default {
  name: 'AdminCampaignsPage',

  data() {
    return {
      campaigns: [],
      editingCampaignId: null,
      form: {
        name: '',
        year: new Date().getFullYear(),
        startDate: '',
        endDate: '',
        active: true
      },
      loading: false,
      saving: false,
      message: '',
      error: ''
    }
  },

  async mounted() {
    await this.loadCampaigns()
  },

  methods: {
    async loadCampaigns() {
      this.loading = true
      this.error = ''

      try {
        const response = await http.get('/admin/admission-campaigns')
        this.campaigns = response.data
      } catch (error) {
        this.error = error.response?.data?.message || 'Не удалось загрузить кампании'
      } finally {
        this.loading = false
      }
    },

    async saveCampaign() {
      this.message = ''
      this.error = ''

      const validationError = this.validateForm()

      if (validationError) {
        this.error = validationError
        return
      }

      this.saving = true

      try {
        if (this.editingCampaignId) {
          await http.put(
            `/admin/admission-campaigns/${this.editingCampaignId}`,
            this.form
          )

          this.message = 'Приёмная кампания обновлена'
        } else {
          await http.post('/admin/admission-campaigns', this.form)

          this.message = 'Приёмная кампания создана'
        }

        this.resetForm()
        await this.loadCampaigns()
      } catch (error) {
        this.error = error.response?.data?.message || 'Не удалось сохранить кампанию'
      } finally {
        this.saving = false
      }
    },

    startEdit(campaign) {
      this.editingCampaignId = campaign.id

      this.form = {
        name: campaign.name,
        year: campaign.year,
        startDate: campaign.startDate,
        endDate: campaign.endDate,
        active: campaign.active
      }

      window.scrollTo({
        top: 0,
        behavior: 'smooth'
      })
    },

    cancelEdit() {
      this.resetForm()
    },

    resetForm() {
      this.editingCampaignId = null

      this.form = {
        name: '',
        year: new Date().getFullYear(),
        startDate: '',
        endDate: '',
        active: true
      }
    },

    validateForm() {
      if (!this.form.name.trim()) {
        return 'Введите название кампании'
      }

      if (!this.form.year) {
        return 'Введите год кампании'
      }

      if (!this.form.startDate) {
        return 'Выберите дату начала'
      }

      if (!this.form.endDate) {
        return 'Выберите дату окончания'
      }

      if (this.form.startDate > this.form.endDate) {
        return 'Дата начала не может быть позже даты окончания'
      }

      return ''
    },

    formatDate(value) {
      if (!value) {
        return '—'
      }

      return new Date(value).toLocaleDateString('ru-RU')
    }
  }
}
</script>