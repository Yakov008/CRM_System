<template>
  <section>
    <h1>Управление предметами ЕГЭ</h1>

    <div class="card">
      <h2>{{ editingSubjectId ? 'Редактировать предмет' : 'Создать предмет' }}</h2>

      <form class="form" @submit.prevent="saveSubject">
        <input
          v-model="form.name"
          type="text"
          placeholder="Название предмета"
        />

        <div class="button-row">
          <button type="submit" :disabled="saving">
            {{ saving ? 'Сохранение...' : 'Сохранить' }}
          </button>

          <button
            v-if="editingSubjectId"
            type="button"
            class="secondary-button"
            @click="cancelEdit"
          >
            Отмена
          </button>
        </div>
      </form>

      <p v-if="message" class="success">{{ message }}</p>
      <p v-if="error" class="error">{{ error }}</p>
    </div>

    <div class="card">
      <h2>Список предметов</h2>

      <p v-if="loading">Загрузка...</p>

      <table v-if="subjects.length > 0" class="table">
        <thead>
          <tr>
            <th>ID</th>
            <th>Название</th>
            <th>Действие</th>
          </tr>
        </thead>

        <tbody>
          <tr v-for="subject in subjects" :key="subject.id">
            <td>{{ subject.id }}</td>
            <td>{{ subject.name }}</td>
            <td>
              <button
                type="button"
                class="secondary-button small-button"
                @click="startEdit(subject)"
              >
                Изменить
              </button>
            </td>
          </tr>
        </tbody>
      </table>

      <p v-else-if="!loading">Предметы ЕГЭ пока не созданы.</p>
    </div>
  </section>
</template>

<script>
import http from '@/shared/api/http'

export default {
  name: 'AdminExamSubjectsPage',

  data() {
    return {
      subjects: [],
      editingSubjectId: null,
      form: {
        name: ''
      },
      loading: false,
      saving: false,
      message: '',
      error: ''
    }
  },

  async mounted() {
    await this.loadSubjects()
  },

  methods: {
    async loadSubjects() {
      this.loading = true
      this.error = ''

      try {
        const response = await http.get('/admin/exam-subjects')
        this.subjects = response.data
      } catch (error) {
        this.error = error.response?.data?.message || 'Не удалось загрузить предметы'
      } finally {
        this.loading = false
      }
    },

    async saveSubject() {
      this.message = ''
      this.error = ''

      const validationError = this.validateForm()

      if (validationError) {
        this.error = validationError
        return
      }

      this.saving = true

      try {
        if (this.editingSubjectId) {
          await http.put(
            `/admin/exam-subjects/${this.editingSubjectId}`,
            this.form
          )

          this.message = 'Предмет ЕГЭ обновлён'
        } else {
          await http.post('/admin/exam-subjects', this.form)

          this.message = 'Предмет ЕГЭ создан'
        }

        this.resetForm()
        await this.loadSubjects()
      } catch (error) {
        this.error = error.response?.data?.message || 'Не удалось сохранить предмет'
      } finally {
        this.saving = false
      }
    },

    startEdit(subject) {
      this.editingSubjectId = subject.id

      this.form = {
        name: subject.name
      }

      window.scrollTo({
        top: 0,
        behavior: 'smooth'
      })
    },

    cancelEdit() {
      this.resetForm()
    },

    resetForm() {
      this.editingSubjectId = null

      this.form = {
        name: ''
      }
    },

    validateForm() {
      if (!this.form.name.trim()) {
        return 'Введите название предмета'
      }

      if (this.form.name.trim().length > 100) {
        return 'Название предмета не должно превышать 100 символов'
      }

      return ''
    }
  }
}
</script>