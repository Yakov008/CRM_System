<template>
  <section>
    <h1>Управление сотрудниками</h1>

    <div class="card">
      <h2>{{ editingUserId ? 'Редактировать сотрудника' : 'Создать сотрудника' }}</h2>

      <form class="form" @submit.prevent="saveStaffUser">
        <input
          v-model="form.email"
          type="email"
          placeholder="Email сотрудника"
        />

        <input
          v-model="form.password"
          type="password"
          :placeholder="editingUserId ? 'Новый пароль, если нужно изменить' : 'Пароль'"
        />

        <label>
          Закреплённый факультет
          <select v-model="form.facultyName">
            <option value="" disabled>Выберите факультет</option>
            <option
              v-for="facultyName in facultyNames"
              :key="facultyName"
              :value="facultyName"
            >
              {{ facultyName }}
            </option>
          </select>
        </label>

        <label class="checkbox-row">
          <input v-model="form.active" type="checkbox" />
          Активная учётная запись
        </label>

        <div class="button-row">
          <button type="submit" :disabled="saving">
            {{ saving ? 'Сохранение...' : 'Сохранить' }}
          </button>

          <button
            v-if="editingUserId"
            type="button"
            class="secondary-button"
            @click="cancelEdit"
          >
            Отмена
          </button>
        </div>
      </form>

      <p v-if="message" class="success">{{ message }}</p>
      <p v-if="error" class="error">{{ error }}</p>
    </div>

    <div class="card">
      <h2>Список сотрудников</h2>

      <p v-if="loading">Загрузка...</p>

      <table v-if="sortedStaffUsers.length > 0" class="table">
        <thead>
          <tr>
            <th>
              <button type="button" class="sort-button" @click="setSort('id')">
                ID {{ sortIndicator('id') }}
              </button>
            </th>
            <th>
              <button type="button" class="sort-button" @click="setSort('email')">
                Email {{ sortIndicator('email') }}
              </button>
            </th>
            <th>
              <button type="button" class="sort-button" @click="setSort('role')">
                Роль {{ sortIndicator('role') }}
              </button>
            </th>
            <th>
              <button type="button" class="sort-button" @click="setSort('facultyName')">
                Факультет {{ sortIndicator('facultyName') }}
              </button>
            </th>
            <th>
              <button type="button" class="sort-button" @click="setSort('active')">
                Активен {{ sortIndicator('active') }}
              </button>
            </th>
            <th>Действие</th>
          </tr>
        </thead>

        <tbody>
          <tr v-for="user in sortedStaffUsers" :key="user.id">
            <td>{{ user.id }}</td>
            <td>{{ user.email }}</td>
            <td>{{ translateRole(user.role) }}</td>
            <td>{{ user.facultyName }}</td>
            <td>
              <span class="status">
                {{ user.active ? 'Да' : 'Нет' }}
              </span>
            </td>
            <td>
              <button
                type="button"
                class="secondary-button small-button"
                @click="startEdit(user)"
              >
                Изменить
              </button>
            </td>
          </tr>
        </tbody>
      </table>

      <p v-else-if="!loading">Сотрудники пока не созданы.</p>
    </div>
  </section>
</template>

<script>
import http from '@/shared/api/http'
import { sortByColumn } from '@/shared/lib/sort'

export default {
  name: 'AdminStaffUsersPage',

  data() {
    return {
      staffUsers: [],
      faculties: [],
      editingUserId: null,
      sortKey: 'id',
      sortDirection: 'asc',
      form: {
        email: '',
        password: '',
        facultyName: '',
        active: true
      },
      loading: false,
      saving: false,
      message: '',
      error: ''
    }
  },

  computed: {
    facultyNames() {
      return this.faculties
        .map(faculty => faculty.name)
        .filter(Boolean)
    },

    sortedStaffUsers() {
      return sortByColumn(this.staffUsers, this.sortKey, this.sortDirection, {
        active: user => user.active ? 1 : 0
      })
    }
  },

  async mounted() {
    await this.loadInitialData()
  },

  methods: {
    async loadInitialData() {
      this.loading = true
      this.error = ''

      try {
        await Promise.all([
          this.loadStaffUsers(),
          this.loadFaculties()
        ])
      } finally {
        this.loading = false
      }
    },

    async loadStaffUsers() {
      try {
        const response = await http.get('/admin/staff')
        this.staffUsers = response.data
      } catch (error) {
        this.error = error.response?.data?.message || 'Не удалось загрузить сотрудников'
      }
    },

    async loadFaculties() {
      try {
        const response = await http.get('/faculties')
        this.faculties = response.data
      } catch (error) {
        this.error = error.response?.data?.message || 'Не удалось загрузить факультеты'
      }
    },

    async saveStaffUser() {
      this.message = ''
      this.error = ''

      const validationError = this.validateForm()

      if (validationError) {
        this.error = validationError
        return
      }

      const payload = {
        email: this.form.email.trim(),
        password: this.form.password,
        facultyName: this.form.facultyName.trim(),
        active: this.form.active
      }

      if (this.editingUserId && !payload.password) {
        payload.password = null
      }

      this.saving = true

      try {
        if (this.editingUserId) {
          await http.put(`/admin/staff/${this.editingUserId}`, payload)
          this.message = 'Учётная запись сотрудника обновлена'
        } else {
          await http.post('/admin/staff', payload)
          this.message = 'Учётная запись сотрудника создана'
        }

        this.resetForm()
        await this.loadStaffUsers()
      } catch (error) {
        this.error = error.response?.data?.message || 'Не удалось сохранить сотрудника'
      } finally {
        this.saving = false
      }
    },

    startEdit(user) {
      this.editingUserId = user.id
      this.message = ''
      this.error = ''

      this.form = {
        email: user.email,
        password: '',
        facultyName: user.facultyName || '',
        active: user.active
      }

      window.scrollTo({
        top: 0,
        behavior: 'smooth'
      })
    },

    cancelEdit() {
      this.resetForm()
    },

    resetForm() {
      this.editingUserId = null
      this.form = {
        email: '',
        password: '',
        facultyName: '',
        active: true
      }
    },

    validateForm() {
      if (!this.form.email.trim()) {
        return 'Введите email сотрудника'
      }

      if (!this.editingUserId && !this.form.password) {
        return 'Введите пароль'
      }

      if (this.form.password && this.form.password.length < 6) {
        return 'Пароль должен содержать не менее 6 символов'
      }

      if (!this.form.facultyName.trim()) {
        return 'Выберите закреплённый факультет'
      }

      return ''
    },

    translateRole(role) {
      const roles = {
        OFFICER: 'Сотрудник приёмной комиссии'
      }

      return roles[role] || role
    },

    setSort(key) {
      if (this.sortKey === key) {
        this.sortDirection = this.sortDirection === 'asc' ? 'desc' : 'asc'
        return
      }

      this.sortKey = key
      this.sortDirection = 'asc'
    },

    sortIndicator(key) {
      if (this.sortKey !== key) {
        return ''
      }

      return this.sortDirection === 'asc' ? '↑' : '↓'
    }
  }
}
</script>
