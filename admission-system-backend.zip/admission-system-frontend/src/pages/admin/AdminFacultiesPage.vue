<template>
  <section>
    <h1>Факультеты</h1>

    <div class="card">
      <h2>{{ editingFacultyId ? 'Редактировать факультет' : 'Создать факультет' }}</h2>

      <form class="form" @submit.prevent="saveFaculty">
        <input
          v-model="form.name"
          type="text"
          placeholder="Название факультета"
        />

        <div class="button-row">
          <button type="submit" :disabled="saving">
            {{ saving ? 'Сохранение...' : 'Сохранить' }}
          </button>

          <button
            v-if="editingFacultyId"
            type="button"
            class="secondary-button"
            @click="cancelEdit"
          >
            Отмена
          </button>
        </div>
      </form>

      <p v-if="message" class="success">{{ message }}</p>
      <p v-if="error" class="error">{{ error }}</p>
    </div>

    <div class="card">
      <h2>Список факультетов</h2>

      <p v-if="loading">Загрузка...</p>

      <table v-if="sortedFaculties.length > 0" class="table">
        <thead>
          <tr>
            <th>
              <button type="button" class="sort-button" @click="setSort('id')">
                ID {{ sortIndicator('id') }}
              </button>
            </th>
            <th>
              <button type="button" class="sort-button" @click="setSort('name')">
                Название {{ sortIndicator('name') }}
              </button>
            </th>
            <th>Действие</th>
          </tr>
        </thead>

        <tbody>
          <tr v-for="faculty in sortedFaculties" :key="faculty.id">
            <td>{{ faculty.id }}</td>
            <td>{{ faculty.name }}</td>
            <td>
              <div class="button-row compact-actions">
                <button
                  type="button"
                  class="secondary-button small-button"
                  @click="startEdit(faculty)"
                >
                  Изменить
                </button>

                <button
                  type="button"
                  class="danger-button small-button"
                  @click="deleteFaculty(faculty)"
                >
                  Удалить
                </button>
              </div>
            </td>
          </tr>
        </tbody>
      </table>

      <p v-else-if="!loading">Факультеты пока не созданы.</p>
    </div>
  </section>
</template>

<script>
import http from '@/shared/api/http'
import { sortByColumn } from '@/shared/lib/sort'

export default {
  name: 'AdminFacultiesPage',

  data() {
    return {
      faculties: [],
      editingFacultyId: null,
      sortKey: 'id',
      sortDirection: 'asc',
      form: {
        name: ''
      },
      loading: false,
      saving: false,
      message: '',
      error: ''
    }
  },

  computed: {
    sortedFaculties() {
      return sortByColumn(this.faculties, this.sortKey, this.sortDirection)
    }
  },

  async mounted() {
    await this.loadFaculties()
  },

  methods: {
    async loadFaculties() {
      this.loading = true
      this.error = ''

      try {
        const response = await http.get('/admin/faculties')
        this.faculties = response.data
      } catch (error) {
        this.error = error.response?.data?.message || 'Не удалось загрузить факультеты'
      } finally {
        this.loading = false
      }
    },

    async saveFaculty() {
      this.message = ''
      this.error = ''

      if (!this.form.name.trim()) {
        this.error = 'Введите название факультета'
        return
      }

      this.saving = true

      try {
        if (this.editingFacultyId) {
          await http.put(`/admin/faculties/${this.editingFacultyId}`, this.form)
          this.message = 'Факультет обновлён'
        } else {
          await http.post('/admin/faculties', this.form)
          this.message = 'Факультет создан'
        }

        this.resetForm()
        await this.loadFaculties()
      } catch (error) {
        this.error = error.response?.data?.message || 'Не удалось сохранить факультет'
      } finally {
        this.saving = false
      }
    },

    startEdit(faculty) {
      this.editingFacultyId = faculty.id
      this.form = {
        name: faculty.name
      }

      window.scrollTo({
        top: 0,
        behavior: 'smooth'
      })
    },

    cancelEdit() {
      this.resetForm()
    },

    resetForm() {
      this.editingFacultyId = null
      this.form = {
        name: ''
      }
    },

    async deleteFaculty(faculty) {
      const confirmed = window.confirm(`Удалить факультет "${faculty.name}"?`)

      if (!confirmed) {
        return
      }

      this.message = ''
      this.error = ''

      try {
        await http.delete(`/admin/faculties/${faculty.id}`)
        this.message = 'Факультет удалён'
        await this.loadFaculties()
      } catch (error) {
        this.error = error.response?.data?.message || 'Не удалось удалить факультет'
      }
    },

    setSort(key) {
      if (this.sortKey === key) {
        this.sortDirection = this.sortDirection === 'asc' ? 'desc' : 'asc'
        return
      }

      this.sortKey = key
      this.sortDirection = 'asc'
    },

    sortIndicator(key) {
      if (this.sortKey !== key) {
        return ''
      }

      return this.sortDirection === 'asc' ? '↑' : '↓'
    }
  }
}
</script>
