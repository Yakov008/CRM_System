<template>
  <section>
    <h1>Требования направлений к ЕГЭ</h1>

    <div class="card">
      <h2>Выбор направления</h2>

      <label>
        Направление подготовки
        <select v-model.number="selectedProgramId" @change="onProgramChange">
          <option value="" disabled>Выберите направление</option>
          <option
            v-for="program in programs"
            :key="program.id"
            :value="program.id"
          >
            {{ program.code }} {{ program.name }} — {{ program.admissionCampaignName }}
          </option>
        </select>
      </label>
    </div>

    <div v-if="selectedProgramId" class="card">
      <h2>{{ editingRequirementId ? 'Редактировать требование' : 'Добавить требование' }}</h2>

      <form class="form" @submit.prevent="saveRequirement">
        <label>
          Предмет ЕГЭ
          <select v-model.number="form.examSubjectId">
            <option value="" disabled>Выберите предмет</option>
            <option
              v-for="subject in subjects"
              :key="subject.id"
              :value="subject.id"
            >
              {{ subject.name }}
            </option>
          </select>
        </label>

        <input
          v-model.number="form.minimumScore"
          type="number"
          min="0"
          max="100"
          placeholder="Минимальный балл"
        />

        <div class="button-row">
          <button type="submit" :disabled="saving">
            {{ saving ? 'Сохранение...' : 'Сохранить' }}
          </button>

          <button
            v-if="editingRequirementId"
            type="button"
            class="secondary-button"
            @click="cancelEdit"
          >
            Отмена
          </button>
        </div>
      </form>

      <p v-if="message" class="success">{{ message }}</p>
      <p v-if="error" class="error">{{ error }}</p>
    </div>

    <div v-if="selectedProgramId" class="card">
      <h2>Список требований</h2>

      <p v-if="loading">Загрузка...</p>

      <table v-if="requirements.length > 0" class="table">
        <thead>
          <tr>
            <th>№</th>
            <th>Предмет</th>
            <th>Минимальный балл</th>
            <th>Действие</th>
          </tr>
        </thead>

        <tbody>
          <tr v-for="(requirement, index) in requirements" :key="requirement.id">
            <td>{{ index + 1 }}</td>
            <td>{{ requirement.examSubjectName }}</td>
            <td>{{ requirement.minimumScore }}</td>
            <td>
              <div class="button-row">
                <button
                  type="button"
                  class="secondary-button small-button"
                  @click="startEdit(requirement)"
                >
                  Изменить
                </button>

                <button
                  type="button"
                  class="danger-button small-button"
                  @click="deleteRequirement(requirement)"
                >
                  Удалить
                </button>
              </div>
            </td>
          </tr>
        </tbody>
      </table>

      <p v-else-if="!loading">
        Для выбранного направления требования пока не добавлены.
      </p>
    </div>
  </section>
</template>

<script>
import http from '@/shared/api/http'

export default {
  name: 'AdminProgramRequirementsPage',

  data() {
    return {
      programs: [],
      subjects: [],
      requirements: [],
      selectedProgramId: '',
      editingRequirementId: null,
      form: {
        examSubjectId: '',
        minimumScore: ''
      },
      loading: false,
      saving: false,
      message: '',
      error: ''
    }
  },

  async mounted() {
    await this.loadInitialData()
  },

  methods: {
    async loadInitialData() {
      this.error = ''

      try {
        await Promise.all([
          this.loadPrograms(),
          this.loadSubjects()
        ])

        if (this.programs.length > 0) {
          this.selectedProgramId = this.programs[0].id
          await this.loadRequirements()
        }
      } catch (error) {
        this.error = 'Не удалось загрузить данные'
      }
    },

    async loadPrograms() {
      const response = await http.get('/admin/programs')
      this.programs = response.data
    },

    async loadSubjects() {
      const response = await http.get('/admin/exam-subjects')
      this.subjects = response.data
    },

    async onProgramChange() {
      this.cancelEdit()
      await this.loadRequirements()
    },

    async loadRequirements() {
      if (!this.selectedProgramId) {
        return
      }

      this.loading = true
      this.error = ''

      try {
        const response = await http.get(
          `/admin/programs/${this.selectedProgramId}/requirements`
        )

        this.requirements = response.data
      } catch (error) {
        this.error = error.response?.data?.message || 'Не удалось загрузить требования'
      } finally {
        this.loading = false
      }
    },

    async saveRequirement() {
      this.message = ''
      this.error = ''

      const validationError = this.validateForm()

      if (validationError) {
        this.error = validationError
        return
      }

      const request = {
        programId: this.selectedProgramId,
        examSubjectId: this.form.examSubjectId,
        minimumScore: this.form.minimumScore
      }

      this.saving = true

      try {
        if (this.editingRequirementId) {
          await http.put(
            `/admin/program-requirements/${this.editingRequirementId}`,
            request
          )

          this.message = 'Требование обновлено'
        } else {
          await http.post('/admin/program-requirements', request)

          this.message = 'Требование добавлено'
        }

        this.resetForm()
        await this.loadRequirements()
      } catch (error) {
        this.error = error.response?.data?.message || 'Не удалось сохранить требование'
      } finally {
        this.saving = false
      }
    },

    startEdit(requirement) {
      this.editingRequirementId = requirement.id

      this.form = {
        examSubjectId: requirement.examSubjectId,
        minimumScore: requirement.minimumScore
      }

      window.scrollTo({
        top: 0,
        behavior: 'smooth'
      })
    },

    cancelEdit() {
      this.resetForm()
    },

    resetForm() {
      this.editingRequirementId = null

      this.form = {
        examSubjectId: '',
        minimumScore: ''
      }
    },

    async deleteRequirement(requirement) {
      const confirmed = window.confirm(
        `Удалить требование по предмету "${requirement.examSubjectName}"?`
      )

      if (!confirmed) {
        return
      }

      this.message = ''
      this.error = ''

      try {
        await http.delete(`/admin/program-requirements/${requirement.id}`)

        this.message = 'Требование удалено'

        await this.loadRequirements()
      } catch (error) {
        this.error = error.response?.data?.message || 'Не удалось удалить требование'
      }
    },

    validateForm() {
      if (!this.selectedProgramId) {
        return 'Выберите направление'
      }

      if (!this.form.examSubjectId) {
        return 'Выберите предмет ЕГЭ'
      }

      if (this.form.minimumScore === '') {
        return 'Введите минимальный балл'
      }

      if (this.form.minimumScore < 0 || this.form.minimumScore > 100) {
        return 'Минимальный балл должен быть от 0 до 100'
      }

      return ''
    }
  }
}
</script>