<template>
  <section>
    <h1>Управление направлениями подготовки</h1>

    <div class="card">
      <h2>{{ editingProgramId ? 'Редактировать направление' : 'Создать направление' }}</h2>

      <form class="form" @submit.prevent="saveProgram">
        <label>
          Приёмная кампания
          <select v-model.number="form.admissionCampaignId">
            <option value="" disabled>Выберите кампанию</option>
            <option
              v-for="campaign in campaigns"
              :key="campaign.id"
              :value="campaign.id"
            >
              {{ campaign.name }}
            </option>
          </select>
        </label>

        <input
          v-model="form.code"
          type="text"
          placeholder="Код направления, например 09.03.03"
        />

        <input
          v-model="form.name"
          type="text"
          placeholder="Название направления"
        />

        <label>
          Факультет
          <select v-model="form.facultyName">
            <option value="" disabled>Выберите факультет</option>
            <option
              v-for="faculty in faculties"
              :key="faculty.id"
              :value="faculty.name"
            >
              {{ faculty.name }}
            </option>
          </select>
        </label>

        <input
          v-model.number="form.budgetPlaces"
          type="number"
          min="0"
          placeholder="Бюджетные места"
        />

        <input
          v-model.number="form.paidPlaces"
          type="number"
          min="0"
          placeholder="Платные места"
        />

        <label class="checkbox-row">
          <input v-model="form.active" type="checkbox" />
          Активное направление
        </label>

        <div class="button-row">
          <button type="submit" :disabled="saving">
            {{ saving ? 'Сохранение...' : 'Сохранить' }}
          </button>

          <button
            v-if="editingProgramId"
            type="button"
            class="secondary-button"
            @click="cancelEdit"
          >
            Отмена
          </button>
        </div>
      </form>

      <p v-if="message" class="success">{{ message }}</p>
      <p v-if="error" class="error">{{ error }}</p>
    </div>

    <div class="card">
      <h2>Список направлений</h2>

      <p v-if="loading">Загрузка...</p>

      <table v-if="sortedPrograms.length > 0" class="table">
        <thead>
          <tr>
            <th>
              <button type="button" class="sort-button" @click="setSort('id')">
                ID {{ sortIndicator('id') }}
              </button>
            </th>
            <th>
              <button type="button" class="sort-button" @click="setSort('admissionCampaignName')">
                Кампания {{ sortIndicator('admissionCampaignName') }}
              </button>
            </th>
            <th>
              <button type="button" class="sort-button" @click="setSort('code')">
                Код {{ sortIndicator('code') }}
              </button>
            </th>
            <th>
              <button type="button" class="sort-button" @click="setSort('name')">
                Название {{ sortIndicator('name') }}
              </button>
            </th>
            <th>
              <button type="button" class="sort-button" @click="setSort('facultyName')">
                Факультет {{ sortIndicator('facultyName') }}
              </button>
            </th>
            <th>
              <button type="button" class="sort-button" @click="setSort('budgetPlaces')">
                Бюджет {{ sortIndicator('budgetPlaces') }}
              </button>
            </th>
            <th>
              <button type="button" class="sort-button" @click="setSort('paidPlaces')">
                Платно {{ sortIndicator('paidPlaces') }}
              </button>
            </th>
            <th>
              <button type="button" class="sort-button" @click="setSort('active')">
                Активно {{ sortIndicator('active') }}
              </button>
            </th>
            <th>Действие</th>
          </tr>
        </thead>

        <tbody>
          <tr v-for="program in sortedPrograms" :key="program.id">
            <td>{{ program.id }}</td>
            <td>{{ program.admissionCampaignName }}</td>
            <td>{{ program.code }}</td>
            <td>{{ program.name }}</td>
            <td>{{ program.facultyName }}</td>
            <td>{{ program.budgetPlaces }}</td>
            <td>{{ program.paidPlaces }}</td>
            <td>
              <span class="status">
                {{ program.active ? 'Да' : 'Нет' }}
              </span>
            </td>
            <td>
              <button
                type="button"
                class="secondary-button small-button"
                @click="startEdit(program)"
              >
                Изменить
              </button>
            </td>
          </tr>
        </tbody>
      </table>

      <p v-else-if="!loading">Направления пока не созданы.</p>
    </div>
  </section>
</template>

<script>
import http from '@/shared/api/http'
import { sortByColumn } from '@/shared/lib/sort'

export default {
  name: 'AdminProgramsPage',

  data() {
    return {
      campaigns: [],
      faculties: [],
      programs: [],
      editingProgramId: null,
      sortKey: 'id',
      sortDirection: 'asc',
      form: {
        admissionCampaignId: '',
        code: '',
        name: '',
        facultyName: '',
        budgetPlaces: '',
        paidPlaces: '',
        active: true
      },
      loading: false,
      saving: false,
      message: '',
      error: ''
    }
  },

  computed: {
    sortedPrograms() {
      return sortByColumn(this.programs, this.sortKey, this.sortDirection, {
        active: program => program.active ? 1 : 0
      })
    }
  },

  async mounted() {
    await this.loadInitialData()
  },

  methods: {
    async loadInitialData() {
      this.loading = true
      this.error = ''

      try {
        await Promise.all([
          this.loadCampaigns(),
          this.loadFaculties(),
          this.loadPrograms()
        ])
      } finally {
        this.loading = false
      }
    },

    async loadCampaigns() {
      try {
        const response = await http.get('/admin/admission-campaigns')
        this.campaigns = response.data

        if (this.campaigns.length > 0 && !this.form.admissionCampaignId) {
          this.form.admissionCampaignId = this.campaigns[0].id
        }
      } catch (error) {
        this.error = error.response?.data?.message || 'Не удалось загрузить кампании'
      }
    },

    async loadFaculties() {
      try {
        const response = await http.get('/faculties')
        this.faculties = response.data
      } catch (error) {
        this.error = error.response?.data?.message || 'Не удалось загрузить факультеты'
      }
    },

    async loadPrograms() {
      try {
        const response = await http.get('/admin/programs')
        this.programs = response.data
      } catch (error) {
        this.error = error.response?.data?.message || 'Не удалось загрузить направления'
      }
    },

    async saveProgram() {
      this.message = ''
      this.error = ''

      const validationError = this.validateForm()

      if (validationError) {
        this.error = validationError
        return
      }

      this.saving = true

      const payload = {
        ...this.form,
        budgetPlaces: Number(this.form.budgetPlaces),
        paidPlaces: Number(this.form.paidPlaces)
      }

      try {
        if (this.editingProgramId) {
          await http.put(`/admin/programs/${this.editingProgramId}`, payload)
          this.message = 'Направление обновлено'
        } else {
          await http.post('/admin/programs', payload)
          this.message = 'Направление создано'
        }

        this.resetForm()
        await this.loadPrograms()
      } catch (error) {
        this.error = error.response?.data?.message || 'Не удалось сохранить направление'
      } finally {
        this.saving = false
      }
    },

    startEdit(program) {
      this.editingProgramId = program.id

      this.form = {
        admissionCampaignId: program.admissionCampaignId,
        code: program.code,
        name: program.name,
        facultyName: program.facultyName,
        budgetPlaces: program.budgetPlaces,
        paidPlaces: program.paidPlaces,
        active: program.active
      }

      window.scrollTo({
        top: 0,
        behavior: 'smooth'
      })
    },

    cancelEdit() {
      this.resetForm()
    },

    resetForm() {
      this.editingProgramId = null

      this.form = {
        admissionCampaignId: this.campaigns.length > 0 ? this.campaigns[0].id : '',
        code: '',
        name: '',
        facultyName: '',
        budgetPlaces: '',
        paidPlaces: '',
        active: true
      }
    },

    validateForm() {
      if (!this.form.admissionCampaignId) {
        return 'Выберите приёмную кампанию'
      }

      if (!this.form.code.trim()) {
        return 'Введите код направления'
      }

      if (!this.form.name.trim()) {
        return 'Введите название направления'
      }

      if (!this.form.facultyName.trim()) {
        return 'Выберите факультет'
      }

      if (this.form.budgetPlaces === '' || this.form.paidPlaces === '') {
        return 'Введите количество бюджетных и платных мест'
      }

      const budgetPlaces = Number(this.form.budgetPlaces)
      const paidPlaces = Number(this.form.paidPlaces)

      if (budgetPlaces < 0 || paidPlaces < 0) {
        return 'Количество мест не может быть отрицательным'
      }

      if (budgetPlaces + paidPlaces <= 0) {
        return 'Количество мест должно быть больше 0'
      }

      return ''
    },

    setSort(key) {
      if (this.sortKey === key) {
        this.sortDirection = this.sortDirection === 'asc' ? 'desc' : 'asc'
        return
      }

      this.sortKey = key
      this.sortDirection = 'asc'
    },

    sortIndicator(key) {
      if (this.sortKey !== key) {
        return ''
      }

      return this.sortDirection === 'asc' ? '↑' : '↓'
    }
  }
}
</script>
