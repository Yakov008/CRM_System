<template>
  <section>
    <h1>Управление направлениями подготовки</h1>

    <div class="card">
      <h2>{{ editingProgramId ? 'Редактировать направление' : 'Создать направление' }}</h2>

      <form class="form" @submit.prevent="saveProgram">
        <label>
          Приёмная кампания
          <select v-model.number="form.admissionCampaignId">
            <option value="" disabled>Выберите кампанию</option>
            <option
              v-for="campaign in campaigns"
              :key="campaign.id"
              :value="campaign.id"
            >
              {{ campaign.name }} — {{ campaign.year }}
            </option>
          </select>
        </label>

        <input
          v-model="form.code"
          type="text"
          placeholder="Код направления, например 09.03.03"
        />

        <input
          v-model="form.name"
          type="text"
          placeholder="Название направления"
        />

        <input
          v-model="form.facultyName"
          type="text"
          placeholder="Факультет"
        />

        <input
          v-model.number="form.budgetPlaces"
          type="number"
          min="0"
          placeholder="Бюджетные места"
        />

        <input
          v-model.number="form.paidPlaces"
          type="number"
          min="0"
          placeholder="Платные места"
        />

        <label class="checkbox-row">
          <input v-model="form.active" type="checkbox" />
          Активное направление
        </label>

        <div class="button-row">
          <button type="submit" :disabled="saving">
            {{ saving ? 'Сохранение...' : 'Сохранить' }}
          </button>

          <button
            v-if="editingProgramId"
            type="button"
            class="secondary-button"
            @click="cancelEdit"
          >
            Отмена
          </button>
        </div>
      </form>

      <p v-if="message" class="success">{{ message }}</p>
      <p v-if="error" class="error">{{ error }}</p>
    </div>

    <div class="card">
      <h2>Список направлений</h2>

      <p v-if="loading">Загрузка...</p>

      <table v-if="programs.length > 0" class="table">
        <thead>
          <tr>
            <th>ID</th>
            <th>Кампания</th>
            <th>Код</th>
            <th>Название</th>
            <th>Факультет</th>
            <th>Бюджет</th>
            <th>Платно</th>
            <th>Активно</th>
            <th>Действие</th>
          </tr>
        </thead>

        <tbody>
          <tr v-for="program in programs" :key="program.id">
            <td>{{ program.id }}</td>
            <td>{{ program.admissionCampaignName }}</td>
            <td>{{ program.code }}</td>
            <td>{{ program.name }}</td>
            <td>{{ program.facultyName }}</td>
            <td>{{ program.budgetPlaces }}</td>
            <td>{{ program.paidPlaces }}</td>
            <td>
              <span class="status">
                {{ program.active ? 'Да' : 'Нет' }}
              </span>
            </td>
            <td>
              <button
                type="button"
                class="secondary-button small-button"
                @click="startEdit(program)"
              >
                Изменить
              </button>
            </td>
          </tr>
        </tbody>
      </table>

      <p v-else-if="!loading">Направления пока не созданы.</p>
    </div>
  </section>
</template>

<script>
import http from '@/shared/api/http'

export default {
  name: 'AdminProgramsPage',

  data() {
    return {
      campaigns: [],
      programs: [],
      editingProgramId: null,
      form: {
        admissionCampaignId: '',
        code: '',
        name: '',
        facultyName: '',
        budgetPlaces: 0,
        paidPlaces: 0,
        active: true
      },
      loading: false,
      saving: false,
      message: '',
      error: ''
    }
  },

  async mounted() {
    await this.loadInitialData()
  },

  methods: {
    async loadInitialData() {
      this.loading = true
      this.error = ''

      try {
        await Promise.all([
          this.loadCampaigns(),
          this.loadPrograms()
        ])
      } finally {
        this.loading = false
      }
    },

    async loadCampaigns() {
      try {
        const response = await http.get('/admin/admission-campaigns')
        this.campaigns = response.data

        if (this.campaigns.length > 0 && !this.form.admissionCampaignId) {
          this.form.admissionCampaignId = this.campaigns[0].id
        }
      } catch (error) {
        this.error = error.response?.data?.message || 'Не удалось загрузить кампании'
      }
    },

    async loadPrograms() {
      try {
        const response = await http.get('/admin/programs')
        this.programs = response.data
      } catch (error) {
        this.error = error.response?.data?.message || 'Не удалось загрузить направления'
      }
    },

    async saveProgram() {
      this.message = ''
      this.error = ''

      const validationError = this.validateForm()

      if (validationError) {
        this.error = validationError
        return
      }

      this.saving = true

      try {
        if (this.editingProgramId) {
          await http.put(`/admin/programs/${this.editingProgramId}`, this.form)
          this.message = 'Направление обновлено'
        } else {
          await http.post('/admin/programs', this.form)
          this.message = 'Направление создано'
        }

        this.resetForm()
        await this.loadPrograms()
      } catch (error) {
        this.error = error.response?.data?.message || 'Не удалось сохранить направление'
      } finally {
        this.saving = false
      }
    },

    startEdit(program) {
      this.editingProgramId = program.id

      this.form = {
        admissionCampaignId: program.admissionCampaignId,
        code: program.code,
        name: program.name,
        facultyName: program.facultyName,
        budgetPlaces: program.budgetPlaces,
        paidPlaces: program.paidPlaces,
        active: program.active
      }

      window.scrollTo({
        top: 0,
        behavior: 'smooth'
      })
    },

    cancelEdit() {
      this.resetForm()
    },

    resetForm() {
      this.editingProgramId = null

      this.form = {
        admissionCampaignId: this.campaigns.length > 0 ? this.campaigns[0].id : '',
        code: '',
        name: '',
        facultyName: '',
        budgetPlaces: 0,
        paidPlaces: 0,
        active: true
      }
    },

    validateForm() {
      if (!this.form.admissionCampaignId) {
        return 'Выберите приёмную кампанию'
      }

      if (!this.form.code.trim()) {
        return 'Введите код направления'
      }

      if (!this.form.name.trim()) {
        return 'Введите название направления'
      }

      if (!this.form.facultyName.trim()) {
        return 'Введите факультет'
      }

      if (this.form.budgetPlaces < 0 || this.form.paidPlaces < 0) {
        return 'Количество мест не может быть отрицательным'
      }

      if (this.form.budgetPlaces + this.form.paidPlaces <= 0) {
        return 'Количество мест должно быть больше 0'
      }

      return ''
    }
  }
}
</script>