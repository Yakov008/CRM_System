<template>
  <section>
    <h1>Направления подготовки</h1>

    <p v-if="loading">Загрузка...</p>
    <p v-if="error" class="error">{{ error }}</p>

    <div v-if="sortedPrograms.length > 0" class="cards">
      <div v-for="program in sortedPrograms" :key="program.id" class="card">
        <h2>{{ program.code }} {{ program.name }}</h2>

        <p><b>Факультет:</b> {{ program.facultyName }}</p>
        <p><b>Бюджетные места:</b> {{ program.budgetPlaces }}</p>
        <p><b>Платные места:</b> {{ program.paidPlaces }}</p>

        <h3>Вступительные испытания</h3>

        <ul>
          <li v-for="requirement in program.requirements" :key="requirement.subjectId">
            {{ requirement.subjectName }} — минимум {{ requirement.minimumScore }}
          </li>
        </ul>
      </div>
    </div>
  </section>
</template>

<script>
import http from '@/shared/api/http'
import { sortByColumn } from '@/shared/lib/sort'

export default {
  name: 'ProgramsPage',

  data() {
    return {
      programs: [],
      loading: false,
      error: ''
    }
  },  

  computed: {
    sortedPrograms() {
      return sortByColumn(this.programs, 'id', 'asc')
    }
  },

  async mounted() {
    await this.loadPrograms()
  },

  methods: {
    async loadPrograms() {
      this.loading = true
      this.error = ''

      try {
        const response = await http.get('/programs')
        this.programs = response.data
      } catch (error) {
        this.error = 'Не удалось загрузить направления'
      } finally {
        this.loading = false
      }
    }
  }
}
</script>
