<template>
  <section>
    <h1>Рейтинговые списки</h1>

    <div class="content-with-sidebar">
      <aside class="filter-sidebar card">
        <h2>Фильтр</h2>

        <label>
          Направление подготовки
          <select v-model.number="selectedProgramId" @change="loadRanking">
            <option value="" disabled>Выберите направление</option>
            <option
              v-for="program in sortedPrograms"
              :key="program.id"
              :value="program.id"
            >
              {{ program.id }} · {{ program.code }} {{ program.name }}
            </option>
          </select>
        </label>

        <p v-if="error" class="error">{{ error }}</p>
      </aside>

      <div class="content-main">
        <div v-if="ranking" class="card">
          <div class="ranking-header">
            <div>
              <h2>{{ ranking.programCode }} {{ ranking.programName }}</h2>
              <p><b>Бюджетные места:</b> {{ ranking.budgetPlaces }}</p>
              <p><b>Платные места:</b> {{ ranking.paidPlaces }}</p>
              <p><b>Сформировано:</b> {{ formatDate(ranking.generatedAt) }}</p>
            </div>
          </div>

          <p v-if="loading">Загрузка рейтинга...</p>

          <table v-if="sortedEntries.length > 0" class="table">
            <thead>
              <tr>
                <th>
                  <button type="button" class="sort-button" @click="setSort('place')">
                    Место {{ sortIndicator('place') }}
                  </button>
                </th>
                <th>
                  <button type="button" class="sort-button" @click="setSort('fullName')">
                    Абитуриент {{ sortIndicator('fullName') }}
                  </button>
                </th>
                <th>
                  <button type="button" class="sort-button" @click="setSort('applicationStatus')">
                    Статус {{ sortIndicator('applicationStatus') }}
                  </button>
                </th>
                <th>
                  <button type="button" class="sort-button" @click="setSort('recommendationText')">
                    Результат {{ sortIndicator('recommendationText') }}
                  </button>
                </th>
                <th>
                  <button type="button" class="sort-button" @click="setSort('priorityNumber')">
                    Приоритет {{ sortIndicator('priorityNumber') }}
                  </button>
                </th>
                <th>
                  <button type="button" class="sort-button" @click="setSort('examScoreSum')">
                    ЕГЭ {{ sortIndicator('examScoreSum') }}
                  </button>
                </th>
                <th>
                  <button type="button" class="sort-button" @click="setSort('achievementsScore')">
                    Достижения {{ sortIndicator('achievementsScore') }}
                  </button>
                </th>
                <th>
                  <button type="button" class="sort-button" @click="setSort('totalScore')">
                    Итого {{ sortIndicator('totalScore') }}
                  </button>
                </th>
              </tr>
            </thead>

            <tbody>
              <tr
                v-for="entry in sortedEntries"
                :key="entry.applicationId"
                :class="{
                  'current-applicant-row': isCurrentApplicant(entry),
                  'budget-boundary-after': shouldShowBudgetBoundary(entry)
                }"
              >
                <td>
                  <b>{{ entry.place }}</b>
                </td>

                <td>
                  <div class="applicant-cell">
                    <span>{{ entry.fullName }}</span>
                    <span v-if="isCurrentApplicant(entry)" class="self-badge">Это вы</span>
                  </div>
                </td>

                <td>
                  <span class="status">
                    {{ translateStatus(entry.applicationStatus) }}
                  </span>
                </td>

                <td>
                  <span
                    class="status"
                    :class="recommendationClass(entry.recommendationStatus)"
                  >
                    {{ entry.recommendationText }}
                  </span>
                </td>

                <td>{{ entry.priorityNumber }}</td>
                <td>{{ entry.examScoreSum }}</td>
                <td>{{ entry.achievementsScore }}</td>
                <td>
                  <b>{{ entry.totalScore }}</b>
                </td>
              </tr>
            </tbody>
          </table>

          <p v-else-if="!loading">
            По выбранному направлению пока нет участников рейтинга.
          </p>
        </div>

        <div v-else-if="!selectedProgramId" class="card">
          <p>Выберите направление, чтобы посмотреть рейтинг.</p>
        </div>
      </div>
    </div>
  </section>
</template>

<script>
import http from '@/shared/api/http'
import { getSession } from '@/shared/lib/session'
import { sortByColumn } from '@/shared/lib/sort'

export default {
  name: 'RankingPage',

  data() {
    return {
      applicantId: getSession().applicantId,
      programs: [],
      selectedProgramId: '',
      ranking: null,
      sortKey: 'place',
      sortDirection: 'asc',
      loading: false,
      error: ''
    }
  },

  computed: {
    sortedPrograms() {
      return sortByColumn(this.programs, 'id', 'asc')
    },

    sortedEntries() {
      if (!this.ranking) {
        return []
      }

      return sortByColumn(this.ranking.entries, this.sortKey, this.sortDirection)
    }
  },

  async mounted() {
    await this.loadPrograms()
  },

  methods: {
    async loadPrograms() {
      this.error = ''

      try {
        const response = await http.get('/programs')
        this.programs = response.data

        if (this.sortedPrograms.length > 0 && !this.selectedProgramId) {
          this.selectedProgramId = this.sortedPrograms[0].id
          await this.loadRanking()
        }
      } catch (error) {
        this.error = error.response?.data?.message || 'Не удалось загрузить направления'
      }
    },

    async loadRanking() {
      if (!this.selectedProgramId) {
        return
      }

      this.loading = true
      this.error = ''

      try {
        const response = await http.get(`/rankings/programs/${this.selectedProgramId}`)
        this.ranking = response.data
        this.sortKey = 'place'
        this.sortDirection = 'asc'
      } catch (error) {
        this.error = error.response?.data?.message || 'Не удалось загрузить рейтинг'
        this.ranking = null
      } finally {
        this.loading = false
      }
    },

    isCurrentApplicant(entry) {
      return this.applicantId && String(entry.applicantId) === String(this.applicantId)
    },

    recommendationClass(status) {
      const classes = {
        RECOMMENDED: 'recommendation-success',
        HIGHER_PRIORITY: 'recommendation-warning',
        NOT_RECOMMENDED: 'recommendation-muted'
      }

      return classes[status] || 'recommendation-muted'
    },

    shouldShowBudgetBoundary(entry) {
      if (!this.ranking?.budgetPlaces) {
        return false
      }

      return this.sortKey === 'place'
        && this.sortDirection === 'asc'
        && this.sortedEntries.length > this.ranking.budgetPlaces
        && entry.place === this.ranking.budgetPlaces
    },

    translateStatus(status) {
      const statuses = {
        DRAFT: 'Черновик',
        SUBMITTED: 'Подано',
        UNDER_REVIEW: 'На проверке',
        APPROVED: 'Принято',
        REJECTED: 'Отклонено',
        WITHDRAWN: 'Отозвано'
      }

      return statuses[status] || status
    },

    setSort(key) {
      if (this.sortKey === key) {
        this.sortDirection = this.sortDirection === 'asc' ? 'desc' : 'asc'
        return
      }

      this.sortKey = key
      this.sortDirection = 'asc'
    },

    sortIndicator(key) {
      if (this.sortKey !== key) {
        return ''
      }

      return this.sortDirection === 'asc' ? '↑' : '↓'
    },

    formatDate(value) {
      if (!value) {
        return '—'
      }

      return new Date(value).toLocaleString('ru-RU')
    }
  }
}
</script>
