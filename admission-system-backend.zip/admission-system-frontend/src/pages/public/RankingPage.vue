<template>
  <section>
    <h1>Рейтинговые списки</h1>

    <div class="card">
      <h2>Выбор направления</h2>

      <label>
        Направление подготовки
        <select v-model.number="selectedProgramId" @change="loadRanking">
          <option value="" disabled>Выберите направление</option>
          <option
            v-for="program in programs"
            :key="program.id"
            :value="program.id"
          >
            {{ program.code }} {{ program.name }}
          </option>
        </select>
      </label>

      <p v-if="error" class="error">{{ error }}</p>
    </div>

    <div v-if="ranking" class="card">
      <div class="ranking-header">
        <div>
          <h2>{{ ranking.programCode }} {{ ranking.programName }}</h2>
          <p><b>Бюджетные места:</b> {{ ranking.budgetPlaces }}</p>
          <p><b>Платные места:</b> {{ ranking.paidPlaces }}</p>
          <p><b>Сформировано:</b> {{ formatDate(ranking.generatedAt) }}</p>
        </div>
      </div>

      <p v-if="loading">Загрузка рейтинга...</p>

      <table v-if="ranking.entries.length > 0" class="table">
        <thead>
          <tr>
            <th>Место</th>
            <th>Абитуриент</th>
            <th>ID заявления</th>
            <th>Статус</th>
            <th>Результат</th>
            <th>Приоритет</th>
            <th>ЕГЭ</th>
            <th>Достижения</th>
            <th>Итого</th>
          </tr>
        </thead>

        <tbody>
          <tr
            v-for="entry in ranking.entries"
            :key="entry.applicationId"
          >
            <td>
              <b>{{ entry.place }}</b>
            </td>

            <td>
              {{ entry.fullName }}
              <div class="muted">ID: {{ entry.applicantId }}</div>
            </td>

            <td>{{ entry.applicationId }}</td>

            <td>
              <span class="status">
                {{ translateStatus(entry.applicationStatus) }}
              </span>
            </td>

            <td>
              <span
                class="status"
                :class="recommendationClass(entry.recommendationStatus)"
              >
                {{ entry.recommendationText }}
              </span>
            </td>

            <td>{{ entry.priorityNumber }}</td>
            <td>{{ entry.examScoreSum }}</td>
            <td>{{ entry.achievementsScore }}</td>
            <td>
              <b>{{ entry.totalScore }}</b>
            </td>
          </tr>
        </tbody>
      </table>

      <p v-else-if="!loading">
        По выбранному направлению пока нет участников рейтинга.
      </p>
    </div>

    <div v-else-if="!selectedProgramId" class="card">
      <p>Выберите направление, чтобы посмотреть рейтинг.</p>
    </div>
  </section>
</template>

<script>
import http from '@/shared/api/http'

export default {
  name: 'RankingPage',

  data() {
    return {
      programs: [],
      selectedProgramId: '',
      ranking: null,
      loading: false,
      error: ''
    }
  },

  async mounted() {
    await this.loadPrograms()
  },

  methods: {
    async loadPrograms() {
      this.error = ''

      try {
        const response = await http.get('/programs')
        this.programs = response.data

        if (this.programs.length > 0 && !this.selectedProgramId) {
          this.selectedProgramId = this.programs[0].id
          await this.loadRanking()
        }
      } catch (error) {
        this.error = error.response?.data?.message || 'Не удалось загрузить направления'
      }
    },

    async loadRanking() {
      if (!this.selectedProgramId) {
        return
      }

      this.loading = true
      this.error = ''

      try {
        const response = await http.get(`/rankings/programs/${this.selectedProgramId}`)
        this.ranking = response.data
      } catch (error) {
        this.error = error.response?.data?.message || 'Не удалось загрузить рейтинг'
        this.ranking = null
      } finally {
        this.loading = false
      }
    },

    recommendationClass(status) {
      const classes = {
        RECOMMENDED: 'recommendation-success',
        HIGHER_PRIORITY: 'recommendation-warning',
        NOT_RECOMMENDED: 'recommendation-muted'
      }

      return classes[status] || 'recommendation-muted'
    },

    translateStatus(status) {
      const statuses = {
        DRAFT: 'Черновик',
        SUBMITTED: 'Подано',
        UNDER_REVIEW: 'На проверке',
        APPROVED: 'Принято',
        REJECTED: 'Отклонено',
        WITHDRAWN: 'Отозвано'
      }

      return statuses[status] || status
    },

    formatDate(value) {
      if (!value) {
        return '—'
      }

      return new Date(value).toLocaleString('ru-RU')
    }
  }
}
</script>