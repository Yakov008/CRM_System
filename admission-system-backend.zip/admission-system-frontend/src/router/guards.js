import { ROUTE_PATHS } from '@/shared/constants/routes'
import { getRole } from '@/shared/lib/session'

export function authGuard(to) {
  const role = getRole()

  if (to.meta.requiresAuth && !role) {
    return ROUTE_PATHS.LOGIN
  }

  if (to.meta.roles && !to.meta.roles.includes(role)) {
    return ROUTE_PATHS.PROGRAMS
  }

  return true
}

