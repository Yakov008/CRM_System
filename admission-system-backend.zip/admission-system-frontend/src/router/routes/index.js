import { adminRoutes } from './admin'
import { applicantRoutes } from './applicant'
import { authRoutes } from './auth'
import { officerRoutes } from './officer'
import { publicRoutes } from './public'

export const routes = [
  ...publicRoutes,
  ...authRoutes,
  ...applicantRoutes,
  ...officerRoutes,
  ...adminRoutes
]

