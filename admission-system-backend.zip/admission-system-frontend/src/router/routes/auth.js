import { ROUTE_PATHS } from '@/shared/constants/routes'

export const authRoutes = [
  {
    path: ROUTE_PATHS.LOGIN,
    component: () => import('@/pages/auth/LoginPage.vue')
  },
  {
    path: ROUTE_PATHS.REGISTER,
    component: () => import('@/pages/auth/RegisterPage.vue')
  }
]

