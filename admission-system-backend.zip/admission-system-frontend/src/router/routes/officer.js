import { OFFICER_ROLES } from '@/shared/constants/roles'
import { ROUTE_PATHS } from '@/shared/constants/routes'

export const officerRoutes = [
  {
    path: ROUTE_PATHS.OFFICER_APPLICATIONS,
    component: () => import('@/pages/officer/OfficerApplicationsPage.vue'),
    meta: {
      requiresAuth: true,
      roles: OFFICER_ROLES
    }
  },
  {
    path: ROUTE_PATHS.OFFICER_DOCUMENTS,
    component: () => import('@/pages/officer/OfficerDocumentsPage.vue'),
    meta: {
      requiresAuth: true,
      roles: OFFICER_ROLES
    }
  }
]

