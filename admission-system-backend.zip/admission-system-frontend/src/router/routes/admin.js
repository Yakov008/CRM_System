import { USER_ROLES } from '@/shared/constants/roles'
import { ROUTE_PATHS } from '@/shared/constants/routes'

const adminMeta = {
  requiresAuth: true,
  roles: [USER_ROLES.ADMIN]
}

export const adminRoutes = [
  {
    path: ROUTE_PATHS.ADMIN_CAMPAIGNS,
    component: () => import('@/pages/admin/AdminCampaignsPage.vue'),
    meta: adminMeta
  },
  {
    path: ROUTE_PATHS.ADMIN_EXAM_SUBJECTS,
    component: () => import('@/pages/admin/AdminExamSubjectsPage.vue'),
    meta: adminMeta
  },
  {
    path: ROUTE_PATHS.ADMIN_PROGRAMS,
    component: () => import('@/pages/admin/AdminProgramsPage.vue'),
    meta: adminMeta
  },
  {
    path: ROUTE_PATHS.ADMIN_PROGRAM_REQUIREMENTS,
    component: () => import('@/pages/admin/AdminProgramRequirementsPage.vue'),
    meta: adminMeta
  },
  {
    path: ROUTE_PATHS.ADMIN_STAFF,
    component: () => import('@/pages/admin/AdminStaffUsersPage.vue'),
    meta: adminMeta
  }
]
