import { ROUTE_PATHS } from '@/shared/constants/routes'

export const publicRoutes = [
  {
    path: ROUTE_PATHS.HOME,
    redirect: ROUTE_PATHS.PROGRAMS
  },
  {
    path: ROUTE_PATHS.PROGRAMS,
    component: () => import('@/pages/public/ProgramsPage.vue')
  },
  {
    path: ROUTE_PATHS.RANKINGS,
    component: () => import('@/pages/public/RankingPage.vue')
  }
]

