import { USER_ROLES } from '@/shared/constants/roles'
import { ROUTE_PATHS } from '@/shared/constants/routes'

export const applicantRoutes = [
  {
    path: ROUTE_PATHS.CABINET,
    component: () => import('@/pages/applicant/ApplicantHomePage.vue'),
    meta: {
      requiresAuth: true
    }
  },
  {
    path: ROUTE_PATHS.EXAM_RESULTS,
    component: () => import('@/pages/applicant/ExamResultsPage.vue'),
    meta: {
      requiresAuth: true,
      roles: [USER_ROLES.APPLICANT]
    }
  },
  {
    path: ROUTE_PATHS.APPLICATIONS,
    component: () => import('@/pages/applicant/ApplicationsPage.vue'),
    meta: {
      requiresAuth: true,
      roles: [USER_ROLES.APPLICANT]
    }
  },
  {
    path: ROUTE_PATHS.DOCUMENTS,
    component: () => import('@/pages/applicant/DocumentsPage.vue'),
    meta: {
      requiresAuth: true,
      roles: [USER_ROLES.APPLICANT]
    }
  }
]

