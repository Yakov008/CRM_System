<template>
  <div class="app">
    <header class="header">
      <RouterLink to="/programs" class="brand" aria-label="Admission System">
        <span class="brand-mark">AS</span>
        <span class="brand-text">
          <span class="logo">Admission System</span>
          <span class="brand-caption">приёмная кампания</span>
        </span>
      </RouterLink>

      <nav class="nav">
        <RouterLink to="/programs">Направления</RouterLink>
        <RouterLink to="/rankings">Рейтинг</RouterLink>

        <RouterLink v-if="isApplicant" to="/exam-results">ЕГЭ</RouterLink>
        <RouterLink v-if="isApplicant" to="/applications">Заявления</RouterLink>
        <RouterLink v-if="isApplicant" to="/documents">Документы</RouterLink>

        <RouterLink v-if="isOfficerOrAdmin" to="/officer/applications">
          Проверка заявлений
        </RouterLink>

        <RouterLink v-if="isOfficerOrAdmin" to="/officer/documents">
          Проверка документов
        </RouterLink>

        <RouterLink v-if="isAdmin" to="/admin/campaigns">
          Управление кампаниями
        </RouterLink>

        <RouterLink v-if="isAdmin" to="/admin/exam-subjects">
          Управление предметами
        </RouterLink>

        <RouterLink v-if="isAdmin" to="/admin/faculties">
          Факультеты
        </RouterLink>

        <RouterLink v-if="isAdmin" to="/admin/programs">
          Управление направлениями
        </RouterLink>

        <RouterLink v-if="isAdmin" to="/admin/program-requirements">
          Требования ЕГЭ
        </RouterLink>

        <RouterLink v-if="isAdmin" to="/admin/staff">
          Сотрудники
        </RouterLink>

        <RouterLink v-if="isLoggedIn" to="/applicant">Кабинет</RouterLink>

        <RouterLink v-if="!isLoggedIn" to="/login">Вход</RouterLink>
        <RouterLink v-if="!isLoggedIn" to="/register">Регистрация</RouterLink>

        <button
          v-if="isLoggedIn"
          type="button"
          class="nav-button"
          @click="logout"
        >
          Выйти
        </button>
      </nav>
    </header>

    <main class="main">
      <RouterView />
    </main>
  </div>
</template>

<script>
import http from '@/shared/api/http'
import { USER_ROLES } from '@/shared/constants/roles'
import { clearSession, getRole, getToken, saveAuthSession } from '@/shared/lib/session'

export default {
  name: 'App',

  data() {
    return {
      role: getRole()
    }
  },

  computed: {
    isLoggedIn() {
      return Boolean(this.role)
    },

    isApplicant() {
      return this.role === USER_ROLES.APPLICANT
    },

    isOfficerOrAdmin() {
      return this.role === USER_ROLES.OFFICER || this.role === USER_ROLES.ADMIN
    },
    isAdmin() {
      return this.role === USER_ROLES.ADMIN
    }
  },

  watch: {
    $route() {
      this.syncUser()
    }
  },

  async mounted() {
    await this.loadCurrentUser()
  },

  methods: {
    syncUser() {
      this.role = getRole()
    },

    async loadCurrentUser() {
      const token = getToken()

      if (!token) {
        this.syncUser()
        return
      }

      try {
        const response = await http.get('/auth/me')

        saveAuthSession(response.data)

        this.syncUser()
      } catch (error) {
        clearSession()
        this.syncUser()
      }
    },

    logout() {
      clearSession()
      this.syncUser()
      this.$router.push('/login')
    }
  }
}
</script>
