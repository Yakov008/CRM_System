export const ROUTE_PATHS = {
  HOME: '/',
  LOGIN: '/login',
  REGISTER: '/register',
  PROGRAMS: '/programs',
  RANKINGS: '/rankings',
  CABINET: '/applicant',
  EXAM_RESULTS: '/exam-results',
  APPLICATIONS: '/applications',
  DOCUMENTS: '/documents',
  OFFICER_APPLICATIONS: '/officer/applications',
  OFFICER_DOCUMENTS: '/officer/documents',
  ADMIN_CAMPAIGNS: '/admin/campaigns',
  ADMIN_EXAM_SUBJECTS: '/admin/exam-subjects',
  ADMIN_PROGRAMS: '/admin/programs',
  ADMIN_PROGRAM_REQUIREMENTS: '/admin/program-requirements',
  ADMIN_STAFF: '/admin/staff'
}
