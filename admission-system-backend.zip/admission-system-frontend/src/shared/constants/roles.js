export const USER_ROLES = {
  APPLICANT: 'APPLICANT',
  OFFICER: 'OFFICER',
  ADMIN: 'ADMIN'
}

export const OFFICER_ROLES = [
  USER_ROLES.OFFICER,
  USER_ROLES.ADMIN
]

export const ROLE_LABELS = {
  [USER_ROLES.APPLICANT]: 'Абитуриент',
  [USER_ROLES.OFFICER]: 'Сотрудник',
  [USER_ROLES.ADMIN]: 'Администратор'
}

