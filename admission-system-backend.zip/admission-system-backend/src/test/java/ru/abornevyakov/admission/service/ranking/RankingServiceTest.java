package ru.abornevyakov.admission.service.ranking;

import org.junit.jupiter.api.Test;
import ru.abornevyakov.admission.dto.ranking.ProgramRankingDto;
import ru.abornevyakov.admission.dto.ranking.RankingEntryDto;
import ru.abornevyakov.admission.entity.AdmissionCampaign;
import ru.abornevyakov.admission.entity.Applicant;
import ru.abornevyakov.admission.entity.ApplicantProfile;
import ru.abornevyakov.admission.entity.Application;
import ru.abornevyakov.admission.entity.ApplicationPriority;
import ru.abornevyakov.admission.entity.ExamResult;
import ru.abornevyakov.admission.entity.ExamSubject;
import ru.abornevyakov.admission.entity.MinimumExamScore;
import ru.abornevyakov.admission.entity.Program;
import ru.abornevyakov.admission.entity.ProgramExamRequirement;
import ru.abornevyakov.admission.entity.enums.ApplicationStatus;
import ru.abornevyakov.admission.repository.ApplicationPriorityRepository;
import ru.abornevyakov.admission.repository.ApplicationRepository;
import ru.abornevyakov.admission.repository.ExamResultRepository;
import ru.abornevyakov.admission.repository.ProgramExamRequirementRepository;
import ru.abornevyakov.admission.repository.ProgramRepository;

import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

class RankingServiceTest {

    private final ProgramRepository programRepository = mock(ProgramRepository.class);
    private final ApplicationRepository applicationRepository = mock(ApplicationRepository.class);
    private final ApplicationPriorityRepository priorityRepository = mock(ApplicationPriorityRepository.class);
    private final ProgramExamRequirementRepository requirementRepository = mock(ProgramExamRequirementRepository.class);
    private final ExamResultRepository examResultRepository = mock(ExamResultRepository.class);

    private final RankingService rankingService = new RankingService(
            programRepository,
            applicationRepository,
            priorityRepository,
            requirementRepository,
            examResultRepository
    );

    @Test
    void displacedCandidateIsRecommendedForNextPriority() {
        AdmissionCampaign campaign = campaign(1L);
        ExamSubject math = subject(1L, "Математика");
        Program firstPriorityProgram = program(10L, campaign, "09.03.03", "Прикладная информатика", 1);
        Program secondPriorityProgram = program(20L, campaign, "09.03.04", "Программная инженерия", 1);

        Applicant displacedApplicant = applicant(100L, "Иванов", "Иван", 0);
        Applicant strongerApplicant = applicant(200L, "Петров", "Петр", 0);

        Application displacedApplication = application(1000L, displacedApplicant, campaign);
        Application strongerApplication = application(2000L, strongerApplicant, campaign);

        when(programRepository.findById(firstPriorityProgram.getId()))
                .thenReturn(Optional.of(firstPriorityProgram));
        when(programRepository.findById(secondPriorityProgram.getId()))
                .thenReturn(Optional.of(secondPriorityProgram));
        when(applicationRepository.findByAdmissionCampaignId(campaign.getId()))
                .thenReturn(List.of(displacedApplication, strongerApplication));

        when(priorityRepository.findByApplicationIdOrderByPriorityNumberAsc(displacedApplication.getId()))
                .thenReturn(List.of(
                        priority(displacedApplication, firstPriorityProgram, 1),
                        priority(displacedApplication, secondPriorityProgram, 2)
                ));
        when(priorityRepository.findByApplicationIdOrderByPriorityNumberAsc(strongerApplication.getId()))
                .thenReturn(List.of(priority(strongerApplication, firstPriorityProgram, 1)));

        when(requirementRepository.findByProgramIdIn(anyList()))
                .thenReturn(List.of(
                        requirement(firstPriorityProgram, math, 0),
                        requirement(secondPriorityProgram, math, 0)
                ));
        when(examResultRepository.findByApplicantIdIn(anyList()))
                .thenReturn(List.of(
                        result(displacedApplicant, math, 80),
                        result(strongerApplicant, math, 95)
                ));

        ProgramRankingDto firstProgramRanking = rankingService.getRankingByProgramId(firstPriorityProgram.getId());
        ProgramRankingDto secondProgramRanking = rankingService.getRankingByProgramId(secondPriorityProgram.getId());

        RankingEntryDto firstProgramLeader = firstProgramRanking.entries().get(0);
        RankingEntryDto secondProgramLeader = secondProgramRanking.entries().get(0);

        assertThat(firstProgramLeader.applicationId()).isEqualTo(strongerApplication.getId());
        assertThat(firstProgramLeader.recommended()).isTrue();
        assertThat(firstProgramLeader.recommendationStatus()).isEqualTo("RECOMMENDED");

        assertThat(secondProgramLeader.applicationId()).isEqualTo(displacedApplication.getId());
        assertThat(secondProgramLeader.recommended()).isTrue();
        assertThat(secondProgramLeader.recommendationStatus()).isEqualTo("RECOMMENDED");
    }

    private AdmissionCampaign campaign(Long id) {
        AdmissionCampaign campaign = new AdmissionCampaign();
        campaign.setId(id);
        campaign.setName("Приёмная кампания");
        campaign.setYear(2026);
        campaign.setActive(true);
        return campaign;
    }

    private Program program(Long id, AdmissionCampaign campaign, String code, String name, int budgetPlaces) {
        Program program = new Program();
        program.setId(id);
        program.setAdmissionCampaign(campaign);
        program.setCode(code);
        program.setName(name);
        program.setFacultyName("Факультет");
        program.setBudgetPlaces(budgetPlaces);
        program.setPaidPlaces(0);
        program.setActive(true);
        return program;
    }

    private Applicant applicant(Long id, String lastName, String firstName, int achievementsScore) {
        ApplicantProfile profile = new ApplicantProfile();
        profile.setLastName(lastName);
        profile.setFirstName(firstName);

        Applicant applicant = new Applicant();
        applicant.setId(id);
        applicant.setProfile(profile);
        applicant.setAchievementsScore(achievementsScore);
        return applicant;
    }

    private Application application(Long id, Applicant applicant, AdmissionCampaign campaign) {
        Application application = new Application();
        application.setId(id);
        application.setApplicant(applicant);
        application.setAdmissionCampaign(campaign);
        application.setStatus(ApplicationStatus.SUBMITTED);
        return application;
    }

    private ApplicationPriority priority(Application application, Program program, int priorityNumber) {
        ApplicationPriority priority = new ApplicationPriority();
        priority.setApplication(application);
        priority.setProgram(program);
        priority.setPriorityNumber(priorityNumber);
        return priority;
    }

    private ExamSubject subject(Long id, String name) {
        ExamSubject subject = new ExamSubject();
        subject.setId(id);
        subject.setName(name);
        return subject;
    }

    private ProgramExamRequirement requirement(Program program, ExamSubject subject, int minimumScore) {
        MinimumExamScore score = new MinimumExamScore();
        score.setScore(minimumScore);

        ProgramExamRequirement requirement = new ProgramExamRequirement();
        requirement.setProgram(program);
        requirement.setExamSubject(subject);
        requirement.setMinimumExamScore(score);
        return requirement;
    }

    private ExamResult result(Applicant applicant, ExamSubject subject, int score) {
        ExamResult result = new ExamResult();
        result.setApplicant(applicant);
        result.setExamSubject(subject);
        result.setExamYear(2026);
        result.setScore(score);
        return result;
    }
}
