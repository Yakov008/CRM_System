package ru.abornevyakov.admission;

import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

class AdmissionSystemBackendApplicationTests {

	@Test
	void applicationClassIsAvailable() {
		assertThat(AdmissionSystemBackendApplication.class).isNotNull();
	}

}
