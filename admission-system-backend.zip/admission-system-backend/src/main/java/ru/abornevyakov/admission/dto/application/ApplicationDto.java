package ru.abornevyakov.admission.dto.application;

import java.time.LocalDateTime;
import java.util.List;

public record ApplicationDto(
        Long id,
        Long applicantId,
        String applicantFullName,
        Integer achievementsScore,
        Long admissionCampaignId,
        String admissionCampaignName,
        String status,
        LocalDateTime createdAt,
        LocalDateTime submittedAt,
        LocalDateTime lockedUntil,
        String comment,
        List<ApplicationPriorityDto> priorities
) {
}