package ru.abornevyakov.admission.dto.exam;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;

public record ExamResultRequest(

        @NotNull
        Long examSubjectId,

        @NotNull
        Integer examYear,

        @NotNull
        @Min(0)
        @Max(100)
        Integer score
) {
}