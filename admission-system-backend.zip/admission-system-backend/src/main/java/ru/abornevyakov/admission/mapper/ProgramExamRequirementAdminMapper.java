package ru.abornevyakov.admission.mapper;

import org.springframework.stereotype.Component;
import ru.abornevyakov.admission.dto.program.ProgramExamRequirementAdminDto;
import ru.abornevyakov.admission.entity.ProgramExamRequirement;

@Component
public class ProgramExamRequirementAdminMapper {

    public ProgramExamRequirementAdminDto toDto(ProgramExamRequirement requirement) {
        return new ProgramExamRequirementAdminDto(
                requirement.getId(),
                requirement.getProgram().getId(),
                requirement.getProgram().getCode(),
                requirement.getProgram().getName(),
                requirement.getExamSubject().getId(),
                requirement.getExamSubject().getName(),
                requirement.getMinimumExamScore().getScore()
        );
    }
}
