package ru.abornevyakov.admission.dto.staff;

public record StaffUserDto(
        Long id,
        String email,
        String role,
        String facultyName,
        Boolean active
) {
}
