package ru.abornevyakov.admission.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import ru.abornevyakov.admission.entity.ExamResult;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

public interface ExamResultRepository extends JpaRepository<ExamResult, Long> {

    List<ExamResult> findByApplicantId(Long applicantId);

    List<ExamResult> findByApplicantIdIn(List<Long> applicantIds);

    List<ExamResult> findByApplicantIdAndExamSubjectId(Long applicantId, Long examSubjectId);

    boolean existsByExamSubjectId(Long examSubjectId);

    boolean existsByApplicantIdAndExamSubjectIdAndExamYear(
            Long applicantId,
            Long examSubjectId,
            Integer examYear
    );

    boolean existsByApplicantIdAndExamSubjectIdAndExamYearAndIdNot(
            Long applicantId,
            Long examSubjectId,
            Integer examYear,
            Long id
    );

    Optional<ExamResult> findFirstByApplicantIdAndCreatedAtAfterOrderByCreatedAtAsc(
            Long applicantId,
            LocalDateTime createdAt
    );

    long countByApplicantIdAndCreatedAtAfter(Long applicantId, LocalDateTime createdAt);
}
