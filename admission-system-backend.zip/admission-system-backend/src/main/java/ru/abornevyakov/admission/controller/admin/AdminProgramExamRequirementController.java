package ru.abornevyakov.admission.controller.admin;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;
import ru.abornevyakov.admission.dto.program.ProgramExamRequirementAdminDto;
import ru.abornevyakov.admission.dto.program.ProgramExamRequirementAdminRequest;
import ru.abornevyakov.admission.service.admin.ProgramExamRequirementAdminService;

import java.util.List;

@RestController
@RequestMapping("/api/admin")
@RequiredArgsConstructor
public class AdminProgramExamRequirementController {

    private final ProgramExamRequirementAdminService requirementAdminService;

    @GetMapping("/programs/{programId}/requirements")
    public List<ProgramExamRequirementAdminDto> getRequirementsByProgramId(
            @PathVariable Long programId
    ) {
        return requirementAdminService.getRequirementsByProgramId(programId);
    }

    @PostMapping("/program-requirements")
    public ProgramExamRequirementAdminDto createRequirement(
            @Valid @RequestBody ProgramExamRequirementAdminRequest request
    ) {
        return requirementAdminService.createRequirement(request);
    }

    @PutMapping("/program-requirements/{requirementId}")
    public ProgramExamRequirementAdminDto updateRequirement(
            @PathVariable Long requirementId,
            @Valid @RequestBody ProgramExamRequirementAdminRequest request
    ) {
        return requirementAdminService.updateRequirement(requirementId, request);
    }

    @DeleteMapping("/program-requirements/{requirementId}")
    public void deleteRequirement(@PathVariable Long requirementId) {
        requirementAdminService.deleteRequirement(requirementId);
    }
}