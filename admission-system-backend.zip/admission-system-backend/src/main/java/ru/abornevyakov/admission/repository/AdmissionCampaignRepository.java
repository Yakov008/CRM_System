package ru.abornevyakov.admission.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import ru.abornevyakov.admission.entity.AdmissionCampaign;

import java.util.List;

public interface AdmissionCampaignRepository extends JpaRepository<AdmissionCampaign, Long> {

    List<AdmissionCampaign> findByActiveTrue();
}