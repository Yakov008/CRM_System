package ru.abornevyakov.admission.dto.officer;

import ru.abornevyakov.admission.dto.application.ApplicationDto;
import ru.abornevyakov.admission.dto.document.ApplicationDocumentDto;
import ru.abornevyakov.admission.dto.exam.ExamResultDto;

import java.util.List;

public record OfficerApplicationDetailsDto(
        ApplicationDto application,
        OfficerApplicantInfoDto applicant,
        List<ExamResultDto> examResults,
        List<ApplicationDocumentDto> documents
) {
}