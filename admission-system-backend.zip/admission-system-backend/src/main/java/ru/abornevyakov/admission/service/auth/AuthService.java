package ru.abornevyakov.admission.service.auth;

import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.abornevyakov.admission.dto.auth.AuthResponse;
import ru.abornevyakov.admission.dto.auth.LoginRequest;
import ru.abornevyakov.admission.dto.auth.CurrentUserDto;
import ru.abornevyakov.admission.security.UserPrincipal;
import ru.abornevyakov.admission.entity.Applicant;
import ru.abornevyakov.admission.entity.User;
import ru.abornevyakov.admission.entity.enums.RoleType;
import ru.abornevyakov.admission.exception.BadRequestException;
import ru.abornevyakov.admission.repository.ApplicantRepository;
import ru.abornevyakov.admission.repository.UserRepository;
import ru.abornevyakov.admission.security.JwtService;

@Service
@RequiredArgsConstructor
public class AuthService {

    private final UserRepository userRepository;
    private final ApplicantRepository applicantRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtService jwtService;
    private final CurrentUserService currentUserService;

    @Transactional(readOnly = true)
    public AuthResponse login(LoginRequest request) {
        User user = userRepository.findByEmail(request.email())
                .orElseThrow(() -> new BadRequestException("Неверный email или пароль"));

        if (!user.isActive()) {
            throw new BadRequestException("Пользователь заблокирован");
        }

        if (!passwordEncoder.matches(request.password(), user.getPassword())) {
            throw new BadRequestException("Неверный email или пароль");
        }

        Long applicantId = null;

        if (user.getRole() == RoleType.APPLICANT) {
            Applicant applicant = applicantRepository.findByUserId(user.getId())
                    .orElseThrow(() -> new BadRequestException("Профиль абитуриента не найден"));

            applicantId = applicant.getId();
        }

        String token = jwtService.generateToken(user);

        return new AuthResponse(
                token,
                user.getId(),
                applicantId,
                user.getEmail(),
                user.getRole().name()
        );
    }

    @Transactional(readOnly = true)
    public CurrentUserDto getCurrentUser() {
        UserPrincipal principal = currentUserService.getCurrentPrincipal();

        Long applicantId = null;

        if (principal.getRole() == RoleType.APPLICANT) {
            Applicant applicant = applicantRepository.findByUserId(principal.getUserId())
                    .orElseThrow(() -> new BadRequestException("Профиль абитуриента не найден"));

            applicantId = applicant.getId();
        }

        return new CurrentUserDto(
                principal.getUserId(),
                applicantId,
                principal.getUsername(),
                principal.getRole().name()
        );
    }
}