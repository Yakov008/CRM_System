package ru.abornevyakov.admission.service.exam;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.abornevyakov.admission.dto.exam.ExamResultDto;
import ru.abornevyakov.admission.dto.exam.ExamResultLimitDto;
import ru.abornevyakov.admission.dto.exam.ExamResultRequest;
import ru.abornevyakov.admission.entity.Applicant;
import ru.abornevyakov.admission.entity.ExamResult;
import ru.abornevyakov.admission.entity.ExamSubject;
import ru.abornevyakov.admission.exception.BadRequestException;
import ru.abornevyakov.admission.exception.ResourceNotFoundException;
import ru.abornevyakov.admission.mapper.ExamResultMapper;
import ru.abornevyakov.admission.repository.ApplicantRepository;
import ru.abornevyakov.admission.repository.ExamResultRepository;
import ru.abornevyakov.admission.repository.ExamSubjectRepository;
import ru.abornevyakov.admission.service.auth.CurrentUserService;

import java.time.LocalDateTime;
import java.util.List;

@Service
@RequiredArgsConstructor
public class ExamResultService {

    private static final int ADD_LIMIT_PER_HOUR = 6;
    private static final int LIMIT_WINDOW_HOURS = 1;

    private final ExamResultRepository examResultRepository;
    private final ApplicantRepository applicantRepository;
    private final ExamSubjectRepository examSubjectRepository;
    private final CurrentUserService currentUserService;
    private final ExamResultMapper examResultMapper;

    @Transactional
    public ExamResultDto addExamResult(Long applicantId, ExamResultRequest request) {
        currentUserService.checkApplicantAccess(applicantId);

        Applicant applicant = applicantRepository.findById(applicantId)
                .orElseThrow(() -> new ResourceNotFoundException("Абитуриент не найден"));

        ExamSubject subject = examSubjectRepository.findById(request.examSubjectId())
                .orElseThrow(() -> new ResourceNotFoundException("Предмет ЕГЭ не найден"));

        if (examResultRepository.existsByApplicantIdAndExamSubjectIdAndExamYear(
                applicantId,
                request.examSubjectId(),
                request.examYear()
        )) {
            throw new BadRequestException("Результат по этому предмету за указанный год уже добавлен");
        }

        LocalDateTime oneHourAgo = LocalDateTime.now().minusHours(LIMIT_WINDOW_HOURS);

        long addedInLastHour = examResultRepository.countByApplicantIdAndCreatedAtAfter(
                applicantId,
                oneHourAgo
        );

        if (addedInLastHour >= ADD_LIMIT_PER_HOUR) {
            throw new BadRequestException("Результаты ЕГЭ можно добавлять не более 6 раз за 1 час");
        }

        ExamResult examResult = new ExamResult();
        examResult.setApplicant(applicant);
        examResult.setExamSubject(subject);
        examResult.setExamYear(request.examYear());
        examResult.setScore(request.score());

        ExamResult savedResult = examResultRepository.save(examResult);

        return examResultMapper.toDto(savedResult);
    }

    @Transactional
    public ExamResultDto updateExamResult(
            Long applicantId,
            Long resultId,
            ExamResultRequest request
    ) {
        currentUserService.checkApplicantAccess(applicantId);

        ExamResult result = examResultRepository.findById(resultId)
                .orElseThrow(() -> new ResourceNotFoundException("Результат ЕГЭ не найден"));

        if (!result.getApplicant().getId().equals(applicantId)) {
            throw new BadRequestException("Результат ЕГЭ не принадлежит указанному абитуриенту");
        }

        ExamSubject subject = examSubjectRepository.findById(request.examSubjectId())
                .orElseThrow(() -> new ResourceNotFoundException("Предмет ЕГЭ не найден"));

        if (examResultRepository.existsByApplicantIdAndExamSubjectIdAndExamYearAndIdNot(
                applicantId,
                request.examSubjectId(),
                request.examYear(),
                resultId
        )) {
            throw new BadRequestException("Результат по этому предмету за указанный год уже добавлен");
        }

        result.setExamSubject(subject);
        result.setExamYear(request.examYear());
        result.setScore(request.score());

        ExamResult savedResult = examResultRepository.save(result);

        return examResultMapper.toDto(savedResult);
    }

    @Transactional
    public void deleteExamResult(Long applicantId, Long resultId) {
        currentUserService.checkApplicantAccess(applicantId);

        ExamResult result = examResultRepository.findById(resultId)
                .orElseThrow(() -> new ResourceNotFoundException("Результат ЕГЭ не найден"));

        if (!result.getApplicant().getId().equals(applicantId)) {
            throw new BadRequestException("Результат ЕГЭ не принадлежит указанному абитуриенту");
        }

        examResultRepository.delete(result);
    }

    @Transactional(readOnly = true)
    public List<ExamResultDto> getResultsByApplicantId(Long applicantId) {
        currentUserService.checkApplicantAccess(applicantId);

        if (!applicantRepository.existsById(applicantId)) {
            throw new ResourceNotFoundException("Абитуриент не найден");
        }

        return examResultRepository.findByApplicantId(applicantId)
                .stream()
                .map(examResultMapper::toDto)
                .toList();
    }

    @Transactional(readOnly = true)
    public ExamResultLimitDto getAddLimit(Long applicantId) {
        currentUserService.checkApplicantAccess(applicantId);

        LocalDateTime windowStart = LocalDateTime.now().minusHours(LIMIT_WINDOW_HOURS);

        long used = examResultRepository.countByApplicantIdAndCreatedAtAfter(
                applicantId,
                windowStart
        );

        long remaining = Math.max(0, ADD_LIMIT_PER_HOUR - used);

        LocalDateTime resetAt = examResultRepository
                .findFirstByApplicantIdAndCreatedAtAfterOrderByCreatedAtAsc(
                        applicantId,
                        windowStart
                )
                .map(result -> result.getCreatedAt().plusHours(LIMIT_WINDOW_HOURS))
                .orElse(null);

        return new ExamResultLimitDto(
                ADD_LIMIT_PER_HOUR,
                used,
                remaining,
                resetAt
        );
    }
}
