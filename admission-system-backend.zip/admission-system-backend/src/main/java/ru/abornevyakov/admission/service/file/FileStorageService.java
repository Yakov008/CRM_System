package ru.abornevyakov.admission.service.file;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;
import ru.abornevyakov.admission.exception.BadRequestException;
import ru.abornevyakov.admission.exception.ResourceNotFoundException;

import java.io.IOException;
import java.net.MalformedURLException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.UUID;

@Service
public class FileStorageService {

    @Value("${app.upload.dir}")
    private String uploadDir;

    public StoredFile store(MultipartFile file) {
        if (file == null || file.isEmpty()) {
            throw new BadRequestException("Файл не выбран");
        }

        String originalFileName = StringUtils.cleanPath(
                file.getOriginalFilename() == null ? "file" : file.getOriginalFilename()
        );

        if (originalFileName.contains("..")) {
            throw new BadRequestException("Некорректное имя файла");
        }

        String extension = "";

        int dotIndex = originalFileName.lastIndexOf(".");
        if (dotIndex > 0) {
            extension = originalFileName.substring(dotIndex);
        }

        String storedFileName = UUID.randomUUID() + extension;

        try {
            Path uploadPath = Paths.get(uploadDir).toAbsolutePath().normalize();
            Files.createDirectories(uploadPath);

            Path targetPath = uploadPath.resolve(storedFileName).normalize();

            if (!targetPath.startsWith(uploadPath)) {
                throw new BadRequestException("Некорректный путь файла");
            }

            file.transferTo(targetPath);

            return new StoredFile(
                    originalFileName,
                    "/uploads/" + storedFileName
            );
        } catch (IOException exception) {
            throw new BadRequestException("Не удалось сохранить файл");
        }
    }

    public StoredResource load(String filePath, String originalFileName) {
        if (filePath == null || filePath.isBlank()) {
            throw new ResourceNotFoundException("Путь к файлу не указан");
        }

        String storedFileName = filePath;

        if (storedFileName.startsWith("/uploads/")) {
            storedFileName = storedFileName.substring("/uploads/".length());
        }

        try {
            Path uploadPath = Paths.get(uploadDir).toAbsolutePath().normalize();
            Path targetPath = uploadPath.resolve(storedFileName).normalize();

            if (!targetPath.startsWith(uploadPath)) {
                throw new BadRequestException("Некорректный путь файла");
            }

            if (!Files.exists(targetPath)) {
                throw new ResourceNotFoundException("Файл не найден на сервере");
            }

            Resource resource = new UrlResource(targetPath.toUri());

            if (!resource.exists() || !resource.isReadable()) {
                throw new ResourceNotFoundException("Файл недоступен для чтения");
            }

            String contentType = Files.probeContentType(targetPath);

            if (contentType == null) {
                contentType = "application/octet-stream";
            }

            return new StoredResource(
                    resource,
                    originalFileName,
                    contentType
            );
        } catch (MalformedURLException exception) {
            throw new ResourceNotFoundException("Файл не найден");
        } catch (IOException exception) {
            throw new BadRequestException("Не удалось прочитать файл");
        }
    }

    public void delete(String filePath) {
        if (filePath == null || filePath.isBlank()) {
            return;
        }

        String storedFileName = filePath;

        if (storedFileName.startsWith("/uploads/")) {
            storedFileName = storedFileName.substring("/uploads/".length());
        }

        try {
            Path uploadPath = Paths.get(uploadDir).toAbsolutePath().normalize();
            Path targetPath = uploadPath.resolve(storedFileName).normalize();

            if (!targetPath.startsWith(uploadPath)) {
                return;
            }

            Files.deleteIfExists(targetPath);
        } catch (IOException exception) {
            // Файл мог уже отсутствовать. Бизнес-операцию из-за этого не ломаем.
        }
    }

    public record StoredFile(
            String fileName,
            String filePath
    ) {
    }

    public record StoredResource(
            Resource resource,
            String fileName,
            String contentType
    ) {
    }
}