package ru.abornevyakov.admission.controller.publicapi;

import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;
import ru.abornevyakov.admission.dto.program.ProgramDto;
import ru.abornevyakov.admission.service.program.ProgramService;

import java.util.List;

@RestController
@RequestMapping("/api/programs")
@RequiredArgsConstructor
public class ProgramController {

    private final ProgramService programService;

    @GetMapping
    public List<ProgramDto> getActivePrograms() {
        return programService.getActivePrograms();
    }

    @GetMapping("/{id}")
    public ProgramDto getProgramById(@PathVariable Long id) {
        return programService.getProgramById(id);
    }
}