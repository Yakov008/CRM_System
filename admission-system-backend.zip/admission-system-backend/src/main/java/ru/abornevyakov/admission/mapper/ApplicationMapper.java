package ru.abornevyakov.admission.mapper;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import ru.abornevyakov.admission.dto.application.ApplicationDto;
import ru.abornevyakov.admission.dto.application.ApplicationPriorityDto;
import ru.abornevyakov.admission.entity.Applicant;
import ru.abornevyakov.admission.entity.ApplicantProfile;
import ru.abornevyakov.admission.entity.Application;
import ru.abornevyakov.admission.repository.ApplicationPriorityRepository;

import java.util.List;

@Component
@RequiredArgsConstructor
public class ApplicationMapper {

    private final ApplicationPriorityRepository applicationPriorityRepository;

    public ApplicationDto toDto(Application application) {
        List<ApplicationPriorityDto> priorities = applicationPriorityRepository
                .findByApplicationIdOrderByPriorityNumberAsc(application.getId())
                .stream()
                .map(priority -> new ApplicationPriorityDto(
                        priority.getId(),
                        priority.getProgram().getId(),
                        priority.getProgram().getCode(),
                        priority.getProgram().getName(),
                        priority.getPriorityNumber()
                ))
                .toList();

        Applicant applicant = application.getApplicant();
        ApplicantProfile profile = applicant.getProfile();

        return new ApplicationDto(
                application.getId(),
                applicant.getId(),
                buildFullName(profile),
                applicant.getAchievementsScore(),
                application.getAdmissionCampaign().getId(),
                application.getAdmissionCampaign().getName(),
                application.getStatus().name(),
                application.getCreatedAt(),
                application.getSubmittedAt(),
                application.getLockedUntil(),
                application.getComment(),
                priorities
        );
    }

    private String buildFullName(ApplicantProfile profile) {
        if (profile.getMiddleName() == null || profile.getMiddleName().isBlank()) {
            return profile.getLastName() + " " + profile.getFirstName();
        }

        return profile.getLastName() + " " + profile.getFirstName() + " " + profile.getMiddleName();
    }
}
