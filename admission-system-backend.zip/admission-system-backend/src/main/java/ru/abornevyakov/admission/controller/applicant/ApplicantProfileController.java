package ru.abornevyakov.admission.controller.applicant;

import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;
import ru.abornevyakov.admission.dto.applicant.ApplicantDto;
import ru.abornevyakov.admission.service.applicant.ApplicantService;

@RestController
@RequestMapping("/api/applicants")
@RequiredArgsConstructor
public class ApplicantProfileController {

    private final ApplicantService applicantService;

    @GetMapping("/{id}")
    public ApplicantDto getApplicantById(@PathVariable Long id) {
        return applicantService.getApplicantById(id);
    }
}