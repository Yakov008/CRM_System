package ru.abornevyakov.admission.dto.ranking;

public record RankingEntryDto(
        Integer place,
        Long applicantId,
        String fullName,
        Long applicationId,
        String applicationStatus,
        Integer priorityNumber,
        Integer examScoreSum,
        Integer achievementsScore,
        Integer totalScore,
        Boolean recommended,
        String recommendationStatus,
        String recommendationText
) {
}