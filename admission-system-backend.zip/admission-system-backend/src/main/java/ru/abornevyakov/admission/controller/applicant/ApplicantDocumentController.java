package ru.abornevyakov.admission.controller.applicant;

import lombok.RequiredArgsConstructor;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import ru.abornevyakov.admission.dto.document.ApplicationDocumentDto;
import ru.abornevyakov.admission.entity.enums.DocumentType;
import ru.abornevyakov.admission.service.document.ApplicationDocumentService;

import java.util.List;

@RestController
@RequestMapping("/api/applicants/{applicantId}/applications/{applicationId}/documents")
@RequiredArgsConstructor
public class ApplicantDocumentController {

    private final ApplicationDocumentService applicationDocumentService;

    @GetMapping
    public List<ApplicationDocumentDto> getDocumentsByApplication(
            @PathVariable Long applicantId,
            @PathVariable Long applicationId
    ) {
        return applicationDocumentService.getDocumentsByApplication(
                applicantId,
                applicationId
        );
    }

    @PostMapping(
            value = "/upload",
            consumes = MediaType.MULTIPART_FORM_DATA_VALUE
    )
    public ApplicationDocumentDto uploadDocument(
            @PathVariable Long applicantId,
            @PathVariable Long applicationId,
            @RequestParam DocumentType documentType,
            @RequestParam("file") MultipartFile file
    ) {
        return applicationDocumentService.uploadDocument(
                applicantId,
                applicationId,
                documentType,
                file
        );
    }

    @PutMapping(
            value = "/{documentId}/replace",
            consumes = MediaType.MULTIPART_FORM_DATA_VALUE
    )
    public ApplicationDocumentDto replaceDocument(
            @PathVariable Long applicantId,
            @PathVariable Long applicationId,
            @PathVariable Long documentId,
            @RequestParam DocumentType documentType,
            @RequestParam("file") MultipartFile file
    ) {
        return applicationDocumentService.replaceDocument(
                applicantId,
                applicationId,
                documentId,
                documentType,
                file
        );
    }

    @DeleteMapping("/{documentId}")
    public void deleteDocument(
            @PathVariable Long applicantId,
            @PathVariable Long applicationId,
            @PathVariable Long documentId
    ) {
        applicationDocumentService.deleteDocument(
                applicantId,
                applicationId,
                documentId
        );
    }
}