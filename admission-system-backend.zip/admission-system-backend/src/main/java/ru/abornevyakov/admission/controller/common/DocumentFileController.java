package ru.abornevyakov.admission.controller.common;

import lombok.RequiredArgsConstructor;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.util.UriUtils;
import ru.abornevyakov.admission.service.document.ApplicationDocumentService;

import java.nio.charset.StandardCharsets;

@RestController
@RequestMapping("/api/documents")
@RequiredArgsConstructor
public class DocumentFileController {

    private final ApplicationDocumentService applicationDocumentService;

    @GetMapping("/{documentId}/download")
    public ResponseEntity<Resource> downloadDocument(
            @PathVariable Long documentId
    ) {
        ApplicationDocumentService.DocumentFile documentFile =
                applicationDocumentService.getDocumentFile(documentId);

        String encodedFileName = UriUtils.encode(
                documentFile.fileName(),
                StandardCharsets.UTF_8
        );

        return ResponseEntity.ok()
                .header(
                        HttpHeaders.CONTENT_DISPOSITION,
                        "attachment; filename*=UTF-8''" + encodedFileName
                )
                .header(HttpHeaders.CONTENT_TYPE, documentFile.contentType())
                .body(documentFile.resource());
    }
}