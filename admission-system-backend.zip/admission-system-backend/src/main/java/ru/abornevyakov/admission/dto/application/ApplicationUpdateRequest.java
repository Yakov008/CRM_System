package ru.abornevyakov.admission.dto.application;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Size;

import java.util.List;

public record ApplicationUpdateRequest(

        @NotEmpty
        @Size(max = 5)
        List<@Valid ApplicationPriorityRequest> priorities,

        String comment
) {
}