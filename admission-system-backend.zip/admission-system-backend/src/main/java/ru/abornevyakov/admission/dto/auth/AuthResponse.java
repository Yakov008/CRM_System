package ru.abornevyakov.admission.dto.auth;

public record AuthResponse(
        String token,
        Long userId,
        Long applicantId,
        String email,
        String role
) {
}