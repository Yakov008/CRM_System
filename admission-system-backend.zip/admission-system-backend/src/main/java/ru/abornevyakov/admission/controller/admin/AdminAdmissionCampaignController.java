package ru.abornevyakov.admission.controller.admin;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;
import ru.abornevyakov.admission.dto.program.AdmissionCampaignDto;
import ru.abornevyakov.admission.dto.program.AdmissionCampaignRequest;
import ru.abornevyakov.admission.service.program.AdmissionCampaignService;

import java.util.List;

@RestController
@RequestMapping("/api/admin/admission-campaigns")
@RequiredArgsConstructor
public class AdminAdmissionCampaignController {

    private final AdmissionCampaignService admissionCampaignService;

    @GetMapping
    public List<AdmissionCampaignDto> getAllCampaigns() {
        return admissionCampaignService.getAllCampaigns();
    }

    @PostMapping
    public AdmissionCampaignDto createCampaign(
            @Valid @RequestBody AdmissionCampaignRequest request
    ) {
        return admissionCampaignService.createCampaign(request);
    }

    @PutMapping("/{campaignId}")
    public AdmissionCampaignDto updateCampaign(
            @PathVariable Long campaignId,
            @Valid @RequestBody AdmissionCampaignRequest request
    ) {
        return admissionCampaignService.updateCampaign(campaignId, request);
    }
}