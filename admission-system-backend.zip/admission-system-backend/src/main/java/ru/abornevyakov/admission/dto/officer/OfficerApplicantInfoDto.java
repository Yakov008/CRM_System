package ru.abornevyakov.admission.dto.officer;

import java.time.LocalDate;

public record OfficerApplicantInfoDto(
        Long applicantId,
        Long userId,
        String email,
        String lastName,
        String firstName,
        String middleName,
        LocalDate birthDate,
        String phone,
        String passportNumber,
        Integer achievementsScore
) {
}