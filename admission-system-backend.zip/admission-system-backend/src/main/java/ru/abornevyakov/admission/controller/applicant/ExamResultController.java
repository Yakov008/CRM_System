package ru.abornevyakov.admission.controller.applicant;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;
import ru.abornevyakov.admission.dto.exam.ExamResultDto;
import ru.abornevyakov.admission.dto.exam.ExamResultRequest;
import ru.abornevyakov.admission.service.exam.ExamResultService;
import ru.abornevyakov.admission.dto.exam.ExamResultLimitDto;

import java.util.List;

@RestController
@RequestMapping("/api/applicants/{applicantId}/exam-results")
@RequiredArgsConstructor
public class ExamResultController {

    private final ExamResultService examResultService;

    @GetMapping
    public List<ExamResultDto> getResultsByApplicantId(
            @PathVariable Long applicantId
    ) {
        return examResultService.getResultsByApplicantId(applicantId);
    }

    @PostMapping
    public ExamResultDto addExamResult(
            @PathVariable Long applicantId,
            @Valid @RequestBody ExamResultRequest request
    ) {
        return examResultService.addExamResult(applicantId, request);
    }

    @PutMapping("/{resultId}")
    public ExamResultDto updateExamResult(
            @PathVariable Long applicantId,
            @PathVariable Long resultId,
            @Valid @RequestBody ExamResultRequest request
    ) {
        return examResultService.updateExamResult(
                applicantId,
                resultId,
                request
        );
    }

    @DeleteMapping("/{resultId}")
    public void deleteExamResult(
            @PathVariable Long applicantId,
            @PathVariable Long resultId
    ) {
        examResultService.deleteExamResult(applicantId, resultId);
    }

    @GetMapping("/limit")
    public ExamResultLimitDto getAddLimit(
            @PathVariable Long applicantId
    ) {
        return examResultService.getAddLimit(applicantId);
    }
}