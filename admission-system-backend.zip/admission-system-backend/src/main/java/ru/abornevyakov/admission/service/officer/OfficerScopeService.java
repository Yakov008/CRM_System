package ru.abornevyakov.admission.service.officer;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import ru.abornevyakov.admission.entity.Application;
import ru.abornevyakov.admission.entity.ApplicationDocument;
import ru.abornevyakov.admission.entity.User;
import ru.abornevyakov.admission.entity.enums.RoleType;
import ru.abornevyakov.admission.exception.ForbiddenException;
import ru.abornevyakov.admission.exception.ResourceNotFoundException;
import ru.abornevyakov.admission.repository.ApplicationPriorityRepository;
import ru.abornevyakov.admission.repository.UserRepository;
import ru.abornevyakov.admission.security.UserPrincipal;
import ru.abornevyakov.admission.service.auth.CurrentUserService;

import java.util.List;

@Service
@RequiredArgsConstructor
public class OfficerScopeService {

    private final CurrentUserService currentUserService;
    private final UserRepository userRepository;
    private final ApplicationPriorityRepository applicationPriorityRepository;

    public List<Application> filterApplicationsForCurrentUser(List<Application> applications) {
        UserPrincipal principal = currentUserService.getCurrentPrincipal();

        if (principal.getRole() == RoleType.ADMIN) {
            return applications;
        }

        String facultyName = getCurrentOfficerFacultyName(principal);

        return applications.stream()
                .filter(application -> isApplicationInFaculty(application.getId(), facultyName))
                .toList();
    }

    public boolean canAccessApplication(Application application) {
        UserPrincipal principal = currentUserService.getCurrentPrincipal();

        if (principal.getRole() == RoleType.ADMIN) {
            return true;
        }

        String facultyName = getCurrentOfficerFacultyName(principal);

        return isApplicationInFaculty(application.getId(), facultyName);
    }

    public void checkApplicationAccess(Application application) {
        if (!canAccessApplication(application)) {
            throw new ForbiddenException("Нет доступа к заявлению другого факультета");
        }
    }

    public void checkDocumentAccess(ApplicationDocument document) {
        checkApplicationAccess(document.getApplication());
    }

    public void checkApplicantAccess(Long applicantId) {
        UserPrincipal principal = currentUserService.getCurrentPrincipal();

        if (principal.getRole() == RoleType.ADMIN) {
            return;
        }

        String facultyName = getCurrentOfficerFacultyName(principal);

        if (!applicationPriorityRepository.existsByApplicationApplicantIdAndProgramFacultyNameIgnoreCase(
                applicantId,
                facultyName
        )) {
            throw new ForbiddenException("Нет доступа к абитуриенту другого факультета");
        }
    }

    private boolean isApplicationInFaculty(Long applicationId, String facultyName) {
        return applicationPriorityRepository.existsByApplicationIdAndProgramFacultyNameIgnoreCase(
                applicationId,
                facultyName
        );
    }

    private String getCurrentOfficerFacultyName(UserPrincipal principal) {
        if (principal.getRole() != RoleType.OFFICER) {
            throw new ForbiddenException("Операция доступна только сотруднику или администратору");
        }

        User user = userRepository.findById(principal.getUserId())
                .orElseThrow(() -> new ResourceNotFoundException("Пользователь не найден"));

        if (user.getFacultyName() == null || user.getFacultyName().isBlank()) {
            throw new ForbiddenException("Для сотрудника не указан закреплённый факультет");
        }

        return user.getFacultyName();
    }
}
