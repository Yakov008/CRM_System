package ru.abornevyakov.admission.service.admin;

import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.abornevyakov.admission.dto.staff.StaffUserCreateRequest;
import ru.abornevyakov.admission.dto.staff.StaffUserDto;
import ru.abornevyakov.admission.dto.staff.StaffUserUpdateRequest;
import ru.abornevyakov.admission.entity.User;
import ru.abornevyakov.admission.entity.enums.RoleType;
import ru.abornevyakov.admission.exception.BadRequestException;
import ru.abornevyakov.admission.exception.ResourceNotFoundException;
import ru.abornevyakov.admission.mapper.StaffUserMapper;
import ru.abornevyakov.admission.repository.FacultyRepository;
import ru.abornevyakov.admission.repository.UserRepository;

import java.util.List;
import java.util.Comparator;

@Service
@RequiredArgsConstructor
public class StaffUserAdminService {

    private final UserRepository userRepository;
    private final FacultyRepository facultyRepository;
    private final PasswordEncoder passwordEncoder;
    private final StaffUserMapper staffUserMapper;

    @Transactional(readOnly = true)
    public List<StaffUserDto> getStaffUsers() {
        return userRepository.findByRoleOrderByEmailAsc(RoleType.OFFICER)
                .stream()
                .sorted(Comparator.comparing(User::getId))
                .map(staffUserMapper::toDto)
                .toList();
    }

    @Transactional
    public StaffUserDto createStaffUser(StaffUserCreateRequest request) {
        String email = normalizeEmail(request.email());
        String facultyName = normalizeFacultyName(request.facultyName());
        validateFacultyExists(facultyName);

        if (userRepository.existsByEmail(email)) {
            throw new BadRequestException("Пользователь с таким email уже существует");
        }

        User user = new User();
        user.setEmail(email);
        user.setPassword(passwordEncoder.encode(request.password()));
        user.setRole(RoleType.OFFICER);
        user.setFacultyName(facultyName);
        user.setActive(request.active());

        return staffUserMapper.toDto(userRepository.save(user));
    }

    @Transactional
    public StaffUserDto updateStaffUser(Long userId, StaffUserUpdateRequest request) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("Сотрудник не найден"));

        if (user.getRole() != RoleType.OFFICER) {
            throw new BadRequestException("Можно изменять только учётные записи сотрудников");
        }

        String email = normalizeEmail(request.email());
        String facultyName = normalizeFacultyName(request.facultyName());
        validateFacultyExists(facultyName);

        if (userRepository.existsByEmailAndIdNot(email, userId)) {
            throw new BadRequestException("Пользователь с таким email уже существует");
        }

        user.setEmail(email);
        user.setFacultyName(facultyName);
        user.setActive(request.active());

        if (request.password() != null && !request.password().isBlank()) {
            user.setPassword(passwordEncoder.encode(request.password()));
        }

        return staffUserMapper.toDto(userRepository.save(user));
    }

    private String normalizeEmail(String email) {
        return email.trim().toLowerCase();
    }

    private String normalizeFacultyName(String facultyName) {
        return facultyName.trim();
    }

    private void validateFacultyExists(String facultyName) {
        if (!facultyRepository.existsByNameIgnoreCase(facultyName)) {
            throw new BadRequestException("Сначала добавьте факультет в справочник факультетов");
        }
    }
}
