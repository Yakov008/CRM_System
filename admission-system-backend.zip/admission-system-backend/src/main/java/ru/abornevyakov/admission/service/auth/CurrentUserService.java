package ru.abornevyakov.admission.service.auth;

import lombok.RequiredArgsConstructor;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import ru.abornevyakov.admission.entity.Applicant;
import ru.abornevyakov.admission.exception.ForbiddenException;
import ru.abornevyakov.admission.exception.ResourceNotFoundException;
import ru.abornevyakov.admission.exception.UnauthorizedException;
import ru.abornevyakov.admission.repository.ApplicantRepository;
import ru.abornevyakov.admission.security.UserPrincipal;

@Service
@RequiredArgsConstructor
public class CurrentUserService {

    private final ApplicantRepository applicantRepository;

    public Long getCurrentUserId() {
        return getCurrentPrincipal().getUserId();
    }

    public Long getCurrentApplicantId() {
        Long currentUserId = getCurrentUserId();

        Applicant applicant = applicantRepository.findByUserId(currentUserId)
                .orElseThrow(() -> new ResourceNotFoundException("Профиль абитуриента не найден"));

        return applicant.getId();
    }

    public UserPrincipal getCurrentPrincipal() {
        Authentication authentication = SecurityContextHolder
                .getContext()
                .getAuthentication();

        if (authentication == null || !(authentication.getPrincipal() instanceof UserPrincipal principal)) {
            throw new UnauthorizedException("Необходима авторизация");
        }

        return principal;
    }

    public void checkApplicantAccess(Long applicantIdFromUrl) {
        Long currentApplicantId = getCurrentApplicantId();

        if (!currentApplicantId.equals(applicantIdFromUrl)) {
            throw new ForbiddenException("Нет доступа к данным другого абитуриента");
        }
    }
}
