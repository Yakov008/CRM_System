package ru.abornevyakov.admission.controller.publicapi;

import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import ru.abornevyakov.admission.dto.exam.ExamSubjectDto;
import ru.abornevyakov.admission.service.exam.ExamSubjectService;

import java.util.List;

@RestController
@RequestMapping("/api/exam-subjects")
@RequiredArgsConstructor
public class ExamSubjectController {

    private final ExamSubjectService examSubjectService;

    @GetMapping
    public List<ExamSubjectDto> getAllSubjects() {
        return examSubjectService.getAllSubjects();
    }
}