package ru.abornevyakov.admission.mapper;

import org.springframework.stereotype.Component;
import ru.abornevyakov.admission.dto.officer.OfficerApplicantInfoDto;
import ru.abornevyakov.admission.entity.Applicant;
import ru.abornevyakov.admission.entity.ApplicantProfile;

@Component
public class OfficerApplicantInfoMapper {

    public OfficerApplicantInfoDto toDto(Applicant applicant) {
        ApplicantProfile profile = applicant.getProfile();

        return new OfficerApplicantInfoDto(
                applicant.getId(),
                applicant.getUser().getId(),
                applicant.getUser().getEmail(),
                profile.getLastName(),
                profile.getFirstName(),
                profile.getMiddleName(),
                profile.getBirthDate(),
                profile.getPhone(),
                profile.getPassportNumber(),
                applicant.getAchievementsScore()
        );
    }
}
