package ru.abornevyakov.admission.mapper;

import org.springframework.stereotype.Component;
import ru.abornevyakov.admission.dto.applicant.ApplicantDto;
import ru.abornevyakov.admission.entity.Applicant;
import ru.abornevyakov.admission.entity.ApplicantProfile;
import ru.abornevyakov.admission.entity.User;

@Component
public class ApplicantMapper {

    public ApplicantDto toDto(Applicant applicant) {
        User user = applicant.getUser();
        ApplicantProfile profile = applicant.getProfile();

        return new ApplicantDto(
                applicant.getId(),
                user.getId(),
                user.getEmail(),
                user.getRole().name(),
                profile.getLastName(),
                profile.getFirstName(),
                profile.getMiddleName(),
                profile.getBirthDate(),
                profile.getPhone(),
                profile.getPassportNumber(),
                applicant.getAchievementsScore()
        );
    }
}
