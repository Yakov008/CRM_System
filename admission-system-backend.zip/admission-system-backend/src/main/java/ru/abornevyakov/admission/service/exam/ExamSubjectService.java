package ru.abornevyakov.admission.service.exam;

import lombok.RequiredArgsConstructor;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.abornevyakov.admission.dto.exam.ExamSubjectDto;
import ru.abornevyakov.admission.dto.exam.ExamSubjectRequest;
import ru.abornevyakov.admission.entity.ExamSubject;
import ru.abornevyakov.admission.exception.BadRequestException;
import ru.abornevyakov.admission.exception.ResourceNotFoundException;
import ru.abornevyakov.admission.mapper.ExamSubjectMapper;
import ru.abornevyakov.admission.repository.ExamResultRepository;
import ru.abornevyakov.admission.repository.ExamSubjectRepository;
import ru.abornevyakov.admission.repository.ProgramExamRequirementRepository;

import java.util.List;

@Service
@RequiredArgsConstructor
public class ExamSubjectService {

    private final ExamSubjectRepository examSubjectRepository;
    private final ProgramExamRequirementRepository programExamRequirementRepository;
    private final ExamResultRepository examResultRepository;
    private final ExamSubjectMapper examSubjectMapper;

    @Transactional(readOnly = true)
    public List<ExamSubjectDto> getAllSubjects() {
        return examSubjectRepository.findAll(Sort.by(Sort.Direction.ASC, "id"))
                .stream()
                .map(examSubjectMapper::toDto)
                .toList();
    }

    @Transactional
    public ExamSubjectDto createSubject(ExamSubjectRequest request) {
        String name = request.name().trim();

        if (examSubjectRepository.existsByNameIgnoreCase(name)) {
            throw new BadRequestException("Предмет с таким названием уже существует");
        }

        ExamSubject subject = new ExamSubject();
        subject.setName(name);

        ExamSubject savedSubject = examSubjectRepository.save(subject);

        return examSubjectMapper.toDto(savedSubject);
    }

    @Transactional
    public ExamSubjectDto updateSubject(Long subjectId, ExamSubjectRequest request) {
        String name = request.name().trim();

        ExamSubject subject = examSubjectRepository.findById(subjectId)
                .orElseThrow(() -> new ResourceNotFoundException("Предмет ЕГЭ не найден"));

        if (examSubjectRepository.existsByNameIgnoreCaseAndIdNot(name, subjectId)) {
            throw new BadRequestException("Предмет с таким названием уже существует");
        }

        subject.setName(name);

        ExamSubject savedSubject = examSubjectRepository.save(subject);

        return examSubjectMapper.toDto(savedSubject);
    }

    @Transactional
    public void deleteSubject(Long subjectId) {
        ExamSubject subject = examSubjectRepository.findById(subjectId)
                .orElseThrow(() -> new ResourceNotFoundException("Предмет ЕГЭ не найден"));

        if (programExamRequirementRepository.existsByExamSubjectId(subjectId)) {
            throw new BadRequestException("Предмет используется в требованиях направлений");
        }

        if (examResultRepository.existsByExamSubjectId(subjectId)) {
            throw new BadRequestException("По предмету уже есть результаты ЕГЭ");
        }

        try {
            examSubjectRepository.delete(subject);
            examSubjectRepository.flush();
        } catch (DataIntegrityViolationException exception) {
            throw new BadRequestException("Предмет нельзя удалить: он уже используется в требованиях или результатах ЕГЭ");
        }
    }
}
