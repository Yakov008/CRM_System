package ru.abornevyakov.admission.dto.program;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

public record ProgramRequest(

        @NotNull(message = "Приёмная кампания обязательна")
        Long admissionCampaignId,

        @NotBlank(message = "Код направления обязателен")
        @Size(max = 20, message = "Код направления не должен превышать 20 символов")
        String code,

        @NotBlank(message = "Название направления обязательно")
        @Size(max = 255, message = "Название направления не должно превышать 255 символов")
        String name,

        @NotBlank(message = "Факультет обязателен")
        @Size(max = 255, message = "Название факультета не должно превышать 255 символов")
        String facultyName,

        @NotNull(message = "Количество бюджетных мест обязательно")
        @Min(value = 0, message = "Количество бюджетных мест не может быть отрицательным")
        Integer budgetPlaces,

        @NotNull(message = "Количество платных мест обязательно")
        @Min(value = 0, message = "Количество платных мест не может быть отрицательным")
        Integer paidPlaces,

        @NotNull(message = "Признак активности обязателен")
        Boolean active
) {
}