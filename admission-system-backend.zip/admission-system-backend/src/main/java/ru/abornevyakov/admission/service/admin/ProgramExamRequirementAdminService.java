package ru.abornevyakov.admission.service.admin;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.abornevyakov.admission.dto.program.ProgramExamRequirementAdminDto;
import ru.abornevyakov.admission.dto.program.ProgramExamRequirementAdminRequest;
import ru.abornevyakov.admission.entity.ExamSubject;
import ru.abornevyakov.admission.entity.MinimumExamScore;
import ru.abornevyakov.admission.entity.Program;
import ru.abornevyakov.admission.entity.ProgramExamRequirement;
import ru.abornevyakov.admission.exception.BadRequestException;
import ru.abornevyakov.admission.exception.ResourceNotFoundException;
import ru.abornevyakov.admission.mapper.ProgramExamRequirementAdminMapper;
import ru.abornevyakov.admission.repository.ExamSubjectRepository;
import ru.abornevyakov.admission.repository.ProgramExamRequirementRepository;
import ru.abornevyakov.admission.repository.ProgramRepository;

import java.util.Comparator;
import java.util.List;

@Service
@RequiredArgsConstructor
public class ProgramExamRequirementAdminService {

    private final ProgramExamRequirementRepository requirementRepository;
    private final ProgramRepository programRepository;
    private final ExamSubjectRepository examSubjectRepository;
    private final ProgramExamRequirementAdminMapper requirementMapper;

    @Transactional(readOnly = true)
    public List<ProgramExamRequirementAdminDto> getRequirementsByProgramId(Long programId) {
        if (!programRepository.existsById(programId)) {
            throw new ResourceNotFoundException("Направление не найдено");
        }

        return requirementRepository.findByProgramId(programId)
                .stream()
                .sorted(Comparator.comparing(requirement -> requirement.getExamSubject().getName()))
                .map(requirementMapper::toDto)
                .toList();
    }

    @Transactional
    public ProgramExamRequirementAdminDto createRequirement(
            ProgramExamRequirementAdminRequest request
    ) {
        if (requirementRepository.existsByProgramIdAndExamSubjectId(
                request.programId(),
                request.examSubjectId()
        )) {
            throw new BadRequestException("Этот предмет уже добавлен к выбранному направлению");
        }

        Program program = programRepository.findById(request.programId())
                .orElseThrow(() -> new ResourceNotFoundException("Направление не найдено"));

        ExamSubject subject = examSubjectRepository.findById(request.examSubjectId())
                .orElseThrow(() -> new ResourceNotFoundException("Предмет ЕГЭ не найден"));

        MinimumExamScore minimumExamScore = new MinimumExamScore();
        minimumExamScore.setScore(request.minimumScore());

        ProgramExamRequirement requirement = new ProgramExamRequirement();
        requirement.setProgram(program);
        requirement.setExamSubject(subject);
        requirement.setMinimumExamScore(minimumExamScore);

        ProgramExamRequirement savedRequirement = requirementRepository.save(requirement);

        return requirementMapper.toDto(savedRequirement);
    }

    @Transactional
    public ProgramExamRequirementAdminDto updateRequirement(
            Long requirementId,
            ProgramExamRequirementAdminRequest request
    ) {
        ProgramExamRequirement requirement = requirementRepository.findById(requirementId)
                .orElseThrow(() -> new ResourceNotFoundException("Требование не найдено"));

        if (requirementRepository.existsByProgramIdAndExamSubjectIdAndIdNot(
                request.programId(),
                request.examSubjectId(),
                requirementId
        )) {
            throw new BadRequestException("Этот предмет уже добавлен к выбранному направлению");
        }

        Program program = programRepository.findById(request.programId())
                .orElseThrow(() -> new ResourceNotFoundException("Направление не найдено"));

        ExamSubject subject = examSubjectRepository.findById(request.examSubjectId())
                .orElseThrow(() -> new ResourceNotFoundException("Предмет ЕГЭ не найден"));

        MinimumExamScore minimumExamScore = requirement.getMinimumExamScore();

        if (minimumExamScore == null) {
            minimumExamScore = new MinimumExamScore();
        }

        minimumExamScore.setScore(request.minimumScore());

        requirement.setProgram(program);
        requirement.setExamSubject(subject);
        requirement.setMinimumExamScore(minimumExamScore);

        ProgramExamRequirement savedRequirement = requirementRepository.save(requirement);

        return requirementMapper.toDto(savedRequirement);
    }

    @Transactional
    public void deleteRequirement(Long requirementId) {
        ProgramExamRequirement requirement = requirementRepository.findById(requirementId)
                .orElseThrow(() -> new ResourceNotFoundException("Требование не найдено"));

        requirementRepository.delete(requirement);
    }
}
