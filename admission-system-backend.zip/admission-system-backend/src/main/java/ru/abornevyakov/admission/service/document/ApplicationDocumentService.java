package ru.abornevyakov.admission.service.document;

import lombok.RequiredArgsConstructor;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;
import ru.abornevyakov.admission.dto.document.ApplicationDocumentDto;
import ru.abornevyakov.admission.dto.document.ApplicationDocumentStatusUpdateRequest;
import ru.abornevyakov.admission.entity.Application;
import ru.abornevyakov.admission.entity.ApplicationDocument;
import ru.abornevyakov.admission.entity.enums.DocumentStatus;
import ru.abornevyakov.admission.entity.enums.DocumentType;
import ru.abornevyakov.admission.entity.enums.RoleType;
import ru.abornevyakov.admission.exception.BadRequestException;
import ru.abornevyakov.admission.exception.ForbiddenException;
import ru.abornevyakov.admission.exception.ResourceNotFoundException;
import ru.abornevyakov.admission.mapper.ApplicationDocumentMapper;
import ru.abornevyakov.admission.repository.ApplicationDocumentRepository;
import ru.abornevyakov.admission.repository.ApplicationRepository;
import ru.abornevyakov.admission.security.UserPrincipal;
import ru.abornevyakov.admission.service.auth.CurrentUserService;
import ru.abornevyakov.admission.service.file.FileStorageService;
import ru.abornevyakov.admission.service.officer.OfficerScopeService;

import java.time.LocalDateTime;
import java.util.List;

@Service
@RequiredArgsConstructor
public class ApplicationDocumentService {

    private final ApplicationDocumentRepository applicationDocumentRepository;
    private final ApplicationRepository applicationRepository;
    private final CurrentUserService currentUserService;
    private final FileStorageService fileStorageService;
    private final OfficerScopeService officerScopeService;
    private final ApplicationDocumentMapper applicationDocumentMapper;

    @Transactional
    public ApplicationDocumentDto uploadDocument(
            Long applicantId,
            Long applicationId,
            DocumentType documentType,
            MultipartFile file
    ) {
        currentUserService.checkApplicantAccess(applicantId);

        Application application = applicationRepository.findById(applicationId)
                .orElseThrow(() -> new ResourceNotFoundException("Заявление не найдено"));

        if (!application.getApplicant().getId().equals(applicantId)) {
            throw new BadRequestException("Заявление не принадлежит указанному абитуриенту");
        }

        FileStorageService.StoredFile storedFile = fileStorageService.store(file);

        ApplicationDocument document = new ApplicationDocument();
        document.setApplication(application);
        document.setDocumentType(documentType);
        document.setFileName(storedFile.fileName());
        document.setFilePath(storedFile.filePath());
        document.setStatus(DocumentStatus.UPLOADED);

        ApplicationDocument savedDocument = applicationDocumentRepository.save(document);

        return applicationDocumentMapper.toDto(savedDocument);
    }

    @Transactional
    public void deleteDocument(
            Long applicantId,
            Long applicationId,
            Long documentId
    ) {
        currentUserService.checkApplicantAccess(applicantId);

        ApplicationDocument document = applicationDocumentRepository.findById(documentId)
                .orElseThrow(() -> new ResourceNotFoundException("Документ не найден"));

        validateDocumentBelongsToApplication(document, applicantId, applicationId);

        if (document.getStatus() == DocumentStatus.VERIFIED) {
            throw new BadRequestException("Проверенный документ нельзя удалить");
        }

        String filePath = document.getFilePath();

        applicationDocumentRepository.delete(document);
        fileStorageService.delete(filePath);
    }

    @Transactional
    public ApplicationDocumentDto replaceDocument(
            Long applicantId,
            Long applicationId,
            Long documentId,
            DocumentType documentType,
            MultipartFile file
    ) {
        currentUserService.checkApplicantAccess(applicantId);

        ApplicationDocument document = applicationDocumentRepository.findById(documentId)
                .orElseThrow(() -> new ResourceNotFoundException("Документ не найден"));

        validateDocumentBelongsToApplication(document, applicantId, applicationId);

        if (document.getStatus() == DocumentStatus.VERIFIED) {
            throw new BadRequestException("Проверенный документ нельзя заменить");
        }

        String oldFilePath = document.getFilePath();

        FileStorageService.StoredFile storedFile = fileStorageService.store(file);

        document.setDocumentType(documentType);
        document.setFileName(storedFile.fileName());
        document.setFilePath(storedFile.filePath());
        document.setStatus(DocumentStatus.UPLOADED);
        document.setComment(null);
        document.setUploadedAt(LocalDateTime.now());

        ApplicationDocument savedDocument = applicationDocumentRepository.save(document);

        fileStorageService.delete(oldFilePath);

        return applicationDocumentMapper.toDto(savedDocument);
    }

    @Transactional(readOnly = true)
    public DocumentFile getDocumentFile(Long documentId) {
        ApplicationDocument document = applicationDocumentRepository.findById(documentId)
                .orElseThrow(() -> new ResourceNotFoundException("Документ не найден"));

        UserPrincipal principal = currentUserService.getCurrentPrincipal();

        if (principal.getRole() == RoleType.APPLICANT) {
            Long currentApplicantId = currentUserService.getCurrentApplicantId();
            Long documentApplicantId = document.getApplication().getApplicant().getId();

            if (!currentApplicantId.equals(documentApplicantId)) {
                throw new ForbiddenException("Нет доступа к документу другого абитуриента");
            }
        } else {
            officerScopeService.checkDocumentAccess(document);
        }

        FileStorageService.StoredResource storedResource = fileStorageService.load(
                document.getFilePath(),
                document.getFileName()
        );

        return new DocumentFile(
                storedResource.resource(),
                storedResource.fileName(),
                storedResource.contentType()
        );
    }

    @Transactional(readOnly = true)
    public List<ApplicationDocumentDto> getDocumentsByApplication(
            Long applicantId,
            Long applicationId
    ) {
        currentUserService.checkApplicantAccess(applicantId);

        Application application = applicationRepository.findById(applicationId)
                .orElseThrow(() -> new ResourceNotFoundException("Заявление не найдено"));

        if (!application.getApplicant().getId().equals(applicantId)) {
            throw new BadRequestException("Заявление не принадлежит указанному абитуриенту");
        }

        return applicationDocumentRepository.findByApplicationId(applicationId)
                .stream()
                .map(applicationDocumentMapper::toDto)
                .toList();
    }

    @Transactional(readOnly = true)
    public List<ApplicationDocumentDto> getDocumentsByStatus(DocumentStatus status) {
        return applicationDocumentRepository.findByStatus(status)
                .stream()
                .filter(document -> isDocumentVisibleForCurrentUser(document))
                .map(applicationDocumentMapper::toDto)
                .toList();
    }

    @Transactional
    public ApplicationDocumentDto updateDocumentStatus(
            Long documentId,
            ApplicationDocumentStatusUpdateRequest request
    ) {
        ApplicationDocument document = applicationDocumentRepository.findById(documentId)
                .orElseThrow(() -> new ResourceNotFoundException("Документ не найден"));

        officerScopeService.checkDocumentAccess(document);

        document.setStatus(request.status());
        document.setComment(request.comment());

        ApplicationDocument savedDocument = applicationDocumentRepository.save(document);

        return applicationDocumentMapper.toDto(savedDocument);
    }

    @Transactional(readOnly = true)
    public List<ApplicationDocumentDto> getAllDocuments() {
        return applicationDocumentRepository.findAll()
                .stream()
                .filter(document -> isDocumentVisibleForCurrentUser(document))
                .map(applicationDocumentMapper::toDto)
                .toList();
    }

    private boolean isDocumentVisibleForCurrentUser(ApplicationDocument document) {
        return officerScopeService.canAccessApplication(document.getApplication());
    }

    private void validateDocumentBelongsToApplication(
            ApplicationDocument document,
            Long applicantId,
            Long applicationId
    ) {
        Application application = document.getApplication();

        if (!application.getId().equals(applicationId)) {
            throw new BadRequestException("Документ не относится к выбранному заявлению");
        }

        if (!application.getApplicant().getId().equals(applicantId)) {
            throw new BadRequestException("Заявление не принадлежит указанному абитуриенту");
        }
    }

    public record DocumentFile(
            Resource resource,
            String fileName,
            String contentType
    ) {
    }
}
