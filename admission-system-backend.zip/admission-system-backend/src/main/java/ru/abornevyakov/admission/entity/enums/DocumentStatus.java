package ru.abornevyakov.admission.entity.enums;

public enum DocumentStatus {
    UPLOADED,
    VERIFIED,
    REJECTED
}