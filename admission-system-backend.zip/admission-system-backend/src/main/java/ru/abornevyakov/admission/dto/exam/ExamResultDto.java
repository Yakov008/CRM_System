package ru.abornevyakov.admission.dto.exam;

import java.time.LocalDateTime;

public record ExamResultDto(
        Long id,
        Long applicantId,
        Long examSubjectId,
        String examSubjectName,
        Integer examYear,
        Integer score,
        LocalDateTime createdAt
) {
}