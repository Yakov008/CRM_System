package ru.abornevyakov.admission.dto.application;

import jakarta.validation.constraints.NotNull;
import ru.abornevyakov.admission.entity.enums.ApplicationStatus;

public record ApplicationStatusUpdateRequest(

        @NotNull
        ApplicationStatus status,

        String comment
) {
}