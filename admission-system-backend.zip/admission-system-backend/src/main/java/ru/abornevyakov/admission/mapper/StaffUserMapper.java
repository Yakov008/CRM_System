package ru.abornevyakov.admission.mapper;

import org.springframework.stereotype.Component;
import ru.abornevyakov.admission.dto.staff.StaffUserDto;
import ru.abornevyakov.admission.entity.User;

@Component
public class StaffUserMapper {

    public StaffUserDto toDto(User user) {
        return new StaffUserDto(
                user.getId(),
                user.getEmail(),
                user.getRole().name(),
                user.getFacultyName(),
                user.isActive()
        );
    }
}
