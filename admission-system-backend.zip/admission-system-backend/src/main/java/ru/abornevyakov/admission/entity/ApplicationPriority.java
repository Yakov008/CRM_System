package ru.abornevyakov.admission.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.Min;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(
        name = "application_priorities",
        uniqueConstraints = {
                @UniqueConstraint(columnNames = {"application_id", "priority_number"}),
                @UniqueConstraint(columnNames = {"application_id", "program_id"})
        }
)
@Getter
@Setter
@NoArgsConstructor
public class ApplicationPriority {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(optional = false)
    @JoinColumn(name = "application_id", nullable = false)
    private Application application;

    @ManyToOne(optional = false)
    @JoinColumn(name = "program_id", nullable = false)
    private Program program;

    @Min(1)
    @Column(name = "priority_number", nullable = false)
    private Integer priorityNumber;
}