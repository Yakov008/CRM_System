package ru.abornevyakov.admission.service.ranking;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.abornevyakov.admission.dto.ranking.ProgramRankingDto;
import ru.abornevyakov.admission.dto.ranking.RankingEntryDto;
import ru.abornevyakov.admission.entity.*;
import ru.abornevyakov.admission.entity.enums.ApplicationStatus;
import ru.abornevyakov.admission.exception.ResourceNotFoundException;
import ru.abornevyakov.admission.repository.ApplicationPriorityRepository;
import ru.abornevyakov.admission.repository.ApplicationRepository;
import ru.abornevyakov.admission.repository.ExamResultRepository;
import ru.abornevyakov.admission.repository.ProgramExamRequirementRepository;
import ru.abornevyakov.admission.repository.ProgramRepository;

import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class RankingService {

    private final ProgramRepository programRepository;
    private final ApplicationRepository applicationRepository;
    private final ApplicationPriorityRepository applicationPriorityRepository;
    private final ProgramExamRequirementRepository programExamRequirementRepository;
    private final ExamResultRepository examResultRepository;

    private static final Comparator<RankingCandidate> RANKING_COMPARATOR =
            Comparator.comparing(RankingCandidate::totalScore, Comparator.reverseOrder())
                    .thenComparing(RankingCandidate::examScoreSum, Comparator.reverseOrder())
                    .thenComparing(RankingCandidate::achievementsScore, Comparator.reverseOrder())
                    .thenComparing(RankingCandidate::applicationId);

    @Transactional(readOnly = true)
    public ProgramRankingDto getRankingByProgramId(Long programId) {
        Program selectedProgram = programRepository.findById(programId)
                .orElseThrow(() -> new ResourceNotFoundException("Направление не найдено"));

        Long campaignId = selectedProgram.getAdmissionCampaign().getId();

        List<Application> applications = applicationRepository.findByAdmissionCampaignId(campaignId)
                .stream()
                .filter(this::isApplicationVisibleInRanking)
                .toList();

        Map<Long, List<ApplicationPriority>> prioritiesByApplication = applications.stream()
                .collect(Collectors.toMap(
                        Application::getId,
                        application -> applicationPriorityRepository
                                .findByApplicationIdOrderByPriorityNumberAsc(application.getId())
                ));

        CandidateData candidateData = buildCandidateData(
                applications,
                prioritiesByApplication,
                loadRequirementsByProgram(prioritiesByApplication),
                loadResultsByApplicant(applications)
        );

        Map<Long, RankingCandidate> recommendedByApplication =
                calculateBudgetRecommendations(applications, prioritiesByApplication, candidateData.candidateIndex());

        List<RankingCandidate> selectedProgramCandidates = candidateData
                .candidatesByProgram()
                .getOrDefault(programId, List.of())
                .stream()
                .sorted(RANKING_COMPARATOR)
                .toList();

        List<RankingEntryDto> entries = new ArrayList<>();

        for (int index = 0; index < selectedProgramCandidates.size(); index++) {
            RankingCandidate candidate = selectedProgramCandidates.get(index);
            RankingCandidate recommendedCandidate = recommendedByApplication.get(candidate.applicationId());

            RecommendationInfo recommendationInfo = buildRecommendationInfo(candidate, recommendedCandidate);

            entries.add(new RankingEntryDto(
                    index + 1,
                    candidate.applicantId(),
                    candidate.fullName(),
                    candidate.applicationId(),
                    candidate.applicationStatus(),
                    candidate.priorityNumber(),
                    candidate.examScoreSum(),
                    candidate.achievementsScore(),
                    candidate.totalScore(),
                    recommendationInfo.recommended(),
                    recommendationInfo.status(),
                    recommendationInfo.text()
            ));
        }

        return new ProgramRankingDto(
                selectedProgram.getId(),
                selectedProgram.getCode(),
                selectedProgram.getName(),
                selectedProgram.getBudgetPlaces(),
                selectedProgram.getPaidPlaces(),
                LocalDateTime.now(),
                entries
        );
    }

    private boolean isApplicationVisibleInRanking(Application application) {
        return application.getStatus() == ApplicationStatus.SUBMITTED
                || application.getStatus() == ApplicationStatus.UNDER_REVIEW
                || application.getStatus() == ApplicationStatus.APPROVED;
    }

    private CandidateData buildCandidateData(
            List<Application> applications,
            Map<Long, List<ApplicationPriority>> prioritiesByApplication,
            Map<Long, List<ProgramExamRequirement>> requirementsByProgram,
            Map<Long, List<ExamResult>> resultsByApplicant
    ) {
        Map<Long, List<RankingCandidate>> candidatesByProgram = new HashMap<>();
        Map<String, RankingCandidate> candidateIndex = new HashMap<>();

        for (Application application : applications) {
            Applicant applicant = application.getApplicant();

            List<ApplicationPriority> priorities = prioritiesByApplication
                    .getOrDefault(application.getId(), List.of());

            for (ApplicationPriority priority : priorities) {
                Program program = priority.getProgram();

                Optional<Integer> examScoreSum = calculateExamScoreSumIfEligible(
                        requirementsByProgram.getOrDefault(program.getId(), List.of()),
                        resultsByApplicant.getOrDefault(applicant.getId(), List.of())
                );

                if (examScoreSum.isEmpty()) {
                    continue;
                }

                int achievementsScore = applicant.getAchievementsScore() == null
                        ? 0
                        : applicant.getAchievementsScore();

                int totalScore = examScoreSum.get() + achievementsScore;

                RankingCandidate candidate = new RankingCandidate(
                        program.getId(),
                        program.getBudgetPlaces(),
                        applicant.getId(),
                        buildFullName(applicant.getProfile()),
                        application.getId(),
                        application.getStatus().name(),
                        priority.getPriorityNumber(),
                        examScoreSum.get(),
                        achievementsScore,
                        totalScore
                );

                candidatesByProgram
                        .computeIfAbsent(program.getId(), id -> new ArrayList<>())
                        .add(candidate);

                candidateIndex.put(
                        candidateKey(application.getId(), program.getId()),
                        candidate
                );
            }
        }

        return new CandidateData(candidatesByProgram, candidateIndex);
    }

    private Map<Long, List<ProgramExamRequirement>> loadRequirementsByProgram(
            Map<Long, List<ApplicationPriority>> prioritiesByApplication
    ) {
        List<Long> programIds = prioritiesByApplication.values()
                .stream()
                .flatMap(List::stream)
                .map(priority -> priority.getProgram().getId())
                .distinct()
                .toList();

        if (programIds.isEmpty()) {
            return Map.of();
        }

        return programExamRequirementRepository.findByProgramIdIn(programIds)
                .stream()
                .collect(Collectors.groupingBy(requirement -> requirement.getProgram().getId()));
    }

    private Map<Long, List<ExamResult>> loadResultsByApplicant(List<Application> applications) {
        List<Long> applicantIds = applications.stream()
                .map(application -> application.getApplicant().getId())
                .distinct()
                .toList();

        if (applicantIds.isEmpty()) {
            return Map.of();
        }

        return examResultRepository.findByApplicantIdIn(applicantIds)
                .stream()
                .collect(Collectors.groupingBy(result -> result.getApplicant().getId()));
    }

    private Optional<Integer> calculateExamScoreSumIfEligible(
            List<ProgramExamRequirement> requirements,
            List<ExamResult> results
    ) {
        if (requirements.isEmpty()) {
            return Optional.empty();
        }

        int sum = 0;

        for (ProgramExamRequirement requirement : requirements) {
            Long requiredSubjectId = requirement.getExamSubject().getId();
            Integer minimumScore = requirement.getMinimumExamScore() == null
                    ? 0
                    : requirement.getMinimumExamScore().getScore();

            ExamResult bestResult = results.stream()
                    .filter(result -> result.getExamSubject().getId().equals(requiredSubjectId))
                    .filter(result -> result.getScore() >= minimumScore)
                    .max(Comparator.comparing(ExamResult::getScore))
                    .orElse(null);

            if (bestResult == null) {
                return Optional.empty();
            }

            sum += bestResult.getScore();
        }

        return Optional.of(sum);
    }

    private Map<Long, RankingCandidate> calculateBudgetRecommendations(
            List<Application> applications,
            Map<Long, List<ApplicationPriority>> prioritiesByApplication,
            Map<String, RankingCandidate> candidateIndex
    ) {
        Map<Long, Integer> nextPriorityIndexByApplication = new HashMap<>();
        Map<Long, List<RankingCandidate>> acceptedByProgram = new HashMap<>();
        Map<Long, RankingCandidate> recommendedByApplication = new HashMap<>();
        Set<Long> exhaustedApplications = new HashSet<>();

        for (Application application : applications) {
            nextPriorityIndexByApplication.put(application.getId(), 0);
        }

        boolean changed = true;

        while (changed) {
            changed = false;

            for (Application application : applications) {
                Long applicationId = application.getId();

                if (recommendedByApplication.containsKey(applicationId)
                        || exhaustedApplications.contains(applicationId)) {
                    continue;
                }

                List<ApplicationPriority> priorities = prioritiesByApplication
                        .getOrDefault(applicationId, List.of());

                boolean proposed = false;

                while (nextPriorityIndexByApplication.get(applicationId) < priorities.size()) {
                    int nextIndex = nextPriorityIndexByApplication.get(applicationId);
                    ApplicationPriority priority = priorities.get(nextIndex);

                    nextPriorityIndexByApplication.put(applicationId, nextIndex + 1);

                    RankingCandidate candidate = candidateIndex.get(
                            candidateKey(applicationId, priority.getProgram().getId())
                    );

                    if (candidate == null) {
                        continue;
                    }

                    List<RankingCandidate> programAccepted = acceptedByProgram
                            .computeIfAbsent(candidate.programId(), id -> new ArrayList<>());

                    programAccepted.add(candidate);
                    programAccepted.sort(RANKING_COMPARATOR);

                    int limit = Math.max(0, candidate.programBudgetPlaces());
                    int keepCount = Math.min(limit, programAccepted.size());

                    List<RankingCandidate> kept = new ArrayList<>(
                            programAccepted.subList(0, keepCount)
                    );

                    List<RankingCandidate> rejected = new ArrayList<>(
                            programAccepted.subList(keepCount, programAccepted.size())
                    );

                    acceptedByProgram.put(candidate.programId(), kept);

                    for (RankingCandidate keptCandidate : kept) {
                        recommendedByApplication.put(
                                keptCandidate.applicationId(),
                                keptCandidate
                        );
                    }

                    for (RankingCandidate rejectedCandidate : rejected) {
                        recommendedByApplication.remove(rejectedCandidate.applicationId());
                    }

                    proposed = true;
                    changed = true;
                    break;
                }

                if (!proposed) {
                    exhaustedApplications.add(applicationId);
                }
            }
        }

        return recommendedByApplication;
    }

    private RecommendationInfo buildRecommendationInfo(
            RankingCandidate currentCandidate,
            RankingCandidate recommendedCandidate
    ) {
        if (recommendedCandidate == null) {
            return new RecommendationInfo(
                    false,
                    "NOT_RECOMMENDED",
                    "Пока не проходит на бюджет"
            );
        }

        if (recommendedCandidate.programId().equals(currentCandidate.programId())) {
            return new RecommendationInfo(
                    true,
                    "RECOMMENDED",
                    "Рекомендован на бюджет"
            );
        }

        if (recommendedCandidate.priorityNumber() < currentCandidate.priorityNumber()) {
            return new RecommendationInfo(
                    false,
                    "HIGHER_PRIORITY",
                    "Проходит на более высокий приоритет"
            );
        }

        return new RecommendationInfo(
                false,
                "NOT_RECOMMENDED",
                "Пока не проходит на бюджет"
        );
    }

    private String candidateKey(Long applicationId, Long programId) {
        return applicationId + ":" + programId;
    }

    private String buildFullName(ApplicantProfile profile) {
        if (profile.getMiddleName() == null || profile.getMiddleName().isBlank()) {
            return profile.getLastName() + " " + profile.getFirstName();
        }

        return profile.getLastName() + " " + profile.getFirstName() + " " + profile.getMiddleName();
    }

    private record CandidateData(
            Map<Long, List<RankingCandidate>> candidatesByProgram,
            Map<String, RankingCandidate> candidateIndex
    ) {
    }

    private record RankingCandidate(
            Long programId,
            Integer programBudgetPlaces,
            Long applicantId,
            String fullName,
            Long applicationId,
            String applicationStatus,
            Integer priorityNumber,
            Integer examScoreSum,
            Integer achievementsScore,
            Integer totalScore
    ) {
    }

    private record RecommendationInfo(
            Boolean recommended,
            String status,
            String text
    ) {
    }
}
