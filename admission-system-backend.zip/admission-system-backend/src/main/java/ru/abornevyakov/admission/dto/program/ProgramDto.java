package ru.abornevyakov.admission.dto.program;

import java.util.List;

public record ProgramDto(
        Long id,
        Long admissionCampaignId,
        String admissionCampaignName,
        String code,
        String name,
        String facultyName,
        Integer budgetPlaces,
        Integer paidPlaces,
        Boolean active,
        List<ExamRequirementDto> requirements
) {
}