package ru.abornevyakov.admission.controller.auth;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;
import ru.abornevyakov.admission.dto.applicant.ApplicantDto;
import ru.abornevyakov.admission.dto.applicant.ApplicantRegisterRequest;
import ru.abornevyakov.admission.service.applicant.ApplicantService;

@RestController
@RequestMapping("/api/applicants")
@RequiredArgsConstructor
public class ApplicantRegistrationController {

    private final ApplicantService applicantService;

    @PostMapping("/register")
    public ApplicantDto registerApplicant(
            @Valid @RequestBody ApplicantRegisterRequest request
    ) {
        return applicantService.registerApplicant(request);
    }
}