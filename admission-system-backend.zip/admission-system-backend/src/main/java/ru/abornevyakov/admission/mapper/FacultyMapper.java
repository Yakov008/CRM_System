package ru.abornevyakov.admission.mapper;

import org.springframework.stereotype.Component;
import ru.abornevyakov.admission.dto.faculty.FacultyDto;
import ru.abornevyakov.admission.entity.Faculty;

@Component
public class FacultyMapper {

    public FacultyDto toDto(Faculty faculty) {
        return new FacultyDto(
                faculty.getId(),
                faculty.getName()
        );
    }
}
