package ru.abornevyakov.admission.entity.enums;

public enum DocumentType {
    PASSPORT,
    EDUCATION_CERTIFICATE,
    CONSENT,
    OTHER
}