package ru.abornevyakov.admission.service.program;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.abornevyakov.admission.dto.program.ProgramDto;
import ru.abornevyakov.admission.dto.program.ProgramRequest;
import ru.abornevyakov.admission.entity.AdmissionCampaign;
import ru.abornevyakov.admission.entity.Faculty;
import ru.abornevyakov.admission.entity.Program;
import ru.abornevyakov.admission.exception.BadRequestException;
import ru.abornevyakov.admission.exception.ResourceNotFoundException;
import ru.abornevyakov.admission.mapper.ProgramMapper;
import ru.abornevyakov.admission.repository.AdmissionCampaignRepository;
import ru.abornevyakov.admission.repository.FacultyRepository;
import ru.abornevyakov.admission.repository.ProgramRepository;

import java.util.Comparator;
import java.util.List;

@Service
@RequiredArgsConstructor
public class ProgramService {

    private final ProgramRepository programRepository;
    private final AdmissionCampaignRepository admissionCampaignRepository;
    private final FacultyRepository facultyRepository;
    private final ProgramMapper programMapper;

    @Transactional(readOnly = true)
    public List<ProgramDto> getAllProgramsForAdmin() {
        return programRepository.findAll()
                .stream()
                .sorted(Comparator.comparing(Program::getId))
                .map(programMapper::toDto)
                .toList();
    }

    @Transactional
    public ProgramDto createProgram(ProgramRequest request) {
        String code = request.code().trim();
        String name = request.name().trim();
        Faculty faculty = getFacultyByName(request.facultyName());

        if (request.budgetPlaces() + request.paidPlaces() <= 0) {
            throw new BadRequestException("Количество мест должно быть больше 0");
        }

        AdmissionCampaign campaign = admissionCampaignRepository.findById(request.admissionCampaignId())
                .orElseThrow(() -> new ResourceNotFoundException("Приёмная кампания не найдена"));

        if (programRepository.existsByCodeIgnoreCaseAndAdmissionCampaignId(code, campaign.getId())) {
            throw new BadRequestException("Направление с таким кодом уже существует в выбранной кампании");
        }

        Program program = new Program();
        program.setAdmissionCampaign(campaign);
        program.setCode(code);
        program.setName(name);
        program.setFaculty(faculty);
        program.setBudgetPlaces(request.budgetPlaces());
        program.setPaidPlaces(request.paidPlaces());
        program.setActive(request.active());

        return programMapper.toDto(programRepository.save(program));
    }

    @Transactional
    public ProgramDto updateProgram(Long programId, ProgramRequest request) {
        String code = request.code().trim();
        String name = request.name().trim();
        Faculty faculty = getFacultyByName(request.facultyName());

        if (request.budgetPlaces() + request.paidPlaces() <= 0) {
            throw new BadRequestException("Количество мест должно быть больше 0");
        }

        Program program = programRepository.findById(programId)
                .orElseThrow(() -> new ResourceNotFoundException("Направление не найдено"));

        AdmissionCampaign campaign = admissionCampaignRepository.findById(request.admissionCampaignId())
                .orElseThrow(() -> new ResourceNotFoundException("Приёмная кампания не найдена"));

        if (programRepository.existsByCodeIgnoreCaseAndAdmissionCampaignIdAndIdNot(
                code,
                campaign.getId(),
                programId
        )) {
            throw new BadRequestException("Направление с таким кодом уже существует в выбранной кампании");
        }

        program.setAdmissionCampaign(campaign);
        program.setCode(code);
        program.setName(name);
        program.setFaculty(faculty);
        program.setBudgetPlaces(request.budgetPlaces());
        program.setPaidPlaces(request.paidPlaces());
        program.setActive(request.active());

        return programMapper.toDto(programRepository.save(program));
    }

    @Transactional(readOnly = true)
    public List<ProgramDto> getActivePrograms() {
        return programRepository.findByActiveTrue()
                .stream()
                .sorted(Comparator.comparing(Program::getId))
                .map(programMapper::toDto)
                .toList();
    }

    @Transactional(readOnly = true)
    public ProgramDto getProgramById(Long id) {
        Program program = programRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Направление не найдено"));

        return programMapper.toDto(program);
    }

    private Faculty getFacultyByName(String facultyName) {
        return facultyRepository.findByNameIgnoreCase(facultyName.trim())
                .orElseThrow(() -> new BadRequestException("Сначала добавьте факультет в справочник факультетов"));
    }
}
