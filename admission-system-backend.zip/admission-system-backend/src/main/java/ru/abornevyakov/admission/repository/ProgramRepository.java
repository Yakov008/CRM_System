package ru.abornevyakov.admission.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import ru.abornevyakov.admission.entity.Program;

import java.util.List;

public interface ProgramRepository extends JpaRepository<Program, Long> {

    List<Program> findByActiveTrue();

    List<Program> findByAdmissionCampaignId(Long admissionCampaignId);

    boolean existsByCodeIgnoreCaseAndAdmissionCampaignId(String code, Long admissionCampaignId);

    boolean existsByCodeIgnoreCaseAndAdmissionCampaignIdAndIdNot(
            String code,
            Long admissionCampaignId,
            Long id
    );
}