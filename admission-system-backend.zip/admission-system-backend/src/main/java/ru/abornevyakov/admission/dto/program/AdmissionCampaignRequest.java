package ru.abornevyakov.admission.dto.program;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

import java.time.LocalDate;

public record AdmissionCampaignRequest(

        @NotBlank(message = "Название приёмной кампании обязательно")
        String name,

        @NotNull(message = "Год обязателен")
        @Min(value = 2020, message = "Год должен быть не меньше 2020")
        Integer year,

        @NotNull(message = "Дата начала обязательна")
        LocalDate startDate,

        @NotNull(message = "Дата окончания обязательна")
        LocalDate endDate,

        @NotNull(message = "Признак активности обязателен")
        Boolean active
) {
}