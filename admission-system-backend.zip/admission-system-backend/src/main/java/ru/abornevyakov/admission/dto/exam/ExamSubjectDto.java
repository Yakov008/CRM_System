package ru.abornevyakov.admission.dto.exam;

public record ExamSubjectDto(
        Long id,
        String name
) {
}