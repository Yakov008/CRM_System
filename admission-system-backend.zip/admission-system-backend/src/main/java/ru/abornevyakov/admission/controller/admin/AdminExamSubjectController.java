package ru.abornevyakov.admission.controller.admin;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;
import ru.abornevyakov.admission.dto.exam.ExamSubjectDto;
import ru.abornevyakov.admission.dto.exam.ExamSubjectRequest;
import ru.abornevyakov.admission.service.exam.ExamSubjectService;

import java.util.List;

@RestController
@RequestMapping("/api/admin/exam-subjects")
@RequiredArgsConstructor
public class AdminExamSubjectController {

    private final ExamSubjectService examSubjectService;

    @GetMapping
    public List<ExamSubjectDto> getAllSubjects() {
        return examSubjectService.getAllSubjects();
    }

    @PostMapping
    public ExamSubjectDto createSubject(
            @Valid @RequestBody ExamSubjectRequest request
    ) {
        return examSubjectService.createSubject(request);
    }

    @PutMapping("/{subjectId}")
    public ExamSubjectDto updateSubject(
            @PathVariable Long subjectId,
            @Valid @RequestBody ExamSubjectRequest request
    ) {
        return examSubjectService.updateSubject(subjectId, request);
    }
}