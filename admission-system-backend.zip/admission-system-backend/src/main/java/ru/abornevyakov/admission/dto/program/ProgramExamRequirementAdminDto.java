package ru.abornevyakov.admission.dto.program;

public record ProgramExamRequirementAdminDto(
        Long id,
        Long programId,
        String programCode,
        String programName,
        Long examSubjectId,
        String examSubjectName,
        Integer minimumScore
) {
}