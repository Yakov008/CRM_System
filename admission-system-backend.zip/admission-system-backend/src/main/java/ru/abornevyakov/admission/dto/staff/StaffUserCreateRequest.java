package ru.abornevyakov.admission.dto.staff;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

public record StaffUserCreateRequest(

        @NotBlank(message = "Email обязателен")
        @Email(message = "Некорректный email")
        @Size(max = 120, message = "Email не должен превышать 120 символов")
        String email,

        @NotBlank(message = "Пароль обязателен")
        @Size(min = 6, max = 100, message = "Пароль должен содержать от 6 до 100 символов")
        String password,

        @NotBlank(message = "Факультет обязателен")
        @Size(max = 150, message = "Название факультета не должно превышать 150 символов")
        String facultyName,

        @NotNull(message = "Признак активности обязателен")
        Boolean active
) {
}
