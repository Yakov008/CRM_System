package ru.abornevyakov.admission.service.officer;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.abornevyakov.admission.dto.document.ApplicationDocumentDto;
import ru.abornevyakov.admission.dto.exam.ExamResultDto;
import ru.abornevyakov.admission.dto.officer.OfficerApplicationDetailsDto;
import ru.abornevyakov.admission.entity.Applicant;
import ru.abornevyakov.admission.entity.Application;
import ru.abornevyakov.admission.exception.ResourceNotFoundException;
import ru.abornevyakov.admission.mapper.ApplicationDocumentMapper;
import ru.abornevyakov.admission.mapper.ApplicationMapper;
import ru.abornevyakov.admission.mapper.ExamResultMapper;
import ru.abornevyakov.admission.mapper.OfficerApplicantInfoMapper;
import ru.abornevyakov.admission.repository.ApplicationDocumentRepository;
import ru.abornevyakov.admission.repository.ApplicationRepository;
import ru.abornevyakov.admission.repository.ExamResultRepository;

import java.util.List;

@Service
@RequiredArgsConstructor
public class OfficerApplicationDetailsService {

    private final ApplicationRepository applicationRepository;
    private final ExamResultRepository examResultRepository;
    private final ApplicationDocumentRepository applicationDocumentRepository;
    private final ApplicationMapper applicationMapper;
    private final OfficerApplicantInfoMapper officerApplicantInfoMapper;
    private final ExamResultMapper examResultMapper;
    private final ApplicationDocumentMapper applicationDocumentMapper;
    private final OfficerScopeService officerScopeService;

    @Transactional(readOnly = true)
    public OfficerApplicationDetailsDto getApplicationDetails(Long applicationId) {
        Application application = applicationRepository.findById(applicationId)
                .orElseThrow(() -> new ResourceNotFoundException("Заявление не найдено"));

        officerScopeService.checkApplicationAccess(application);

        Applicant applicant = application.getApplicant();

        return new OfficerApplicationDetailsDto(
                applicationMapper.toDto(application),
                officerApplicantInfoMapper.toDto(applicant),
                getExamResults(applicant.getId()),
                getDocuments(application.getId())
        );
    }

    private List<ExamResultDto> getExamResults(Long applicantId) {
        return examResultRepository.findByApplicantId(applicantId)
                .stream()
                .map(examResultMapper::toDto)
                .toList();
    }

    private List<ApplicationDocumentDto> getDocuments(Long applicationId) {
        return applicationDocumentRepository.findByApplicationId(applicationId)
                .stream()
                .map(applicationDocumentMapper::toDto)
                .toList();
    }
}
