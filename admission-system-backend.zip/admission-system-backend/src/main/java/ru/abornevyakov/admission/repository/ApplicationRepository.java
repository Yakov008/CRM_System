package ru.abornevyakov.admission.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import ru.abornevyakov.admission.entity.Application;
import ru.abornevyakov.admission.entity.enums.ApplicationStatus;

import java.util.List;
import java.util.Optional;

public interface ApplicationRepository extends JpaRepository<Application, Long> {

    List<Application> findByApplicantId(Long applicantId);

    List<Application> findByAdmissionCampaignId(Long admissionCampaignId);

    List<Application> findByStatus(ApplicationStatus status);

    Optional<Application> findByApplicantIdAndAdmissionCampaignId(
            Long applicantId,
            Long admissionCampaignId
    );

    List<Application> findAllByOrderByCreatedAtDesc();

    List<Application> findByStatusOrderByCreatedAtDesc(ApplicationStatus status);

    List<Application> findByAdmissionCampaignIdOrderByCreatedAtDesc(Long admissionCampaignId);

    List<Application> findByStatusAndAdmissionCampaignIdOrderByCreatedAtDesc(
            ApplicationStatus status,
            Long admissionCampaignId
    );
}
