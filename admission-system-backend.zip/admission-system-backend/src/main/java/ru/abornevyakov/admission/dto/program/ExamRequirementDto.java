package ru.abornevyakov.admission.dto.program;

public record ExamRequirementDto(
        Long subjectId,
        String subjectName,
        Integer minimumScore
) {
}