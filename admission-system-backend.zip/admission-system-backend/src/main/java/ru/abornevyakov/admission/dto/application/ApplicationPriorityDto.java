package ru.abornevyakov.admission.dto.application;

public record ApplicationPriorityDto(
        Long id,
        Long programId,
        String programCode,
        String programName,
        Integer priorityNumber
) {
}