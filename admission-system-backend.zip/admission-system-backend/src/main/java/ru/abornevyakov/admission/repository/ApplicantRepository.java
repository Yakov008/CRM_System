package ru.abornevyakov.admission.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import ru.abornevyakov.admission.entity.Applicant;

import java.util.Optional;

public interface ApplicantRepository extends JpaRepository<Applicant, Long> {

    Optional<Applicant> findByUserId(Long userId);
}