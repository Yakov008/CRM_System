package ru.abornevyakov.admission.dto.program;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;

public record ProgramExamRequirementAdminRequest(

        @NotNull(message = "Направление обязательно")
        Long programId,

        @NotNull(message = "Предмет ЕГЭ обязателен")
        Long examSubjectId,

        @NotNull(message = "Минимальный балл обязателен")
        @Min(value = 0, message = "Минимальный балл не может быть меньше 0")
        @Max(value = 100, message = "Минимальный балл не может быть больше 100")
        Integer minimumScore
) {
}