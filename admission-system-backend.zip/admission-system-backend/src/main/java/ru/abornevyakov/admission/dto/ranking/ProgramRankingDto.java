package ru.abornevyakov.admission.dto.ranking;

import java.time.LocalDateTime;
import java.util.List;

public record ProgramRankingDto(
        Long programId,
        String programCode,
        String programName,
        Integer budgetPlaces,
        Integer paidPlaces,
        LocalDateTime generatedAt,
        List<RankingEntryDto> entries
) {
}