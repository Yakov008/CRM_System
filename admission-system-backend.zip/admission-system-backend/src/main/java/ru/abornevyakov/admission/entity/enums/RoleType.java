package ru.abornevyakov.admission.entity.enums;

public enum RoleType {
    APPLICANT,
    OFFICER,
    ADMIN
}
