package ru.abornevyakov.admission.dto.faculty;

public record FacultyDto(
        Long id,
        String name
) {
}
