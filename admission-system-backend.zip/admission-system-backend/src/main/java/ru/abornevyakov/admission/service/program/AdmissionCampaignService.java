package ru.abornevyakov.admission.service.program;

import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.abornevyakov.admission.dto.program.AdmissionCampaignDto;
import ru.abornevyakov.admission.dto.program.AdmissionCampaignRequest;
import ru.abornevyakov.admission.entity.AdmissionCampaign;
import ru.abornevyakov.admission.exception.BadRequestException;
import ru.abornevyakov.admission.exception.ResourceNotFoundException;
import ru.abornevyakov.admission.mapper.AdmissionCampaignMapper;
import ru.abornevyakov.admission.repository.AdmissionCampaignRepository;

import java.time.LocalDate;
import java.util.List;

@Service
@RequiredArgsConstructor
public class AdmissionCampaignService {

    private final AdmissionCampaignRepository admissionCampaignRepository;
    private final AdmissionCampaignMapper admissionCampaignMapper;

    @Transactional(readOnly = true)
    public List<AdmissionCampaignDto> getActiveCampaigns() {
        return admissionCampaignRepository.findByActiveTrue()
                .stream()
                .map(admissionCampaignMapper::toDto)
                .toList();
    }

    @Transactional(readOnly = true)
    public List<AdmissionCampaignDto> getAllCampaigns() {
        return admissionCampaignRepository
                .findAll(Sort.by(Sort.Direction.DESC, "year", "startDate"))
                .stream()
                .map(admissionCampaignMapper::toDto)
                .toList();
    }

    @Transactional
    public AdmissionCampaignDto createCampaign(AdmissionCampaignRequest request) {
        validateCampaignDates(request.startDate(), request.endDate());

        AdmissionCampaign campaign = new AdmissionCampaign();
        campaign.setName(request.name());
        campaign.setYear(request.year());
        campaign.setStartDate(request.startDate());
        campaign.setEndDate(request.endDate());
        campaign.setActive(request.active());

        AdmissionCampaign savedCampaign = admissionCampaignRepository.save(campaign);

        return admissionCampaignMapper.toDto(savedCampaign);
    }

    @Transactional
    public AdmissionCampaignDto updateCampaign(
            Long campaignId,
            AdmissionCampaignRequest request
    ) {
        validateCampaignDates(request.startDate(), request.endDate());

        AdmissionCampaign campaign = admissionCampaignRepository.findById(campaignId)
                .orElseThrow(() -> new ResourceNotFoundException("Приёмная кампания не найдена"));

        campaign.setName(request.name());
        campaign.setYear(request.year());
        campaign.setStartDate(request.startDate());
        campaign.setEndDate(request.endDate());
        campaign.setActive(request.active());

        AdmissionCampaign savedCampaign = admissionCampaignRepository.save(campaign);

        return admissionCampaignMapper.toDto(savedCampaign);
    }

    private void validateCampaignDates(LocalDate startDate, LocalDate endDate) {
        if (startDate.isAfter(endDate)) {
            throw new BadRequestException("Дата начала не может быть позже даты окончания");
        }
    }
}
