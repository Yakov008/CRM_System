package ru.abornevyakov.admission.mapper;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import ru.abornevyakov.admission.dto.program.ExamRequirementDto;
import ru.abornevyakov.admission.dto.program.ProgramDto;
import ru.abornevyakov.admission.entity.Program;
import ru.abornevyakov.admission.repository.ProgramExamRequirementRepository;

import java.util.List;

@Component
@RequiredArgsConstructor
public class ProgramMapper {

    private final ProgramExamRequirementRepository requirementRepository;

    public ProgramDto toDto(Program program) {
        List<ExamRequirementDto> requirements = requirementRepository
                .findByProgramId(program.getId())
                .stream()
                .map(requirement -> new ExamRequirementDto(
                        requirement.getExamSubject().getId(),
                        requirement.getExamSubject().getName(),
                        requirement.getMinimumExamScore() == null
                                ? null
                                : requirement.getMinimumExamScore().getScore()
                ))
                .toList();

        return new ProgramDto(
                program.getId(),
                program.getAdmissionCampaign().getId(),
                program.getAdmissionCampaign().getName(),
                program.getCode(),
                program.getName(),
                program.getFacultyName(),
                program.getBudgetPlaces(),
                program.getPaidPlaces(),
                program.isActive(),
                requirements
        );
    }
}
