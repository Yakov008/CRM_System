package ru.abornevyakov.admission.dto.exam;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public record ExamSubjectRequest(

        @NotBlank(message = "Название предмета обязательно")
        @Size(max = 100, message = "Название предмета не должно превышать 100 символов")
        String name
) {
}