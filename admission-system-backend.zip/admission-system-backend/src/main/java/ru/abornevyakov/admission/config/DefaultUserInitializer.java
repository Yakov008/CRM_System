package ru.abornevyakov.admission.config;

import lombok.RequiredArgsConstructor;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;
import ru.abornevyakov.admission.entity.User;
import ru.abornevyakov.admission.entity.enums.RoleType;
import ru.abornevyakov.admission.repository.UserRepository;

@Component
@RequiredArgsConstructor
public class DefaultUserInitializer implements CommandLineRunner {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    @Override
    public void run(String... args) {
        createUserIfNotExists(
                "officer@example.com",
                "officer123",
                RoleType.OFFICER,
                "Факультет информационных технологий"
        );

        createUserIfNotExists(
                "admin@example.com",
                "admin123",
                RoleType.ADMIN,
                null
        );
    }

    private void createUserIfNotExists(String email, String password, RoleType role, String facultyName) {
        if (userRepository.findByEmail(email).isPresent()) {
            userRepository.findByEmail(email)
                    .filter(user -> user.getRole() == RoleType.OFFICER)
                    .filter(user -> user.getFacultyName() == null || user.getFacultyName().isBlank())
                    .ifPresent(user -> {
                        user.setFacultyName(facultyName);
                        userRepository.save(user);
                    });
            return;
        }

        User user = new User();
        user.setEmail(email);
        user.setPassword(passwordEncoder.encode(password));
        user.setRole(role);
        user.setActive(true);
        user.setFacultyName(facultyName);

        userRepository.save(user);
    }
}
