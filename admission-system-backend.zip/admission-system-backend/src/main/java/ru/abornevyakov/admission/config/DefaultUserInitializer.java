package ru.abornevyakov.admission.config;

import lombok.RequiredArgsConstructor;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.annotation.Order;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;
import ru.abornevyakov.admission.entity.Faculty;
import ru.abornevyakov.admission.entity.User;
import ru.abornevyakov.admission.entity.enums.RoleType;
import ru.abornevyakov.admission.repository.FacultyRepository;
import ru.abornevyakov.admission.repository.UserRepository;

@Component
@Order(2)
@RequiredArgsConstructor
public class DefaultUserInitializer implements CommandLineRunner {

    private final UserRepository userRepository;
    private final FacultyRepository facultyRepository;
    private final PasswordEncoder passwordEncoder;

    @Override
    public void run(String... args) {
        createUserIfNotExists(
                "officer@example.com",
                "officer123",
                RoleType.OFFICER,
                "Факультет информационных технологий"
        );

        createUserIfNotExists(
                "officer.economics@example.com",
                "officer123",
                RoleType.OFFICER,
                "Экономический факультет"
        );

        createUserIfNotExists(
                "admin@example.com",
                "admin123",
                RoleType.ADMIN,
                null
        );
    }

    private void createUserIfNotExists(String email, String password, RoleType role, String facultyName) {
        Faculty faculty = facultyName == null ? null : getOrCreateFaculty(facultyName);

        userRepository.findByEmail(email)
                .ifPresentOrElse(user -> {
                    if (user.getRole() == RoleType.OFFICER && user.getFaculty() == null) {
                        user.setFaculty(user.getLegacyFacultyName() == null
                                ? faculty
                                : getOrCreateFaculty(user.getLegacyFacultyName()));
                        userRepository.save(user);
                    }
                }, () -> {
                    User user = new User();
                    user.setEmail(email);
                    user.setPassword(passwordEncoder.encode(password));
                    user.setRole(role);
                    user.setActive(true);
                    user.setFaculty(faculty);

                    userRepository.save(user);
                });
    }

    private Faculty getOrCreateFaculty(String name) {
        return facultyRepository.findByNameIgnoreCase(name)
                .orElseGet(() -> {
                    Faculty faculty = new Faculty();
                    faculty.setName(name);
                    return facultyRepository.save(faculty);
                });
    }
}
