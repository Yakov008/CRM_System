package ru.abornevyakov.admission.dto.application;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;

public record ApplicationPriorityRequest(

        @NotNull
        Long programId,

        @NotNull
        @Min(1)
        Integer priorityNumber
) {
}