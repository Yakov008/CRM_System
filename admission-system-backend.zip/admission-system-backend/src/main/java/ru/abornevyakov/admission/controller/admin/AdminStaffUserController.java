package ru.abornevyakov.admission.controller.admin;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;
import ru.abornevyakov.admission.dto.staff.StaffUserCreateRequest;
import ru.abornevyakov.admission.dto.staff.StaffUserDto;
import ru.abornevyakov.admission.dto.staff.StaffUserUpdateRequest;
import ru.abornevyakov.admission.service.admin.StaffUserAdminService;

import java.util.List;

@RestController
@RequestMapping("/api/admin/staff")
@RequiredArgsConstructor
public class AdminStaffUserController {

    private final StaffUserAdminService staffUserAdminService;

    @GetMapping
    public List<StaffUserDto> getStaffUsers() {
        return staffUserAdminService.getStaffUsers();
    }

    @PostMapping
    public StaffUserDto createStaffUser(@Valid @RequestBody StaffUserCreateRequest request) {
        return staffUserAdminService.createStaffUser(request);
    }

    @PutMapping("/{userId}")
    public StaffUserDto updateStaffUser(
            @PathVariable Long userId,
            @Valid @RequestBody StaffUserUpdateRequest request
    ) {
        return staffUserAdminService.updateStaffUser(userId, request);
    }
}
