package ru.abornevyakov.admission.mapper;

import org.springframework.stereotype.Component;
import ru.abornevyakov.admission.dto.exam.ExamResultDto;
import ru.abornevyakov.admission.entity.ExamResult;

@Component
public class ExamResultMapper {

    public ExamResultDto toDto(ExamResult result) {
        return new ExamResultDto(
                result.getId(),
                result.getApplicant().getId(),
                result.getExamSubject().getId(),
                result.getExamSubject().getName(),
                result.getExamYear(),
                result.getScore(),
                result.getCreatedAt()
        );
    }
}