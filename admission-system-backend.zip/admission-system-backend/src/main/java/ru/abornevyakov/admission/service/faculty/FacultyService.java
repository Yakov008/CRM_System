package ru.abornevyakov.admission.service.faculty;

import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.abornevyakov.admission.dto.faculty.FacultyDto;
import ru.abornevyakov.admission.dto.faculty.FacultyRequest;
import ru.abornevyakov.admission.entity.Faculty;
import ru.abornevyakov.admission.exception.BadRequestException;
import ru.abornevyakov.admission.exception.ResourceNotFoundException;
import ru.abornevyakov.admission.mapper.FacultyMapper;
import ru.abornevyakov.admission.repository.FacultyRepository;
import ru.abornevyakov.admission.repository.ProgramRepository;
import ru.abornevyakov.admission.repository.UserRepository;

import java.util.List;

@Service
@RequiredArgsConstructor
public class FacultyService {

    private final FacultyRepository facultyRepository;
    private final ProgramRepository programRepository;
    private final UserRepository userRepository;
    private final FacultyMapper facultyMapper;

    @Transactional(readOnly = true)
    public List<FacultyDto> getAllFaculties() {
        return facultyRepository.findAll(Sort.by(Sort.Direction.ASC, "id"))
                .stream()
                .map(facultyMapper::toDto)
                .toList();
    }

    @Transactional
    public FacultyDto createFaculty(FacultyRequest request) {
        String name = request.name().trim();

        if (facultyRepository.existsByNameIgnoreCase(name)) {
            throw new BadRequestException("Факультет с таким названием уже существует");
        }

        Faculty faculty = new Faculty();
        faculty.setName(name);

        return facultyMapper.toDto(facultyRepository.save(faculty));
    }

    @Transactional
    public FacultyDto updateFaculty(Long facultyId, FacultyRequest request) {
        String name = request.name().trim();

        Faculty faculty = facultyRepository.findById(facultyId)
                .orElseThrow(() -> new ResourceNotFoundException("Факультет не найден"));

        if (facultyRepository.existsByNameIgnoreCaseAndIdNot(name, facultyId)) {
            throw new BadRequestException("Факультет с таким названием уже существует");
        }

        faculty.setName(name);

        return facultyMapper.toDto(facultyRepository.save(faculty));
    }

    @Transactional
    public void deleteFaculty(Long facultyId) {
        Faculty faculty = facultyRepository.findById(facultyId)
                .orElseThrow(() -> new ResourceNotFoundException("Факультет не найден"));

        if (programRepository.existsByFacultyNameIgnoreCase(faculty.getName())) {
            throw new BadRequestException("Факультет используется в направлениях подготовки");
        }

        if (userRepository.existsByFacultyNameIgnoreCase(faculty.getName())) {
            throw new BadRequestException("Факультет назначен сотрудникам");
        }

        facultyRepository.delete(faculty);
    }
}
