package ru.abornevyakov.admission.config;

import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import ru.abornevyakov.admission.security.JwtAuthenticationFilter;
import ru.abornevyakov.admission.security.RestAccessDeniedHandler;
import ru.abornevyakov.admission.security.RestAuthenticationEntryPoint;

@Configuration
@EnableWebSecurity
@RequiredArgsConstructor
public class SecurityConfig {

    private final JwtAuthenticationFilter jwtAuthenticationFilter;
    private final RestAuthenticationEntryPoint restAuthenticationEntryPoint;
    private final RestAccessDeniedHandler restAccessDeniedHandler;

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        return http
                .cors(Customizer.withDefaults())
                .csrf(AbstractHttpConfigurer::disable)
                .sessionManagement(session ->
                        session.sessionCreationPolicy(SessionCreationPolicy.STATELESS)
                )
                .formLogin(AbstractHttpConfigurer::disable)
                .httpBasic(AbstractHttpConfigurer::disable)
                .exceptionHandling(exception -> exception
                        .authenticationEntryPoint(restAuthenticationEntryPoint)
                        .accessDeniedHandler(restAccessDeniedHandler)
                )
                .authorizeHttpRequests(auth -> auth
                        .requestMatchers(HttpMethod.OPTIONS, "/**").permitAll()

                        .requestMatchers(HttpMethod.GET, "/api/health").permitAll()
                        .requestMatchers(HttpMethod.POST, "/api/auth/login").permitAll()
                        .requestMatchers(HttpMethod.POST, "/api/applicants/register").permitAll()

                        .requestMatchers(HttpMethod.GET, "/api/programs/**").permitAll()
                        .requestMatchers(HttpMethod.GET, "/api/faculties").permitAll()
                        .requestMatchers(HttpMethod.GET, "/api/admission-campaigns").permitAll()
                        .requestMatchers(HttpMethod.GET, "/api/admission-campaigns/active").permitAll()
                        .requestMatchers(HttpMethod.GET, "/api/rankings/**").permitAll()

                        .requestMatchers(HttpMethod.GET, "/api/applications").hasAnyRole("OFFICER", "ADMIN")
                        .requestMatchers(HttpMethod.GET, "/api/applications/*").hasAnyRole("OFFICER", "ADMIN")
                        .requestMatchers(HttpMethod.GET, "/api/applications/*/details").hasAnyRole("OFFICER", "ADMIN")
                        .requestMatchers(HttpMethod.PATCH, "/api/applications/*/status").hasAnyRole("OFFICER", "ADMIN")

                        .requestMatchers(HttpMethod.GET, "/api/documents").hasAnyRole("OFFICER", "ADMIN")
                        .requestMatchers(HttpMethod.PATCH, "/api/documents/*/status").hasAnyRole("OFFICER", "ADMIN")
                        .requestMatchers(HttpMethod.GET, "/api/documents/*/download").hasAnyRole("APPLICANT", "OFFICER", "ADMIN")

                        .requestMatchers(HttpMethod.PATCH, "/api/officer/applicants/*/achievements")
                        .hasAnyRole("OFFICER", "ADMIN")

                        .requestMatchers("/api/admin/**").hasRole("ADMIN")

                        .requestMatchers("/api/applicants/**").hasRole("APPLICANT")

                        .anyRequest().authenticated()
                )
                .addFilterBefore(
                        jwtAuthenticationFilter,
                        UsernamePasswordAuthenticationFilter.class
                )
                .build();
    }
}
