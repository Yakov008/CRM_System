package ru.abornevyakov.admission.service.applicant;

import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.abornevyakov.admission.dto.applicant.ApplicantAchievementsUpdateRequest;
import ru.abornevyakov.admission.dto.applicant.ApplicantDto;
import ru.abornevyakov.admission.dto.applicant.ApplicantRegisterRequest;
import ru.abornevyakov.admission.entity.Applicant;
import ru.abornevyakov.admission.entity.ApplicantProfile;
import ru.abornevyakov.admission.entity.User;
import ru.abornevyakov.admission.entity.enums.RoleType;
import ru.abornevyakov.admission.exception.BadRequestException;
import ru.abornevyakov.admission.exception.ResourceNotFoundException;
import ru.abornevyakov.admission.mapper.ApplicantMapper;
import ru.abornevyakov.admission.repository.ApplicantProfileRepository;
import ru.abornevyakov.admission.repository.ApplicantRepository;
import ru.abornevyakov.admission.repository.UserRepository;
import ru.abornevyakov.admission.service.auth.CurrentUserService;
import ru.abornevyakov.admission.service.officer.OfficerScopeService;

@Service
@RequiredArgsConstructor
public class ApplicantService {

    private final UserRepository userRepository;
    private final ApplicantRepository applicantRepository;
    private final ApplicantProfileRepository applicantProfileRepository;
    private final PasswordEncoder passwordEncoder;
    private final CurrentUserService currentUserService;
    private final OfficerScopeService officerScopeService;
    private final ApplicantMapper applicantMapper;

    @Transactional
    public ApplicantDto registerApplicant(ApplicantRegisterRequest request) {
        if (userRepository.existsByEmail(request.email())) {
            throw new BadRequestException("Пользователь с таким email уже существует");
        }

        if (applicantProfileRepository.existsByPassportNumber(request.passportNumber())) {
            throw new BadRequestException("Абитуриент с таким паспортом уже существует");
        }

        User user = new User();
        user.setEmail(request.email());
        user.setPassword(passwordEncoder.encode(request.password()));
        user.setRole(RoleType.APPLICANT);
        user.setActive(true);

        User savedUser = userRepository.save(user);

        ApplicantProfile profile = new ApplicantProfile();
        profile.setLastName(request.lastName());
        profile.setFirstName(request.firstName());
        profile.setMiddleName(request.middleName());
        profile.setBirthDate(request.birthDate());
        profile.setPhone(request.phone());
        profile.setPassportNumber(request.passportNumber());

        Applicant applicant = new Applicant();
        applicant.setUser(savedUser);
        applicant.setProfile(profile);
        applicant.setAchievementsScore(0);

        Applicant savedApplicant = applicantRepository.save(applicant);

        return applicantMapper.toDto(savedApplicant);
    }

    @Transactional(readOnly = true)
    public ApplicantDto getApplicantById(Long id) {
        currentUserService.checkApplicantAccess(id);

        Applicant applicant = applicantRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Абитуриент не найден"));

        return applicantMapper.toDto(applicant);
    }

    @Transactional
    public ApplicantDto updateAchievementsScore(
            Long applicantId,
            ApplicantAchievementsUpdateRequest request
    ) {
        officerScopeService.checkApplicantAccess(applicantId);

        Applicant applicant = applicantRepository.findById(applicantId)
                .orElseThrow(() -> new ResourceNotFoundException("Абитуриент не найден"));

        applicant.setAchievementsScore(request.achievementsScore());

        Applicant savedApplicant = applicantRepository.save(applicant);

        return applicantMapper.toDto(savedApplicant);
    }
}
