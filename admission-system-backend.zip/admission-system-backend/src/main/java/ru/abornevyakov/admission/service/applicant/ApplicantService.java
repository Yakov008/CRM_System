package ru.abornevyakov.admission.service.applicant;

import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.abornevyakov.admission.dto.applicant.ApplicantAchievementsUpdateRequest;
import ru.abornevyakov.admission.dto.applicant.ApplicantDto;
import ru.abornevyakov.admission.dto.applicant.ApplicantRegisterRequest;
import ru.abornevyakov.admission.entity.Applicant;
import ru.abornevyakov.admission.entity.ApplicantProfile;
import ru.abornevyakov.admission.entity.User;
import ru.abornevyakov.admission.entity.enums.RoleType;
import ru.abornevyakov.admission.exception.BadRequestException;
import ru.abornevyakov.admission.exception.ResourceNotFoundException;
import ru.abornevyakov.admission.mapper.ApplicantMapper;
import ru.abornevyakov.admission.repository.ApplicantProfileRepository;
import ru.abornevyakov.admission.repository.ApplicantRepository;
import ru.abornevyakov.admission.repository.UserRepository;
import ru.abornevyakov.admission.service.auth.CurrentUserService;
import ru.abornevyakov.admission.service.officer.OfficerScopeService;

@Service
@RequiredArgsConstructor
public class ApplicantService {

    private final UserRepository userRepository;
    private final ApplicantRepository applicantRepository;
    private final ApplicantProfileRepository applicantProfileRepository;
    private final PasswordEncoder passwordEncoder;
    private final CurrentUserService currentUserService;
    private final OfficerScopeService officerScopeService;
    private final ApplicantMapper applicantMapper;

    @Transactional
    public ApplicantDto registerApplicant(ApplicantRegisterRequest request) {
        String email = request.email().trim().toLowerCase();
        String phone = normalizePhone(request.phone());
        String passportNumber = normalizePassportNumber(request.passportNumber());

        if (userRepository.existsByEmail(email)) {
            throw new BadRequestException("Пользователь с таким email уже существует");
        }

        if (applicantProfileRepository.existsByPassportNumber(passportNumber)) {
            throw new BadRequestException("Абитуриент с таким паспортом уже существует");
        }

        User user = new User();
        user.setEmail(email);
        user.setPassword(passwordEncoder.encode(request.password()));
        user.setRole(RoleType.APPLICANT);
        user.setActive(true);

        User savedUser = userRepository.save(user);

        ApplicantProfile profile = new ApplicantProfile();
        profile.setLastName(request.lastName().trim());
        profile.setFirstName(request.firstName().trim());
        profile.setMiddleName(normalizeOptionalText(request.middleName()));
        profile.setBirthDate(request.birthDate());
        profile.setPhone(phone);
        profile.setPassportNumber(passportNumber);

        Applicant applicant = new Applicant();
        applicant.setUser(savedUser);
        applicant.setProfile(profile);
        applicant.setAchievementsScore(0);

        return applicantMapper.toDto(applicantRepository.save(applicant));
    }

    @Transactional(readOnly = true)
    public ApplicantDto getApplicantById(Long id) {
        currentUserService.checkApplicantAccess(id);

        Applicant applicant = applicantRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Абитуриент не найден"));

        return applicantMapper.toDto(applicant);
    }

    @Transactional
    public ApplicantDto updateAchievementsScore(
            Long applicantId,
            ApplicantAchievementsUpdateRequest request
    ) {
        officerScopeService.checkApplicantAccess(applicantId);

        Applicant applicant = applicantRepository.findById(applicantId)
                .orElseThrow(() -> new ResourceNotFoundException("Абитуриент не найден"));

        applicant.setAchievementsScore(request.achievementsScore());

        return applicantMapper.toDto(applicantRepository.save(applicant));
    }

    private String normalizePhone(String phone) {
        String digits = phone.replaceAll("\\D", "");

        if (digits.length() == 11 && digits.startsWith("8")) {
            digits = "7" + digits.substring(1);
        } else if (digits.length() == 10) {
            digits = "7" + digits;
        }

        if (digits.length() != 11 || !digits.startsWith("7")) {
            throw new BadRequestException("Телефон должен быть указан в формате +7 999 000-00-00");
        }

        return "+7 " + digits.substring(1, 4)
                + " " + digits.substring(4, 7)
                + "-" + digits.substring(7, 9)
                + "-" + digits.substring(9, 11);
    }

    private String normalizePassportNumber(String passportNumber) {
        String digits = passportNumber.replaceAll("\\D", "");

        if (digits.length() != 10) {
            throw new BadRequestException("Паспорт должен содержать 10 цифр");
        }

        return digits;
    }

    private String normalizeOptionalText(String value) {
        if (value == null || value.isBlank()) {
            return null;
        }

        return value.trim();
    }
}
