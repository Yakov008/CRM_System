package ru.abornevyakov.admission.controller.officer;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;
import ru.abornevyakov.admission.dto.document.ApplicationDocumentDto;
import ru.abornevyakov.admission.dto.document.ApplicationDocumentStatusUpdateRequest;
import ru.abornevyakov.admission.entity.enums.DocumentStatus;
import ru.abornevyakov.admission.service.document.ApplicationDocumentService;

import java.util.List;

@RestController
@RequestMapping("/api/documents")
@RequiredArgsConstructor
public class OfficerDocumentController {

    private final ApplicationDocumentService applicationDocumentService;

    @GetMapping
    public List<ApplicationDocumentDto> getDocuments(
            @RequestParam(required = false) DocumentStatus status
    ) {
        if (status == null) {
            return applicationDocumentService.getAllDocuments();
        }

        return applicationDocumentService.getDocumentsByStatus(status);
    }

    @PatchMapping("/{documentId}/status")
    public ApplicationDocumentDto updateDocumentStatus(
            @PathVariable Long documentId,
            @Valid @RequestBody ApplicationDocumentStatusUpdateRequest request
    ) {
        return applicationDocumentService.updateDocumentStatus(
                documentId,
                request
        );
    }
}