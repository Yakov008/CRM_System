package ru.abornevyakov.admission.controller.auth;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;
import ru.abornevyakov.admission.dto.auth.AuthResponse;
import ru.abornevyakov.admission.dto.auth.LoginRequest;
import ru.abornevyakov.admission.dto.auth.CurrentUserDto;
import ru.abornevyakov.admission.service.auth.AuthService;

@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
public class AuthController {

    private final AuthService authService;

    @PostMapping("/login")
    public AuthResponse login(@Valid @RequestBody LoginRequest request) {
        return authService.login(request);
    }

    @GetMapping("/me")
    public CurrentUserDto getCurrentUser() {
        return authService.getCurrentUser();
    }
}