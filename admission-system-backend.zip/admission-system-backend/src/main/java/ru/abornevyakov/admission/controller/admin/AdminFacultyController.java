package ru.abornevyakov.admission.controller.admin;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import ru.abornevyakov.admission.dto.faculty.FacultyDto;
import ru.abornevyakov.admission.dto.faculty.FacultyRequest;
import ru.abornevyakov.admission.service.faculty.FacultyService;

import java.util.List;

@RestController
@RequestMapping("/api/admin/faculties")
@RequiredArgsConstructor
public class AdminFacultyController {

    private final FacultyService facultyService;

    @GetMapping
    public List<FacultyDto> getAllFaculties() {
        return facultyService.getAllFaculties();
    }

    @PostMapping
    public FacultyDto createFaculty(@Valid @RequestBody FacultyRequest request) {
        return facultyService.createFaculty(request);
    }

    @PutMapping("/{facultyId}")
    public FacultyDto updateFaculty(
            @PathVariable Long facultyId,
            @Valid @RequestBody FacultyRequest request
    ) {
        return facultyService.updateFaculty(facultyId, request);
    }

    @DeleteMapping("/{facultyId}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deleteFaculty(@PathVariable Long facultyId) {
        facultyService.deleteFaculty(facultyId);
    }
}
