package ru.abornevyakov.admission.dto.faculty;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public record FacultyRequest(

        @NotBlank(message = "Название факультета обязательно")
        @Size(max = 255, message = "Название факультета не должно превышать 255 символов")
        String name
) {
}
