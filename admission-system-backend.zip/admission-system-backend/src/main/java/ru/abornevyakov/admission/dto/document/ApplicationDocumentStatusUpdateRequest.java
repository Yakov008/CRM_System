package ru.abornevyakov.admission.dto.document;

import jakarta.validation.constraints.NotNull;
import ru.abornevyakov.admission.entity.enums.DocumentStatus;

public record ApplicationDocumentStatusUpdateRequest(

        @NotNull
        DocumentStatus status,

        String comment
) {
}