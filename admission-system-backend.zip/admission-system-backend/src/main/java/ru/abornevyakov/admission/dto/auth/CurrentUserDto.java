package ru.abornevyakov.admission.dto.auth;

public record CurrentUserDto(
        Long userId,
        Long applicantId,
        String email,
        String role
) {
}