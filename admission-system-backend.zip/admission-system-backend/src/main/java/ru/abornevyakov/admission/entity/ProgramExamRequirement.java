package ru.abornevyakov.admission.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(
        name = "program_exam_requirements",
        uniqueConstraints = {
                @UniqueConstraint(columnNames = {"program_id", "exam_subject_id"})
        }
)
@Getter
@Setter
@NoArgsConstructor
public class ProgramExamRequirement {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(optional = false)
    @JoinColumn(name = "program_id", nullable = false)
    private Program program;

    @ManyToOne(optional = false)
    @JoinColumn(name = "exam_subject_id", nullable = false)
    private ExamSubject examSubject;

    @OneToOne(optional = false, cascade = CascadeType.ALL, orphanRemoval = true)
    @JoinColumn(name = "minimum_exam_score_id", nullable = false)
    private MinimumExamScore minimumExamScore;
}