package ru.abornevyakov.admission.controller.officer;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;
import ru.abornevyakov.admission.dto.application.ApplicationDto;
import ru.abornevyakov.admission.dto.application.ApplicationStatusUpdateRequest;
import ru.abornevyakov.admission.dto.officer.OfficerApplicationDetailsDto;
import ru.abornevyakov.admission.entity.enums.ApplicationStatus;
import ru.abornevyakov.admission.service.application.ApplicationService;
import ru.abornevyakov.admission.service.officer.OfficerApplicationDetailsService;

import java.util.List;

@RestController
@RequestMapping("/api/applications")
@RequiredArgsConstructor
public class OfficerApplicationController {

    private final ApplicationService applicationService;
    private final OfficerApplicationDetailsService officerApplicationDetailsService;

    @GetMapping
    public List<ApplicationDto> getApplications(
            @RequestParam(required = false) ApplicationStatus status,
            @RequestParam(required = false) Long campaignId
    ) {
        return applicationService.getApplications(status, campaignId);
    }

    @GetMapping("/{applicationId}")
    public ApplicationDto getApplicationById(
            @PathVariable Long applicationId
    ) {
        return applicationService.getApplicationById(applicationId);
    }

    @GetMapping("/{applicationId}/details")
    public OfficerApplicationDetailsDto getApplicationDetails(
            @PathVariable Long applicationId
    ) {
        return officerApplicationDetailsService.getApplicationDetails(applicationId);
    }

    @PatchMapping("/{applicationId}/status")
    public ApplicationDto updateApplicationStatus(
            @PathVariable Long applicationId,
            @Valid @RequestBody ApplicationStatusUpdateRequest request
    ) {
        return applicationService.updateApplicationStatus(applicationId, request);
    }
}
