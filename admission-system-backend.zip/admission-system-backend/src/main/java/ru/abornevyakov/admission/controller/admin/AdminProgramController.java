package ru.abornevyakov.admission.controller.admin;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;
import ru.abornevyakov.admission.dto.program.ProgramDto;
import ru.abornevyakov.admission.dto.program.ProgramRequest;
import ru.abornevyakov.admission.service.program.ProgramService;

import java.util.List;

@RestController
@RequestMapping("/api/admin/programs")
@RequiredArgsConstructor
public class AdminProgramController {

    private final ProgramService programService;

    @GetMapping
    public List<ProgramDto> getAllPrograms() {
        return programService.getAllProgramsForAdmin();
    }

    @PostMapping
    public ProgramDto createProgram(@Valid @RequestBody ProgramRequest request) {
        return programService.createProgram(request);
    }

    @PutMapping("/{programId}")
    public ProgramDto updateProgram(
            @PathVariable Long programId,
            @Valid @RequestBody ProgramRequest request
    ) {
        return programService.updateProgram(programId, request);
    }
}