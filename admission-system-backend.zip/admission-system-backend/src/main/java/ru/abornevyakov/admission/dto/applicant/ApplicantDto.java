package ru.abornevyakov.admission.dto.applicant;

import java.time.LocalDate;

public record ApplicantDto(
        Long applicantId,
        Long userId,
        String email,
        String role,
        String lastName,
        String firstName,
        String middleName,
        LocalDate birthDate,
        String phone,
        String passportNumber,
        Integer achievementsScore
) {
}