package ru.abornevyakov.admission.mapper;

import org.springframework.stereotype.Component;
import ru.abornevyakov.admission.dto.exam.ExamSubjectDto;
import ru.abornevyakov.admission.entity.ExamSubject;

@Component
public class ExamSubjectMapper {

    public ExamSubjectDto toDto(ExamSubject subject) {
        return new ExamSubjectDto(
                subject.getId(),
                subject.getName()
        );
    }
}
