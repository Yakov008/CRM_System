package ru.abornevyakov.admission.config;

import lombok.RequiredArgsConstructor;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import ru.abornevyakov.admission.entity.*;
import ru.abornevyakov.admission.repository.*;

import java.time.LocalDate;

@Component
@RequiredArgsConstructor
public class DataInitializer implements CommandLineRunner {

    private final AdmissionCampaignRepository campaignRepository;
    private final ProgramRepository programRepository;
    private final ExamSubjectRepository subjectRepository;
    private final ProgramExamRequirementRepository requirementRepository;

    @Override
    public void run(String... args) {
        if (campaignRepository.count() > 0) {
            return;
        }

        AdmissionCampaign campaign = new AdmissionCampaign();
        campaign.setName("Приёмная кампания 2026");
        campaign.setYear(2026);
        campaign.setStartDate(LocalDate.of(2026, 6, 20));
        campaign.setEndDate(LocalDate.of(2026, 8, 20));
        campaign.setActive(true);
        campaignRepository.save(campaign);

        ExamSubject russian = createSubject("Русский язык");
        ExamSubject math = createSubject("Математика");
        ExamSubject informatics = createSubject("Информатика");

        Program appliedInformatics = createProgram(
                "09.03.03",
                "Прикладная информатика",
                "Факультет информационных технологий",
                25,
                50,
                campaign
        );

        Program softwareEngineering = createProgram(
                "09.03.04",
                "Программная инженерия",
                "Факультет информационных технологий",
                20,
                45,
                campaign
        );

        createRequirement(appliedInformatics, russian, 40);
        createRequirement(appliedInformatics, math, 39);
        createRequirement(appliedInformatics, informatics, 44);

        createRequirement(softwareEngineering, russian, 40);
        createRequirement(softwareEngineering, math, 39);
        createRequirement(softwareEngineering, informatics, 46);
    }

    private ExamSubject createSubject(String name) {
        ExamSubject subject = new ExamSubject();
        subject.setName(name);
        return subjectRepository.save(subject);
    }

    private Program createProgram(
            String code,
            String name,
            String facultyName,
            Integer budgetPlaces,
            Integer paidPlaces,
            AdmissionCampaign campaign
    ) {
        Program program = new Program();
        program.setCode(code);
        program.setName(name);
        program.setFacultyName(facultyName);
        program.setBudgetPlaces(budgetPlaces);
        program.setPaidPlaces(paidPlaces);
        program.setAdmissionCampaign(campaign);
        program.setActive(true);
        return programRepository.save(program);
    }

    private ProgramExamRequirement createRequirement(
            Program program,
            ExamSubject subject,
            Integer minimumScoreValue
    ) {
        MinimumExamScore minimumScore = new MinimumExamScore();
        minimumScore.setScore(minimumScoreValue);

        ProgramExamRequirement requirement = new ProgramExamRequirement();
        requirement.setProgram(program);
        requirement.setExamSubject(subject);
        requirement.setMinimumExamScore(minimumScore);

        return requirementRepository.save(requirement);
    }
}