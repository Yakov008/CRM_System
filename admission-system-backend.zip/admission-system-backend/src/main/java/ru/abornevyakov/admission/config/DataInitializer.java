package ru.abornevyakov.admission.config;

import lombok.RequiredArgsConstructor;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;
import ru.abornevyakov.admission.entity.*;
import ru.abornevyakov.admission.entity.enums.ApplicationStatus;
import ru.abornevyakov.admission.entity.enums.DocumentStatus;
import ru.abornevyakov.admission.entity.enums.DocumentType;
import ru.abornevyakov.admission.entity.enums.RoleType;
import ru.abornevyakov.admission.repository.*;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Component
@RequiredArgsConstructor
public class DataInitializer implements CommandLineRunner {

    private static final String IT_FACULTY = "Факультет информационных технологий";
    private static final String ECONOMICS_FACULTY = "Экономический факультет";
    private static final String LAW_FACULTY = "Юридический факультет";

    private final AdmissionCampaignRepository campaignRepository;
    private final ProgramRepository programRepository;
    private final FacultyRepository facultyRepository;
    private final ExamSubjectRepository subjectRepository;
    private final ProgramExamRequirementRepository requirementRepository;
    private final UserRepository userRepository;
    private final ApplicantRepository applicantRepository;
    private final ApplicationRepository applicationRepository;
    private final ApplicationPriorityRepository priorityRepository;
    private final ExamResultRepository examResultRepository;
    private final ApplicationDocumentRepository documentRepository;
    private final PasswordEncoder passwordEncoder;

    @Override
    public void run(String... args) {
        ExamSubject russian = getOrCreateSubject("Русский язык");
        ExamSubject math = getOrCreateSubject("Математика");
        ExamSubject informatics = getOrCreateSubject("Информатика");
        ExamSubject socialStudies = getOrCreateSubject("Обществознание");
        ExamSubject english = getOrCreateSubject("Английский язык");
        ExamSubject history = getOrCreateSubject("История");

        getOrCreateFaculty(IT_FACULTY);
        getOrCreateFaculty(ECONOMICS_FACULTY);
        getOrCreateFaculty(LAW_FACULTY);

        AdmissionCampaign campaign2025 = getOrCreateCampaign(
                "Приёмная кампания 2025",
                2025,
                LocalDate.of(2025, 6, 20),
                LocalDate.of(2025, 8, 20),
                false
        );

        AdmissionCampaign campaign2026 = getOrCreateCampaign(
                "Приёмная кампания 2026",
                2026,
                LocalDate.of(2026, 6, 20),
                LocalDate.of(2026, 8, 20),
                true
        );

        AdmissionCampaign campaign2027 = getOrCreateCampaign(
                "Приёмная кампания 2027",
                2027,
                LocalDate.of(2027, 6, 19),
                LocalDate.of(2027, 8, 21),
                true
        );

        deleteAccidentalAppliedInformaticsMasterProgram();

        Program appliedInformatics2026 = getOrCreateProgram(
                campaign2026,
                "09.03.03",
                "Прикладная информатика",
                IT_FACULTY,
                25,
                50,
                true
        );
        Program softwareEngineering2026 = getOrCreateProgram(
                campaign2026,
                "09.03.04",
                "Программная инженерия",
                IT_FACULTY,
                20,
                45,
                true
        );
        Program informationSecurity2026 = getOrCreateProgram(
                campaign2026,
                "10.03.01",
                "Информационная безопасность",
                IT_FACULTY,
                15,
                30,
                true
        );
        Program dataScience2026 = getOrCreateProgram(
                campaign2026,
                "09.03.06",
                "Data Science и искусственный интеллект",
                IT_FACULTY,
                1,
                25,
                true
        );
        Program economics2026 = getOrCreateProgram(
                campaign2026,
                "38.03.01",
                "Экономика",
                ECONOMICS_FACULTY,
                18,
                60,
                true
        );
        Program management2026 = getOrCreateProgram(
                campaign2026,
                "38.03.02",
                "Менеджмент",
                ECONOMICS_FACULTY,
                16,
                55,
                true
        );
        Program law2026 = getOrCreateProgram(
                campaign2026,
                "40.03.01",
                "Юриспруденция",
                LAW_FACULTY,
                12,
                70,
                true
        );

        Program appliedInformatics2025 = getOrCreateProgram(
                campaign2025,
                "09.03.03",
                "Прикладная информатика",
                IT_FACULTY,
                22,
                45,
                false
        );
        Program economics2025 = getOrCreateProgram(
                campaign2025,
                "38.03.01",
                "Экономика",
                ECONOMICS_FACULTY,
                15,
                50,
                false
        );

        Program aiSystems2027 = getOrCreateProgram(
                campaign2027,
                "09.03.05",
                "Интеллектуальные системы и технологии",
                IT_FACULTY,
                18,
                40,
                true
        );
        Program businessAnalytics2027 = getOrCreateProgram(
                campaign2027,
                "38.03.05",
                "Бизнес-аналитика",
                ECONOMICS_FACULTY,
                14,
                45,
                true
        );

        createItRequirements(appliedInformatics2026, russian, math, informatics, 44);
        createItRequirements(softwareEngineering2026, russian, math, informatics, 46);
        createItRequirements(informationSecurity2026, russian, math, informatics, 48);
        createItRequirements(dataScience2026, russian, math, informatics, 50);
        createItRequirements(appliedInformatics2025, russian, math, informatics, 44);
        createItRequirements(aiSystems2027, russian, math, informatics, 50);

        createEconomicsRequirements(economics2026, russian, math, socialStudies);
        createEconomicsRequirements(management2026, russian, math, socialStudies);
        createEconomicsRequirements(economics2025, russian, math, socialStudies);
        createEconomicsRequirements(businessAnalytics2027, russian, math, socialStudies);

        createRequirement(law2026, russian, 40);
        createRequirement(law2026, socialStudies, 45);
        createRequirement(law2026, history, 40);

        Applicant ivan = getOrCreateApplicant(
                "ivan.petrov@example.com",
                "applicant123",
                "Петров",
                "Иван",
                "Сергеевич",
                LocalDate.of(2007, 3, 14),
                "+7 914 111-22-33",
                "2500123456",
                7
        );
        Applicant anna = getOrCreateApplicant(
                "anna.smirnova@example.com",
                "applicant123",
                "Смирнова",
                "Анна",
                "Андреевна",
                LocalDate.of(2006, 11, 2),
                "+7 914 222-33-44",
                "2500654321",
                10
        );
        Applicant maxim = getOrCreateApplicant(
                "maxim.kuznetsov@example.com",
                "applicant123",
                "Кузнецов",
                "Максим",
                "Игоревич",
                LocalDate.of(2007, 1, 27),
                "+7 914 333-44-55",
                "2500789123",
                4
        );
        Applicant maria = getOrCreateApplicant(
                "maria.volkova@example.com",
                "applicant123",
                "Волкова",
                "Мария",
                "Олеговна",
                LocalDate.of(2007, 5, 9),
                "+7 914 444-55-66",
                "2500888777",
                8
        );
        Applicant pavel = getOrCreateApplicant(
                "pavel.orlov@example.com",
                "applicant123",
                "Орлов",
                "Павел",
                "Дмитриевич",
                LocalDate.of(2006, 9, 18),
                "+7 914 555-66-77",
                "2500999888",
                3
        );
        Applicant dmitry = getOrCreateApplicant(
                "dmitry.sokolov@example.com",
                "applicant123",
                "Соколов",
                "Дмитрий",
                "Алексеевич",
                LocalDate.of(2007, 4, 21),
                "+7 914 666-77-88",
                "2500111222",
                6
        );
        Applicant elena = getOrCreateApplicant(
                "elena.morozova@example.com",
                "applicant123",
                "Морозова",
                "Елена",
                "Викторовна",
                LocalDate.of(2006, 12, 6),
                "+7 914 777-88-99",
                "2500222333",
                5
        );
        Applicant nikita = getOrCreateApplicant(
                "nikita.belov@example.com",
                "applicant123",
                "Белов",
                "Никита",
                "Романович",
                LocalDate.of(2007, 2, 11),
                "+7 914 888-99-00",
                "2500333444",
                2
        );
        Applicant sofia = getOrCreateApplicant(
                "sofia.egorova@example.com",
                "applicant123",
                "Егорова",
                "София",
                "Михайловна",
                LocalDate.of(2007, 7, 3),
                "+7 914 999-00-11",
                "2500444555",
                9
        );

        createExamResult(ivan, russian, 2026, 88);
        createExamResult(ivan, math, 2026, 92);
        createExamResult(ivan, informatics, 2026, 95);
        createExamResult(ivan, socialStudies, 2026, 74);

        createExamResult(anna, russian, 2026, 91);
        createExamResult(anna, math, 2026, 79);
        createExamResult(anna, informatics, 2026, 84);
        createExamResult(anna, socialStudies, 2026, 96);
        createExamResult(anna, english, 2026, 89);

        createExamResult(maxim, russian, 2026, 76);
        createExamResult(maxim, math, 2026, 81);
        createExamResult(maxim, informatics, 2026, 78);
        createExamResult(maxim, socialStudies, 2026, 82);
        createExamResult(maxim, history, 2026, 85);

        createExamResult(maria, russian, 2026, 96);
        createExamResult(maria, math, 2026, 98);
        createExamResult(maria, informatics, 2026, 97);

        createExamResult(pavel, russian, 2026, 82);
        createExamResult(pavel, math, 2026, 84);
        createExamResult(pavel, informatics, 2026, 86);

        createExamResult(dmitry, russian, 2026, 90);
        createExamResult(dmitry, math, 2026, 91);
        createExamResult(dmitry, informatics, 2026, 89);

        createExamResult(elena, russian, 2026, 84);
        createExamResult(elena, math, 2026, 88);
        createExamResult(elena, informatics, 2026, 90);

        createExamResult(nikita, russian, 2026, 78);
        createExamResult(nikita, math, 2026, 83);
        createExamResult(nikita, informatics, 2026, 80);

        createExamResult(sofia, russian, 2026, 93);
        createExamResult(sofia, math, 2026, 94);
        createExamResult(sofia, informatics, 2026, 92);

        Application ivanApplication = getOrCreateApplication(
                ivan,
                campaign2026,
                ApplicationStatus.UNDER_REVIEW,
                "Приоритет — IT-направления, документы на проверке"
        );
        createPriority(ivanApplication, softwareEngineering2026, 1);
        createPriority(ivanApplication, appliedInformatics2026, 2);
        createPriority(ivanApplication, informationSecurity2026, 3);
        createDocument(ivanApplication, DocumentType.PASSPORT, "passport_ivan_petrov.txt", DocumentStatus.VERIFIED);
        createDocument(ivanApplication, DocumentType.EDUCATION_CERTIFICATE, "certificate_ivan_petrov.txt", DocumentStatus.UPLOADED);

        Application annaApplication = getOrCreateApplication(
                anna,
                campaign2026,
                ApplicationStatus.SUBMITTED,
                "Рассматривает экономические направления"
        );
        createPriority(annaApplication, economics2026, 1);
        createPriority(annaApplication, management2026, 2);
        createPriority(annaApplication, appliedInformatics2026, 3);
        createDocument(annaApplication, DocumentType.PASSPORT, "passport_anna_smirnova.txt", DocumentStatus.UPLOADED);

        Application maximApplication = getOrCreateApplication(
                maxim,
                campaign2026,
                ApplicationStatus.APPROVED,
                "Заявление проверено сотрудником"
        );
        createPriority(maximApplication, informationSecurity2026, 1);
        createPriority(maximApplication, law2026, 2);
        createPriority(maximApplication, management2026, 3);
        createDocument(maximApplication, DocumentType.PASSPORT, "passport_maxim_kuznetsov.txt", DocumentStatus.VERIFIED);
        createDocument(maximApplication, DocumentType.CONSENT, "consent_maxim_kuznetsov.txt", DocumentStatus.VERIFIED);

        Application mariaApplication = getOrCreateApplication(
                maria,
                campaign2026,
                ApplicationStatus.UNDER_REVIEW,
                "Сильный конкурент на Data Science: занимает единственное бюджетное место"
        );
        createPriority(mariaApplication, dataScience2026, 1);
        createPriority(mariaApplication, softwareEngineering2026, 2);
        createPriority(mariaApplication, appliedInformatics2026, 3);
        createDocument(mariaApplication, DocumentType.PASSPORT, "passport_maria_volkova.txt", DocumentStatus.VERIFIED);

        Application pavelApplication = getOrCreateApplication(
                pavel,
                campaign2026,
                ApplicationStatus.SUBMITTED,
                "По первому приоритету не проходит на Data Science, но участвует в списках на прикладную информатику"
        );
        createPriority(pavelApplication, dataScience2026, 1);
        createPriority(pavelApplication, appliedInformatics2026, 2);
        createPriority(pavelApplication, softwareEngineering2026, 3);
        createDocument(pavelApplication, DocumentType.PASSPORT, "passport_pavel_orlov.txt", DocumentStatus.UPLOADED);

        Application dmitryApplication = getOrCreateApplication(
                dmitry,
                campaign2026,
                ApplicationStatus.SUBMITTED,
                "Участвует в конкурсе на Data Science и IT-направления"
        );
        createPriority(dmitryApplication, dataScience2026, 1);
        createPriority(dmitryApplication, softwareEngineering2026, 2);
        createPriority(dmitryApplication, appliedInformatics2026, 3);
        createDocument(dmitryApplication, DocumentType.PASSPORT, "passport_dmitry_sokolov.txt", DocumentStatus.UPLOADED);

        Application elenaApplication = getOrCreateApplication(
                elena,
                campaign2026,
                ApplicationStatus.UNDER_REVIEW,
                "Конкурсный пример для отображения границы бюджетных мест"
        );
        createPriority(elenaApplication, dataScience2026, 1);
        createPriority(elenaApplication, appliedInformatics2026, 2);
        createPriority(elenaApplication, informationSecurity2026, 3);
        createDocument(elenaApplication, DocumentType.PASSPORT, "passport_elena_morozova.txt", DocumentStatus.VERIFIED);

        Application nikitaApplication = getOrCreateApplication(
                nikita,
                campaign2026,
                ApplicationStatus.SUBMITTED,
                "Ниже бюджетной границы на первом приоритете"
        );
        createPriority(nikitaApplication, dataScience2026, 1);
        createPriority(nikitaApplication, appliedInformatics2026, 2);
        createPriority(nikitaApplication, softwareEngineering2026, 3);
        createDocument(nikitaApplication, DocumentType.PASSPORT, "passport_nikita_belov.txt", DocumentStatus.UPLOADED);

        Application sofiaApplication = getOrCreateApplication(
                sofia,
                campaign2026,
                ApplicationStatus.UNDER_REVIEW,
                "Сильный абитуриент для плотного конкурсного списка"
        );
        createPriority(sofiaApplication, dataScience2026, 1);
        createPriority(sofiaApplication, softwareEngineering2026, 2);
        createPriority(sofiaApplication, appliedInformatics2026, 3);
        createDocument(sofiaApplication, DocumentType.PASSPORT, "passport_sofia_egorova.txt", DocumentStatus.VERIFIED);
    }

    private AdmissionCampaign getOrCreateCampaign(
            String name,
            Integer year,
            LocalDate startDate,
            LocalDate endDate,
            boolean active
    ) {
        return campaignRepository.findAll()
                .stream()
                .filter(campaign -> campaign.getYear().equals(year) && campaign.getName().equalsIgnoreCase(name))
                .findFirst()
                .map(campaign -> {
                    campaign.setStartDate(startDate);
                    campaign.setEndDate(endDate);
                    campaign.setActive(active);
                    return campaignRepository.save(campaign);
                })
                .orElseGet(() -> {
                    AdmissionCampaign campaign = new AdmissionCampaign();
                    campaign.setName(name);
                    campaign.setYear(year);
                    campaign.setStartDate(startDate);
                    campaign.setEndDate(endDate);
                    campaign.setActive(active);
                    return campaignRepository.save(campaign);
                });
    }

    private ExamSubject getOrCreateSubject(String name) {
        return subjectRepository.findAll()
                .stream()
                .filter(subject -> subject.getName().equalsIgnoreCase(name))
                .findFirst()
                .orElseGet(() -> {
                    ExamSubject subject = new ExamSubject();
                    subject.setName(name);
                    return subjectRepository.save(subject);
                });
    }

    private Faculty getOrCreateFaculty(String name) {
        return facultyRepository.findAll()
                .stream()
                .filter(faculty -> faculty.getName().equalsIgnoreCase(name))
                .findFirst()
                .orElseGet(() -> {
                    Faculty faculty = new Faculty();
                    faculty.setName(name);
                    return facultyRepository.save(faculty);
                });
    }

    private Program getOrCreateProgram(
            AdmissionCampaign campaign,
            String code,
            String name,
            String facultyName,
            Integer budgetPlaces,
            Integer paidPlaces,
            boolean active
    ) {
        return programRepository.findByAdmissionCampaignId(campaign.getId())
                .stream()
                .filter(program -> program.getCode().equalsIgnoreCase(code))
                .findFirst()
                .map(program -> {
                    program.setName(name);
                    program.setFacultyName(facultyName);
                    program.setBudgetPlaces(budgetPlaces);
                    program.setPaidPlaces(paidPlaces);
                    program.setActive(active);
                    return programRepository.save(program);
                })
                .orElseGet(() -> {
                    Program program = new Program();
                    program.setAdmissionCampaign(campaign);
                    program.setCode(code);
                    program.setName(name);
                    program.setFacultyName(facultyName);
                    program.setBudgetPlaces(budgetPlaces);
                    program.setPaidPlaces(paidPlaces);
                    program.setActive(active);
                    return programRepository.save(program);
                });
    }

    private void deleteAccidentalAppliedInformaticsMasterProgram() {
        programRepository.findAll()
                .stream()
                .filter(program -> "09.04.03".equalsIgnoreCase(program.getCode()))
                .filter(program -> "Прикладная информатика".equalsIgnoreCase(program.getName()))
                .filter(program -> priorityRepository.findByProgramId(program.getId()).isEmpty())
                .forEach(program -> {
                    requirementRepository.deleteAll(requirementRepository.findByProgramId(program.getId()));
                    programRepository.delete(program);
                });
    }

    private void createItRequirements(
            Program program,
            ExamSubject russian,
            ExamSubject math,
            ExamSubject informatics,
            Integer informaticsMinimum
    ) {
        createRequirement(program, russian, 40);
        createRequirement(program, math, 39);
        createRequirement(program, informatics, informaticsMinimum);
    }

    private void createEconomicsRequirements(
            Program program,
            ExamSubject russian,
            ExamSubject math,
            ExamSubject socialStudies
    ) {
        createRequirement(program, russian, 40);
        createRequirement(program, math, 39);
        createRequirement(program, socialStudies, 45);
    }

    private void createRequirement(
            Program program,
            ExamSubject subject,
            Integer minimumScoreValue
    ) {
        if (requirementRepository.existsByProgramIdAndExamSubjectId(program.getId(), subject.getId())) {
            return;
        }

        MinimumExamScore minimumScore = new MinimumExamScore();
        minimumScore.setScore(minimumScoreValue);

        ProgramExamRequirement requirement = new ProgramExamRequirement();
        requirement.setProgram(program);
        requirement.setExamSubject(subject);
        requirement.setMinimumExamScore(minimumScore);

        requirementRepository.save(requirement);
    }

    private Applicant getOrCreateApplicant(
            String email,
            String password,
            String lastName,
            String firstName,
            String middleName,
            LocalDate birthDate,
            String phone,
            String passportNumber,
            Integer achievementsScore
    ) {
        return userRepository.findByEmail(email)
                .flatMap(user -> applicantRepository.findByUserId(user.getId()))
                .map(applicant -> {
                    ApplicantProfile profile = applicant.getProfile();
                    profile.setLastName(lastName);
                    profile.setFirstName(firstName);
                    profile.setMiddleName(middleName);
                    profile.setBirthDate(birthDate);
                    profile.setPhone(phone);
                    profile.setPassportNumber(passportNumber);
                    applicant.setAchievementsScore(achievementsScore);
                    return applicantRepository.save(applicant);
                })
                .orElseGet(() -> {
                    User user = new User();
                    user.setEmail(email);
                    user.setPassword(passwordEncoder.encode(password));
                    user.setRole(RoleType.APPLICANT);
                    user.setActive(true);
                    User savedUser = userRepository.save(user);

                    ApplicantProfile profile = new ApplicantProfile();
                    profile.setLastName(lastName);
                    profile.setFirstName(firstName);
                    profile.setMiddleName(middleName);
                    profile.setBirthDate(birthDate);
                    profile.setPhone(phone);
                    profile.setPassportNumber(passportNumber);

                    Applicant applicant = new Applicant();
                    applicant.setUser(savedUser);
                    applicant.setProfile(profile);
                    applicant.setAchievementsScore(achievementsScore);

                    return applicantRepository.save(applicant);
                });
    }

    private void createExamResult(Applicant applicant, ExamSubject subject, Integer examYear, Integer score) {
        if (examResultRepository.existsByApplicantIdAndExamSubjectIdAndExamYear(
                applicant.getId(),
                subject.getId(),
                examYear
        )) {
            return;
        }

        ExamResult result = new ExamResult();
        result.setApplicant(applicant);
        result.setExamSubject(subject);
        result.setExamYear(examYear);
        result.setScore(score);
        result.setCreatedAt(LocalDateTime.now().minusDays(10));

        examResultRepository.save(result);
    }

    private Application getOrCreateApplication(
            Applicant applicant,
            AdmissionCampaign campaign,
            ApplicationStatus status,
            String comment
    ) {
        return applicationRepository.findByApplicantIdAndAdmissionCampaignId(applicant.getId(), campaign.getId())
                .map(application -> {
                    application.setStatus(status);
                    application.setComment(comment);
                    return applicationRepository.save(application);
                })
                .orElseGet(() -> {
                    LocalDateTime now = LocalDateTime.now().minusDays(3);

                    Application application = new Application();
                    application.setApplicant(applicant);
                    application.setAdmissionCampaign(campaign);
                    application.setStatus(status);
                    application.setSubmittedAt(now);
                    application.setLockedUntil(now.minusHours(1));
                    application.setComment(comment);

                    return applicationRepository.save(application);
                });
    }

    private void createPriority(Application application, Program program, Integer priorityNumber) {
        boolean exists = priorityRepository.findByApplicationIdOrderByPriorityNumberAsc(application.getId())
                .stream()
                .anyMatch(priority -> priority.getProgram().getId().equals(program.getId())
                        || priority.getPriorityNumber().equals(priorityNumber));

        if (exists) {
            return;
        }

        ApplicationPriority priority = new ApplicationPriority();
        priority.setApplication(application);
        priority.setProgram(program);
        priority.setPriorityNumber(priorityNumber);

        priorityRepository.save(priority);
    }

    private void createDocument(
            Application application,
            DocumentType documentType,
            String fileName,
            DocumentStatus status
    ) {
        boolean exists = documentRepository.findByApplicationId(application.getId())
                .stream()
                .anyMatch(document -> document.getDocumentType() == documentType);

        if (exists) {
            return;
        }

        String storedFileName = "demo-" + application.getId() + "-" + fileName;
        createDemoUploadFile(storedFileName, application, documentType);

        ApplicationDocument document = new ApplicationDocument();
        document.setApplication(application);
        document.setDocumentType(documentType);
        document.setFileName(fileName);
        document.setFilePath("/uploads/" + storedFileName);
        document.setStatus(status);
        document.setComment(status == DocumentStatus.VERIFIED ? "Документ проверен" : "Ожидает проверки");

        documentRepository.save(document);
    }

    private void createDemoUploadFile(
            String storedFileName,
            Application application,
            DocumentType documentType
    ) {
        try {
            Path uploadDir = Path.of("uploads").toAbsolutePath().normalize();
            Files.createDirectories(uploadDir);

            Path filePath = uploadDir.resolve(storedFileName).normalize();

            if (!filePath.startsWith(uploadDir)) {
                return;
            }

            String content = "Демо-файл документа\n"
                    + "Заявление ID: " + application.getId() + "\n"
                    + "Абитуриент ID: " + application.getApplicant().getId() + "\n"
                    + "Тип документа: " + documentType + "\n";

            Files.writeString(filePath, content, StandardCharsets.UTF_8);
        } catch (IOException ignored) {
            // Демо-документ не критичен для запуска приложения.
        }
    }
}
