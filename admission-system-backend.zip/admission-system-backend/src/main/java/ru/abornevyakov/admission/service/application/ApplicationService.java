package ru.abornevyakov.admission.service.application;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.abornevyakov.admission.dto.application.ApplicationCreateRequest;
import ru.abornevyakov.admission.dto.application.ApplicationDto;
import ru.abornevyakov.admission.dto.application.ApplicationPriorityRequest;
import ru.abornevyakov.admission.dto.application.ApplicationStatusUpdateRequest;
import ru.abornevyakov.admission.dto.application.ApplicationUpdateRequest;
import ru.abornevyakov.admission.entity.AdmissionCampaign;
import ru.abornevyakov.admission.entity.Applicant;
import ru.abornevyakov.admission.entity.Application;
import ru.abornevyakov.admission.entity.ApplicationPriority;
import ru.abornevyakov.admission.entity.Program;
import ru.abornevyakov.admission.entity.ProgramExamRequirement;
import ru.abornevyakov.admission.entity.enums.ApplicationStatus;
import ru.abornevyakov.admission.entity.enums.RoleType;
import ru.abornevyakov.admission.exception.BadRequestException;
import ru.abornevyakov.admission.exception.ResourceNotFoundException;
import ru.abornevyakov.admission.mapper.ApplicationMapper;
import ru.abornevyakov.admission.repository.AdmissionCampaignRepository;
import ru.abornevyakov.admission.repository.ApplicantRepository;
import ru.abornevyakov.admission.repository.ApplicationPriorityRepository;
import ru.abornevyakov.admission.repository.ApplicationRepository;
import ru.abornevyakov.admission.repository.ExamResultRepository;
import ru.abornevyakov.admission.repository.ProgramExamRequirementRepository;
import ru.abornevyakov.admission.repository.ProgramRepository;
import ru.abornevyakov.admission.service.auth.CurrentUserService;
import ru.abornevyakov.admission.service.officer.OfficerScopeService;

import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Service
@RequiredArgsConstructor
public class ApplicationService {

    private final ApplicantRepository applicantRepository;
    private final AdmissionCampaignRepository admissionCampaignRepository;
    private final ProgramRepository programRepository;
    private final ApplicationRepository applicationRepository;
    private final ApplicationPriorityRepository applicationPriorityRepository;
    private final ProgramExamRequirementRepository requirementRepository;
    private final ExamResultRepository examResultRepository;
    private final CurrentUserService currentUserService;
    private final OfficerScopeService officerScopeService;
    private final ApplicationMapper applicationMapper;

    @Transactional
    public ApplicationDto createApplication(Long applicantId, ApplicationCreateRequest request) {
        currentUserService.checkApplicantAccess(applicantId);

        Applicant applicant = applicantRepository.findById(applicantId)
                .orElseThrow(() -> new ResourceNotFoundException("Абитуриент не найден"));

        AdmissionCampaign campaign = admissionCampaignRepository.findById(request.admissionCampaignId())
                .orElseThrow(() -> new ResourceNotFoundException("Приёмная кампания не найдена"));

        if (!campaign.isActive()) {
            throw new BadRequestException("Нельзя подать заявление в неактивную приёмную кампанию");
        }

        if (applicationRepository.findByApplicantIdAndAdmissionCampaignId(applicantId, campaign.getId()).isPresent()) {
            throw new BadRequestException("Заявление на эту приёмную кампанию уже существует");
        }

        validatePriorities(request.priorities());

        LocalDateTime now = LocalDateTime.now();
        boolean submit = !Boolean.FALSE.equals(request.submit());

        Application application = new Application();
        application.setApplicant(applicant);
        application.setAdmissionCampaign(campaign);
        application.setStatus(submit ? ApplicationStatus.SUBMITTED : ApplicationStatus.DRAFT);
        application.setSubmittedAt(submit ? now : null);
        application.setLockedUntil(submit ? now.plusHours(1) : null);
        application.setComment(request.comment());

        Application savedApplication = applicationRepository.save(application);

        for (ApplicationPriorityRequest priorityRequest : request.priorities()) {
            Program program = programRepository.findById(priorityRequest.programId())
                    .orElseThrow(() -> new ResourceNotFoundException("Направление не найдено"));

            if (!program.isActive()) {
                throw new BadRequestException("Направление неактивно: " + program.getName());
            }

            if (!program.getAdmissionCampaign().getId().equals(campaign.getId())) {
                throw new BadRequestException("Направление не относится к выбранной приёмной кампании: " + program.getName());
            }

            if (submit) {
                validateExamResults(applicantId, program);
            }

            ApplicationPriority priority = new ApplicationPriority();
            priority.setApplication(savedApplication);
            priority.setProgram(program);
            priority.setPriorityNumber(priorityRequest.priorityNumber());

            applicationPriorityRepository.save(priority);
        }

        return getApplicationById(savedApplication.getId());
    }

    @Transactional
    public ApplicationDto submitApplication(Long applicantId, Long applicationId) {
        currentUserService.checkApplicantAccess(applicantId);

        Application application = applicationRepository.findById(applicationId)
                .orElseThrow(() -> new ResourceNotFoundException("Заявление не найдено"));

        if (!application.getApplicant().getId().equals(applicantId)) {
            throw new BadRequestException("Заявление не принадлежит указанному абитуриенту");
        }

        checkApplicationUnlocked(application);
        checkApplicationCanBeEdited(application);

        if (application.getStatus() != ApplicationStatus.DRAFT) {
            throw new BadRequestException("Подать можно только черновик заявления");
        }

        List<ApplicationPriority> priorities = applicationPriorityRepository
                .findByApplicationIdOrderByPriorityNumberAsc(application.getId());

        if (priorities.isEmpty()) {
            throw new BadRequestException("Нужно выбрать хотя бы одно направление");
        }

        for (ApplicationPriority priority : priorities) {
            validateExamResults(applicantId, priority.getProgram());
        }

        LocalDateTime now = LocalDateTime.now();

        application.setStatus(ApplicationStatus.SUBMITTED);
        application.setSubmittedAt(now);
        application.setLockedUntil(now.plusHours(1));

        return applicationMapper.toDto(applicationRepository.save(application));
    }

    @Transactional
    public ApplicationDto updateApplication(
            Long applicantId,
            Long applicationId,
            ApplicationUpdateRequest request
    ) {
        currentUserService.checkApplicantAccess(applicantId);

        Application application = applicationRepository.findById(applicationId)
                .orElseThrow(() -> new ResourceNotFoundException("Заявление не найдено"));

        if (!application.getApplicant().getId().equals(applicantId)) {
            throw new BadRequestException("Заявление не принадлежит указанному абитуриенту");
        }

        checkApplicationUnlocked(application);
        checkApplicationCanBeEdited(application);
        validatePriorities(request.priorities());

        AdmissionCampaign campaign = application.getAdmissionCampaign();

        applicationPriorityRepository.deleteByApplicationId(application.getId());
        applicationPriorityRepository.flush();

        for (ApplicationPriorityRequest priorityRequest : request.priorities()) {
            Program program = programRepository.findById(priorityRequest.programId())
                    .orElseThrow(() -> new ResourceNotFoundException("Направление не найдено"));

            if (!program.isActive()) {
                throw new BadRequestException("Направление неактивно: " + program.getName());
            }

            if (!program.getAdmissionCampaign().getId().equals(campaign.getId())) {
                throw new BadRequestException("Направление не относится к приёмной кампании заявления: " + program.getName());
            }

            validateExamResults(applicantId, program);

            ApplicationPriority priority = new ApplicationPriority();
            priority.setApplication(application);
            priority.setProgram(program);
            priority.setPriorityNumber(priorityRequest.priorityNumber());

            applicationPriorityRepository.save(priority);
        }

        LocalDateTime now = LocalDateTime.now();

        application.setComment(request.comment());
        application.setLockedUntil(
                application.getStatus() == ApplicationStatus.DRAFT ? null : now.plusHours(1)
        );

        Application savedApplication = applicationRepository.save(application);

        return applicationMapper.toDto(savedApplication);
    }

    @Transactional
    public ApplicationDto withdrawApplication(Long applicantId, Long applicationId) {
        currentUserService.checkApplicantAccess(applicantId);

        Application application = applicationRepository.findById(applicationId)
                .orElseThrow(() -> new ResourceNotFoundException("Заявление не найдено"));

        if (!application.getApplicant().getId().equals(applicantId)) {
            throw new BadRequestException("Заявление не принадлежит указанному абитуриенту");
        }

        if (application.getStatus() == ApplicationStatus.WITHDRAWN) {
            throw new BadRequestException("Заявление уже отозвано");
        }

        if (application.getStatus() == ApplicationStatus.APPROVED) {
            throw new BadRequestException("Принятое заявление нельзя отозвать через личный кабинет");
        }

        if (application.getStatus() == ApplicationStatus.REJECTED) {
            throw new BadRequestException("Отклонённое заявление нельзя отозвать");
        }

        if (application.getLockedUntil() != null
                && application.getLockedUntil().isAfter(LocalDateTime.now())) {
            throw new BadRequestException("Заявление нельзя отозвать до " + application.getLockedUntil());
        }

        application.setStatus(ApplicationStatus.WITHDRAWN);
        application.setComment("Заявление отозвано абитуриентом");

        Application savedApplication = applicationRepository.save(application);

        return applicationMapper.toDto(savedApplication);
    }

    @Transactional(readOnly = true)
    public List<ApplicationDto> getApplicationsByApplicantId(Long applicantId) {
        currentUserService.checkApplicantAccess(applicantId);

        if (!applicantRepository.existsById(applicantId)) {
            throw new ResourceNotFoundException("Абитуриент не найден");
        }

        return applicationRepository.findByApplicantId(applicantId)
                .stream()
                .map(applicationMapper::toDto)
                .toList();
    }

    @Transactional(readOnly = true)
    public ApplicationDto getApplicationById(Long applicationId) {
        Application application = applicationRepository.findById(applicationId)
                .orElseThrow(() -> new ResourceNotFoundException("Заявление не найдено"));

        if (currentUserService.getCurrentPrincipal().getRole() == RoleType.APPLICANT) {
            currentUserService.checkApplicantAccess(application.getApplicant().getId());
        } else {
            officerScopeService.checkApplicationAccess(application);
        }

        return applicationMapper.toDto(application);
    }

    @Transactional(readOnly = true)
    public List<ApplicationDto> getAllApplications() {
        return getApplications(null, null);
    }

    @Transactional(readOnly = true)
    public List<ApplicationDto> getApplicationsByStatus(ApplicationStatus status) {
        return getApplications(status, null);
    }

    @Transactional(readOnly = true)
    public List<ApplicationDto> getApplications(ApplicationStatus status, Long campaignId) {
        List<Application> applications;

        if (status != null && campaignId != null) {
            applications = applicationRepository.findByStatusAndAdmissionCampaignIdOrderByCreatedAtDesc(
                    status,
                    campaignId
            );
        } else if (status != null) {
            applications = applicationRepository.findByStatusOrderByCreatedAtDesc(status);
        } else if (campaignId != null) {
            applications = applicationRepository.findByAdmissionCampaignIdOrderByCreatedAtDesc(campaignId);
        } else {
            applications = applicationRepository.findAllByOrderByCreatedAtDesc();
        }

        return officerScopeService.filterApplicationsForCurrentUser(
                        applications
                )
                .stream()
                .map(applicationMapper::toDto)
                .toList();
    }

    @Transactional
    public ApplicationDto updateApplicationStatus(
            Long applicationId,
            ApplicationStatusUpdateRequest request
    ) {
        Application application = applicationRepository.findById(applicationId)
                .orElseThrow(() -> new ResourceNotFoundException("Заявление не найдено"));

        officerScopeService.checkApplicationAccess(application);

        application.setStatus(request.status());
        application.setComment(request.comment());
        application.setLockedUntil(LocalDateTime.now().plusHours(1));

        Application savedApplication = applicationRepository.save(application);

        return applicationMapper.toDto(savedApplication);
    }

    private void checkApplicationUnlocked(Application application) {
        if (application.getLockedUntil() != null
                && LocalDateTime.now().isBefore(application.getLockedUntil())) {
            throw new BadRequestException(
                    "Заявление нельзя изменять до " + application.getLockedUntil()
            );
        }
    }

    private void checkApplicationCanBeEdited(Application application) {
        ApplicationStatus status = application.getStatus();

        if (status == ApplicationStatus.APPROVED
                || status == ApplicationStatus.REJECTED
                || status == ApplicationStatus.WITHDRAWN) {
            throw new BadRequestException("Заявление с текущим статусом нельзя редактировать");
        }
    }

    private void validatePriorities(List<ApplicationPriorityRequest> priorities) {
        if (priorities == null || priorities.isEmpty()) {
            throw new BadRequestException("Нужно выбрать хотя бы одно направление");
        }

        Set<Long> programIds = new HashSet<>();
        Set<Integer> priorityNumbers = new HashSet<>();

        for (ApplicationPriorityRequest priority : priorities) {
            if (!programIds.add(priority.programId())) {
                throw new BadRequestException("Одно направление нельзя выбрать два раза");
            }

            if (!priorityNumbers.add(priority.priorityNumber())) {
                throw new BadRequestException("Номер приоритета не должен повторяться");
            }
        }

        for (int priorityNumber = 1; priorityNumber <= priorities.size(); priorityNumber++) {
            if (!priorityNumbers.contains(priorityNumber)) {
                throw new BadRequestException("Приоритеты должны идти подряд, начиная с 1");
            }
        }
    }

    private void validateExamResults(Long applicantId, Program program) {
        List<ProgramExamRequirement> requirements = requirementRepository.findByProgramId(program.getId());

        for (ProgramExamRequirement requirement : requirements) {
            Long subjectId = requirement.getExamSubject().getId();
            String subjectName = requirement.getExamSubject().getName();

            Integer minimumScore = requirement.getMinimumExamScore() == null
                    ? 0
                    : requirement.getMinimumExamScore().getScore();

            boolean hasPassedResult = examResultRepository
                    .findByApplicantIdAndExamSubjectId(applicantId, subjectId)
                    .stream()
                    .anyMatch(result -> result.getScore() >= minimumScore);

            if (!hasPassedResult) {
                throw new BadRequestException(
                        "Недостаточно баллов или отсутствует результат по предмету: " + subjectName
                );
            }
        }
    }
}
