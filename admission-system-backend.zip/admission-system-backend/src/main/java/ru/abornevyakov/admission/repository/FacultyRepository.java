package ru.abornevyakov.admission.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import ru.abornevyakov.admission.entity.Faculty;

import java.util.Optional;

public interface FacultyRepository extends JpaRepository<Faculty, Long> {

    Optional<Faculty> findByNameIgnoreCase(String name);

    boolean existsByNameIgnoreCase(String name);

    boolean existsByNameIgnoreCaseAndIdNot(String name, Long id);
}
