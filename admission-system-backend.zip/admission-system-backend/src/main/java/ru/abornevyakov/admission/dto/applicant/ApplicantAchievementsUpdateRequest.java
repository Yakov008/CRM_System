package ru.abornevyakov.admission.dto.applicant;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;

public record ApplicantAchievementsUpdateRequest(

        @NotNull
        @Min(0)
        @Max(10)
        Integer achievementsScore
) {
}