package ru.abornevyakov.admission.controller.publicapi;

import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import ru.abornevyakov.admission.dto.program.AdmissionCampaignDto;
import ru.abornevyakov.admission.service.program.AdmissionCampaignService;

import java.util.List;

@RestController
@RequestMapping("/api/admission-campaigns")
@RequiredArgsConstructor
public class AdmissionCampaignController {

    private final AdmissionCampaignService admissionCampaignService;

    @GetMapping("/active")
    public List<AdmissionCampaignDto> getActiveCampaigns() {
        return admissionCampaignService.getActiveCampaigns();
    }
}