package ru.abornevyakov.admission.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import ru.abornevyakov.admission.entity.ApplicantProfile;

public interface ApplicantProfileRepository extends JpaRepository<ApplicantProfile, Long> {
    boolean existsByPassportNumber(String passportNumber);
}