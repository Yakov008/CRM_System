package ru.abornevyakov.admission.dto.document;

import java.time.LocalDateTime;

public record ApplicationDocumentDto(
        Long id,
        Long applicationId,
        String documentType,
        String fileName,
        String filePath,
        String status,
        LocalDateTime uploadedAt,
        String comment
) {
}