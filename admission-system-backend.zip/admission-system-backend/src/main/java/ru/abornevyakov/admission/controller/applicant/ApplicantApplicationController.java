package ru.abornevyakov.admission.controller.applicant;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;
import ru.abornevyakov.admission.dto.application.ApplicationCreateRequest;
import ru.abornevyakov.admission.dto.application.ApplicationDto;
import ru.abornevyakov.admission.dto.application.ApplicationUpdateRequest;
import ru.abornevyakov.admission.service.application.ApplicationService;

import java.util.List;

@RestController
@RequestMapping("/api/applicants/{applicantId}/applications")
@RequiredArgsConstructor
public class ApplicantApplicationController {

    private final ApplicationService applicationService;

    @PostMapping
    public ApplicationDto createApplication(
            @PathVariable Long applicantId,
            @Valid @RequestBody ApplicationCreateRequest request
    ) {
        return applicationService.createApplication(applicantId, request);
    }

    @GetMapping
    public List<ApplicationDto> getApplicationsByApplicantId(
            @PathVariable Long applicantId
    ) {
        return applicationService.getApplicationsByApplicantId(applicantId);
    }

    @PutMapping("/{applicationId}")
    public ApplicationDto updateApplication(
            @PathVariable Long applicantId,
            @PathVariable Long applicationId,
            @Valid @RequestBody ApplicationUpdateRequest request
    ) {
        return applicationService.updateApplication(applicantId, applicationId, request);
    }

    @PatchMapping("/{applicationId}/withdraw")
    public ApplicationDto withdrawApplication(
            @PathVariable Long applicantId,
            @PathVariable Long applicationId
    ) {
        return applicationService.withdrawApplication(applicantId, applicationId);
    }

    @PatchMapping("/{applicationId}/submit")
    public ApplicationDto submitApplication(
            @PathVariable Long applicantId,
            @PathVariable Long applicationId
    ) {
        return applicationService.submitApplication(applicantId, applicationId);
    }
}
