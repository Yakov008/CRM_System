package ru.abornevyakov.admission.mapper;

import org.springframework.stereotype.Component;
import ru.abornevyakov.admission.dto.program.AdmissionCampaignDto;
import ru.abornevyakov.admission.entity.AdmissionCampaign;

@Component
public class AdmissionCampaignMapper {

    public AdmissionCampaignDto toDto(AdmissionCampaign campaign) {
        return new AdmissionCampaignDto(
                campaign.getId(),
                campaign.getName(),
                campaign.getYear(),
                campaign.getStartDate(),
                campaign.getEndDate(),
                campaign.isActive()
        );
    }
}
