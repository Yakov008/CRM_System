package ru.abornevyakov.admission.controller.officer;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;
import ru.abornevyakov.admission.dto.applicant.ApplicantAchievementsUpdateRequest;
import ru.abornevyakov.admission.dto.applicant.ApplicantDto;
import ru.abornevyakov.admission.service.applicant.ApplicantService;

@RestController
@RequestMapping("/api/officer/applicants")
@RequiredArgsConstructor
public class OfficerApplicantController {

    private final ApplicantService applicantService;

    @PatchMapping("/{applicantId}/achievements")
    public ApplicantDto updateAchievementsScore(
            @PathVariable Long applicantId,
            @Valid @RequestBody ApplicantAchievementsUpdateRequest request
    ) {
        return applicantService.updateAchievementsScore(applicantId, request);
    }
}