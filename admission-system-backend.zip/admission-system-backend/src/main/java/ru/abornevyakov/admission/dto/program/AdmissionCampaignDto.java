package ru.abornevyakov.admission.dto.program;

import java.time.LocalDate;

public record AdmissionCampaignDto(
        Long id,
        String name,
        Integer year,
        LocalDate startDate,
        LocalDate endDate,
        boolean active
) {
}