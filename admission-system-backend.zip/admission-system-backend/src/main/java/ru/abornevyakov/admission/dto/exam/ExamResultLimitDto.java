package ru.abornevyakov.admission.dto.exam;

import java.time.LocalDateTime;

public record ExamResultLimitDto(
        Integer limit,
        Long used,
        Long remaining,
        LocalDateTime resetAt
) {
}