package ru.abornevyakov.admission.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import ru.abornevyakov.admission.entity.ApplicationDocument;
import ru.abornevyakov.admission.entity.enums.DocumentStatus;

import java.util.List;

public interface ApplicationDocumentRepository extends JpaRepository<ApplicationDocument, Long> {

    List<ApplicationDocument> findByApplicationId(Long applicationId);

    List<ApplicationDocument> findByStatus(DocumentStatus status);
}