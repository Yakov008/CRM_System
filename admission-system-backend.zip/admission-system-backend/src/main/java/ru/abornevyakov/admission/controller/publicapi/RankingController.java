package ru.abornevyakov.admission.controller.publicapi;

import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;
import ru.abornevyakov.admission.dto.ranking.ProgramRankingDto;
import ru.abornevyakov.admission.service.ranking.RankingService;

@RestController
@RequestMapping("/api/rankings")
@RequiredArgsConstructor
public class RankingController {

    private final RankingService rankingService;

    @GetMapping("/programs/{programId}")
    public ProgramRankingDto getRankingByProgramId(@PathVariable Long programId) {
        return rankingService.getRankingByProgramId(programId);
    }
}