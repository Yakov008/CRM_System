package ru.abornevyakov.admission.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import ru.abornevyakov.admission.entity.ApplicationPriority;

import java.util.List;

public interface ApplicationPriorityRepository extends JpaRepository<ApplicationPriority, Long> {

    List<ApplicationPriority> findByApplicationIdOrderByPriorityNumberAsc(Long applicationId);

    List<ApplicationPriority> findByProgramId(Long programId);

    boolean existsByApplicationIdAndProgramFacultyNameIgnoreCase(Long applicationId, String facultyName);

    boolean existsByApplicationApplicantIdAndProgramFacultyNameIgnoreCase(Long applicantId, String facultyName);

    @Modifying
    @Query("delete from ApplicationPriority priority where priority.application.id = :applicationId")
    void deleteByApplicationId(@Param("applicationId") Long applicationId);
}
