package ru.abornevyakov.admission.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import ru.abornevyakov.admission.entity.ProgramExamRequirement;

import java.util.List;

public interface ProgramExamRequirementRepository extends JpaRepository<ProgramExamRequirement, Long> {

    List<ProgramExamRequirement> findByProgramId(Long programId);

    List<ProgramExamRequirement> findByProgramIdIn(List<Long> programIds);

    boolean existsByExamSubjectId(Long examSubjectId);

    boolean existsByProgramIdAndExamSubjectId(Long programId, Long examSubjectId);

    boolean existsByProgramIdAndExamSubjectIdAndIdNot(
            Long programId,
            Long examSubjectId,
            Long id
    );
}
