package ru.abornevyakov.admission.dto.applicant;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import java.time.LocalDate;

public record ApplicantRegisterRequest(

        @Email
        @NotBlank
        String email,

        @NotBlank
        @Size(min = 6, max = 100)
        String password,

        @NotBlank
        String lastName,

        @NotBlank
        String firstName,

        String middleName,

        @NotNull
        LocalDate birthDate,

        @NotBlank
        String phone,

        @NotBlank
        String passportNumber
) {
}