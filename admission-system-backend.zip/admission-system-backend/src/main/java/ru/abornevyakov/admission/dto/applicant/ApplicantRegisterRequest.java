package ru.abornevyakov.admission.dto.applicant;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Past;
import jakarta.validation.constraints.Size;

import java.time.LocalDate;

public record ApplicantRegisterRequest(

        @Email(message = "Некорректный email")
        @NotBlank(message = "Email обязателен")
        @Size(max = 120, message = "Email не должен превышать 120 символов")
        String email,

        @NotBlank(message = "Пароль обязателен")
        @Size(min = 6, max = 100, message = "Пароль должен содержать от 6 до 100 символов")
        String password,

        @NotBlank(message = "Фамилия обязательна")
        @Size(max = 80, message = "Фамилия не должна превышать 80 символов")
        String lastName,

        @NotBlank(message = "Имя обязательно")
        @Size(max = 80, message = "Имя не должно превышать 80 символов")
        String firstName,

        @Size(max = 80, message = "Отчество не должно превышать 80 символов")
        String middleName,

        @NotNull(message = "Дата рождения обязательна")
        @Past(message = "Дата рождения должна быть в прошлом")
        LocalDate birthDate,

        @NotBlank(message = "Телефон обязателен")
        @Size(max = 30, message = "Телефон не должен превышать 30 символов")
        String phone,

        @NotBlank(message = "Паспорт обязателен")
        @Size(max = 20, message = "Паспорт не должен превышать 20 символов")
        String passportNumber
) {
}
