package ru.abornevyakov.admission.mapper;

import org.springframework.stereotype.Component;
import ru.abornevyakov.admission.dto.document.ApplicationDocumentDto;
import ru.abornevyakov.admission.entity.ApplicationDocument;

@Component
public class ApplicationDocumentMapper {

    public ApplicationDocumentDto toDto(ApplicationDocument document) {
        return new ApplicationDocumentDto(
                document.getId(),
                document.getApplication().getId(),
                document.getDocumentType().name(),
                document.getFileName(),
                document.getFilePath(),
                document.getStatus().name(),
                document.getUploadedAt(),
                document.getComment()
        );
    }
}